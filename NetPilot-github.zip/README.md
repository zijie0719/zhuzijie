# NetPilot · 本机网络自动化工作台

用一根 Console 线接上交换机 / 路由器，在浏览器里看拓扑、查命令、让 AI 写配置，再逐条审核下发。
数据、密钥、备份全部留在本机，默认只监听 `127.0.0.1`，不上公网。

支持厂商：**华为 VRP / 华三 Comware / 锐捷 RGOS / Cisco IOS·IOS-XE**。

```
Console / SSH  ──►  SecureCRT 桥接（VBS）  ──►  NetPilot 本机后台  ──►  浏览器
                    或 串口 / SSH 直连           白名单 · 备份 · 审计
```

## 能力

| 模块 | 说明 |
| --- | --- |
| 拓扑 | LLDP / CDP 只读采集自动画图，可递归发现、可按 30 秒–60 分钟自动刷新，SSE 实时推送 |
| 命令速查 | **377 条**（94×4 厂商 + Cisco 多一条），标注只读 / 配置 / 高风险、所属视图，四维筛选 |
| 配置向导 | **22 个步骤**按厂商语法生成完整 CLI：VLAN、Trunk、SVI、STP、LACP、DHCP、OSPF、VRRP、VSU |
| 自动化编排 | 预检白名单 → 人工确认 → 写前自动备份 → 逐行下发，报错即停，单任务最多 300 行 |
| 配置备份 | 加密落盘，独立页面查看 / 导出，保留最近 120 份 |
| AI 助手 | 流式输出，只发厂商 / 型号 / 版本，命令块可「只读直查」或「送入编排」，不自动执行 |
| 部署 | 可开 `0.0.0.0` 对外，强制口令 + Host 白名单 + CSP，附 nginx 样例 |

技术栈：React 19 + Vite 8 + Express 5 + Node 22/24，`serialport` / `ssh2`，零数据库（JSON + 加密文件）。

## 目录

[1. 启动](#1-启动) · [2. 连接设备](#2-连接设备三种方式securecrt-优先) · [3. 拓扑](#3-拓扑) · [4. 一键自动化](#4-一键自动化) · [5. 配置向导](#5-配置向导) · [6. 命令速查](#6-命令速查) · [7. AI 配置](#7-ai-配置后台保存页面不落盘) · [8. 数据与边界](#8-数据与边界) · [9. 部署到服务器](#9-部署到服务器) · [10. 排错](#10-排错) · [11. 仓库结构](#11-仓库结构) · [12. 许可](#12-许可)

## 使用范围

本项目用于**你自己有权管理的网络设备**。所有写配置动作都要经过命令白名单、人工输入确认、写前备份三道关，
并且不会自动执行 `save` / `write` 落盘。请不要把它指向不属于你的设备。

---

## 1. 启动

```bat
:: 首次
npm ci
npm run build

:: 日常（等价于双击「启动 NetPilot.cmd」）
npm start
```

`启动 NetPilot.cmd` 会先检查 Node，再拉起后台并自动打开 `http://127.0.0.1:47831`。
页面顶部显示「本机服务运行中」即就绪。端口被占用时用 `NETPILOT_PORT=47832 npm start` 换端口。

要求 Node `^22.13.0 || >=24`。

---

## 2. 连接设备（三种方式，SecureCRT 优先）

### 方式 A：SecureCRT 桥接（推荐，不抢串口）

1. 在 SecureCRT 里用 Console 或 SSH 登录设备，停在 `<设备名>` / `设备名#` 提示符。
2. 网页点「连接设备」→「SecureCRT」→ 生成配对入口。
3. 在该 SecureCRT 标签执行 **Script → Run**，选择弹窗给出的
   `.netpilot\NetPilot-SecureCRT.vbs`。
4. 粘贴 12 位配对码。脚本会在原标签内循环等待任务，绑定成功后网页自动读取厂商、型号、LLDP 邻居。

脚本不读密码、不关你的会话；网页断开只解绑。运行期间不要在同一标签手动敲命令。

> 脚本由后端按 UTF-16LE + BOM 生成，中文提示在 Windows 上不会乱码。

### 方式 B：串口直连

网页 →「串口直连」→ 选串口（自动每 5 秒刷新）→ 选波特率（默认 9600）。Windows 是 COM3，Linux 是 /dev/ttyUSB0 或 /dev/ttyACM0。
需要已登录的 Console 会提示符；程序不猜口令。**同一 COM 口不能被 SecureCRT 同时占用。**

### 方式 C：SSH 直连

填私有 IPv4、端口，点「读取公钥（不会登录）」，用带外渠道核对 `SHA256:` 指纹后再连接。
指纹白名单存在本机设置里，递归发现只访问白名单内主机。

---

## 3. 拓扑

绑定成功后自动执行只读采集（`display lldp neighbor` / `show lldp neighbors detail` / `show cdp neighbors detail`），
解析邻居名称、端口、机箱号、管理地址后画图。

- 拖动平移、滚轮缩放、点设备看详情
- 「自动发现」可递归（限私有网段 + 已存指纹，默认 3 跳 / 最多 20 台）
- **拓扑自动刷新**：设置里可选 30 秒–60 分钟，只对已连接设备刷新直接邻居；新增设备/链路才写审计，不刷任务列表
- 设备列表里每台已连接设备可单独「刷新邻居」，结果通过 SSE 实时推到拓扑，无需手动刷新页面
- 设备详情显示「最近采集」时间，便于判断数据新鲜度
- 导出拓扑 JSON 便于交接

只读发现不会开启 LLDP/CDP，也不会改配置；图上没画出来的设备不代表不存在。

---

## 4. 一键自动化

「自动化编排」页顶部有 6 个快捷方案：**设备体检 / 读取当前配置 / 批量建 VLAN / Trunk 放行 / Access 端口 / 改设备名**。

流程固定为四步，缺一不可：

1. 勾选目标设备（仅同厂商、已连接）
2. 预检：逐行校验命令白名单，拦截未替换参数、破坏性命令、`save/write`
3. 人工确认：输入「确认执行」并勾选影响范围
4. 执行：写配置前先备份（DPAPI 加密落盘），任一行回显报错立即停止

不会自动写启动配置；要保存请在终端人工执行。单次任务最多 300 行命令；配置向导生成超限会直接提示拆分批次。执行中途可「停止后续步骤」，已生效的命令不会回滚。

每次写配置前都会自动留存一份设备配置快照，在「配置备份」页可以看设备、时间、大小并导出明文；最多保留 120 份（按时间淘汰），加密方式与密钥存储一致。

---

## 5. 配置向导

「配置向导」把常见交付场景拆成 22 个步骤，勾选 + 填参数，按目标厂商语法生成完整 CLI：

| 分组 | 步骤 |
| --- | --- |
| 基础与带外管理 | 改设备名、NTP、Syslog、SSH、只读 SNMP |
| VLAN 与二层 | 批量建 VLAN、Access、Trunk（追加放行）、SVI 网关 |
| 生成树与防环 | STP 模式（RSTP/MST）、边缘端口、BPDU 保护 |
| 链路聚合 | LACP 聚合组 + 成员口 |
| 接入安全 | 端口安全、DHCP Snooping 信任口、DHCP 地址池 |
| 三层与路由 | 默认路由、OSPF |
| 高可用 | VRRP、VSU 堆叠（仅锐捷） |
| 邻居与巡检 | 启用 LLDP、只读体检 |

- 华为/华三自动用 `system-view … return`，锐捷/Cisco 用 `configure terminal … end`
- 接口名、VLAN、IP、掩码、聚合组号全部白名单校验，非法值直接报错，不会拼进命令
- 生成结果一键「送入编排预检」，仍要走人工确认
- VSU 等厂商专有步骤会明确拒绝其他厂商，不会硬套语法

## 6. 命令速查

**94 条 × 4 厂商（Cisco 95 条），共 377 条**，覆盖系统 / 接口 / VLAN / 路由 / 邻居 / 安全 / 诊断七类，
每条标注只读·配置·高风险、所属视图和注意事项，可按「厂商 / 分类 / 类型 / 关键字」四维筛选。
每条命令可一键「加入配置草稿」，直接进自动化预检。

查询类包含：版本、当前/启动配置、启动文件、License、时钟、CPU、内存、温度、风扇、电源、堆叠 IRF/VSU、
接口摘要与详情、流量计数、光模块、PoE、聚合、LLDP/CDP 邻居与统计、VLAN 列表、
MAC 表、ARP、路由表、OSPF/BGP 邻居、VRRP、BFD、IGMP Snooping、ACL、端口安全、DHCP Snooping、
802.1X、RADIUS、生成树、QoS 队列、日志、调试开关、一键诊断等。

锐捷专有条目已单独收录：`vlan range`、`switchport trunk allowed vlan only / remove`、RLDP、
`ip dhcp snooping trust`、VSU（`switch virtual domain`）、`ip route ... <管理距离>` 浮动路由等。

---

## 7. AI 配置（后台保存，页面不落盘）

「系统设置 → AI 服务配置」：

- 快速填充：DeepSeek / DeepSeek R1 / OpenAI / Kimi / 通义千问 / 智谱 GLM / Ollama 本地
- Base URL 自动追加 `/chat/completions`；远端强制 HTTPS，本机允许 `http://127.0.0.1:11434/v1`
- API Key 由 Node 后台加密后落盘（Windows 用 **DPAPI CurrentUser**，Linux/macOS 用 **AES-256-GCM**），页面只显示「已保存 · 不回显」
- 保存后可「测试已保存配置」验证连通性

右侧常驻 AI 面板（工具化，不是聊天演示）：

- 标题栏直接显示**当前模型**（如 `DeepSeek · deepseek-chat`）与是否已配置，未配置时点一下进设置
- 上方一行选**目标设备**、勾选是否附带拓扑；选择设备后快捷指令会换成设备相关的那组
- 空态是 4 个**可执行的快捷指令**（巡检、端口 up/down、备份、VLAN 变更），点一下直接提问并流式返回，不再只是往输入框塞文字
- **流式输出** + `停止` 随时中止；失败显示服务商真实原因（401/402/429/超时），`重试` 会带上上一次提问内容
- 选目标设备后只把**厂商 / 型号 / 版本**发给模型，并附带该厂商语法要点，避免张冠李戴
- 每段命令下方只有三个动作：`复制` / `只读直查`（全为 `display`/`show` 时出现，经设备会话执行并弹窗看结果）/ `送入编排`（仍需预检与人工确认）
- 只读查询结果可勾选「允许把回显发给模型解读」，直接接着问

## 8. 数据与边界

| 内容 | 位置 |
| --- | --- |
| 设备、链路、任务、审计 | `.netpilot/state.json` |
| API Key、SSH 密码 | `.netpilot/secrets.dpapi`（Windows DPAPI / Linux AES-256-GCM 密文） |
| 配置备份 | `.netpilot/backups/<id>.dpapi` |
| 审计 | 最近 1,500 条，可导出 JSON |

`.netpilot/` 已写进 `.gitignore`。**不要把整个目录提交到仓库**——里面有加密密钥和真实设备信息。

- 默认仅监听 `127.0.0.1`，校验 Host / Origin，写操作走 CSRF token
- 单任务串行，避免并发下发到同一台设备
- 所有真机命令都经白名单 + 人工确认；重启、清空、格式化、删除、保存启动配置被硬拦截

---

## 9. 部署到服务器

默认只监听 `127.0.0.1`。对外提供服务必须显式开三件事，否则拒绝启动：

```bat
set NETPILOT_BIND=0.0.0.0
set NETPILOT_ACCESS_TOKEN=至少12位的长口令
set NETPILOT_ALLOWED_HOSTS=netpilot.example.com
node server\index.mjs
```

| 变量 | 作用 | 默认 |
| --- | --- | --- |
| `NETPILOT_BIND` | 监听地址，`0.0.0.0` 为所有网卡 | `127.0.0.1` |
| `NETPILOT_PORT` | 端口 | `47831` |
| `NETPILOT_ACCESS_TOKEN` | 访问口令；非回环监听时**必填且 ≥12 位** | 空（不启用登录） |
| `NETPILOT_ALLOWED_HOSTS` | 允许的 Host（逗号分隔，支持 `*`）；回环地址始终放行 | 空 |

启用口令后：页面先出登录框，`HttpOnly + SameSite=Strict` Cookie 12 小时有效，登录失败 1 分钟 10 次限流，成功/失败都写审计。
`/api/health` 不需要登录，适合负载均衡探活；`/bridge/*` 永远只接受本机来源。

**Windows / Linux 都能跑，密钥存储方式不同：**

- Windows：`secrets.dpapi` / 备份用 **DPAPI（CurrentUser）**，换用户或换机器解不开。
- Linux / macOS：用 **AES-256-GCM**，密钥在 `.netpilot/.netpilot.key`（32 字节，0600）。
  这个文件必须和 `.netpilot/` 一起备份；丢了就再也解不开已保存的 API Key 与配置备份。
- Linux 下串口需要把运行用户加入 `dialout` 组：`sudo usermod -aG dialout <用户>`，重新登录后生效。

**必须先想清楚 Console 线插在哪台机器：**

- **推荐**：NetPilot 跑在插着 Console 线的 Windows 机器上（SecureCRT 也在同一台），局域网/公网通过 nginx 反代访问网页。
- 如果跑在机房服务器上，那 Console 线（或串口服务器）和 SecureCRT 也必须在那台服务器上，因为桥接脚本走的是 `127.0.0.1`。

nginx 反代样例见 `deploy/nginx.conf.example`（已关闭 SSE 缓冲），Windows 一键脚本见 `deploy/start-server.cmd`。
反代时记得把域名写进 `NETPILOT_ALLOWED_HOSTS`，并用 HTTPS——口令走明文 HTTP 等于没有口令。

## 10. 排错

| 现象 | 处理 |
| --- | --- |
| 页面提示「本机后台未连接」 | 运行「启动 NetPilot.cmd」；确认 47831 未被占用 |
| 选不到 COM 口 | 装 USB 转串口驱动；SecureCRT 先断开该端口 |
| SecureCRT 配对超时 | 提示符必须停在 `<SW1>` / `SW1#`；脚本要在目标标签里跑 |
| 厂商识别失败 | 登录后手动执行 `display version` / `show version`，确认权限足够 |
| AI 返回 401/402 | 密钥、余额或模型名不对；在设置里重新保存并测试 |
| 拓扑只有一台设备 | 邻居协议未启用或对端未通告；先在设备上开 LLDP |
| 浏览器提示需要登录 | 部署时设置了 `NETPILOT_ACCESS_TOKEN`，输入该口令；忘记可改环境变量重启 |
| 反代后 403 Host 不在允许列表 | 把域名加进 `NETPILOT_ALLOWED_HOSTS`，并确认 nginx 透传了 `Host` |
| 页面事件不刷新 | nginx 需要 `proxy_buffering off`，否则 SSE 会被缓冲 |

开发：`npm run dev`（Vite 5173，代理到 47831）、`npm test`（152 项，含部署安全、配置向导、存储裁剪与加密回归）、`npm run build`。

---

## 11. 仓库结构

```
server/        Express 后台：路由、传输层、桥接、白名单、存储、AI、配置向导
  index.mjs      全部 HTTP 路由与任务编排
  transport.mjs  串口 / SSH / SecureCRT 三种连接的统一接口
  securecrt.mjs  配对码、任务轮询、结果回传（配合 scripts/*.vbs）
  vendors.mjs    四厂商命令库与语法差异
  wizard.mjs     22 步配置生成器
  policy.mjs     命令白名单与风险判定
  store.mjs      JSON 状态 + 加密密钥 + 备份裁剪
src/           React 前端（拓扑、编排、向导、命令库、AI、备份、设置）
scripts/       SecureCRT 桥接脚本、构建与启动脚本
tests/         152 项 Node 原生测试，覆盖服务端全链路
deploy/        nginx 反代样例、服务器启动脚本
components/    Shadcn UI 组件（模板自带，非本项目业务代码）
```

CI 配置在 `.github/workflows/ci.yml`，推送到 GitHub 后会在 Windows runner 上自动跑构建与测试。

## 12. 许可

[MIT](LICENSE)。模板来源见 [PROVENANCE.md](PROVENANCE.md)，第三方依赖各自保留其许可。
