@echo off
chcp 65001 >nul
title NetPilot - 本机网络自动化工作台
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo 未检测到 Node.js。请安装 Node.js 24 LTS 后重试。
  echo 下载地址：https://nodejs.org/
  pause
  exit /b 1
)
echo 正在启动 NetPilot。本窗口关闭后，本次启动的后台服务也会停止。
echo 设备拓扑和密钥保存在本机，不会自动发布公网。
node scripts\launch.mjs
if errorlevel 1 pause
