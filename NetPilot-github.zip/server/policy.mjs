import { isIP } from 'node:net';
import { createHash } from 'node:crypto';

export function commandLines(input) {
  if (typeof input !== 'string' || input.length > 20000) throw new Error('命令必须是文本，且不超过 20,000 字符');
  const lines = input.split(/\r?\n/).map(x => x.trim()).filter(x => x && !/^(?:!|#|\/\/)/.test(x));
  if (!lines.length || lines.length > 300) throw new Error('每次执行需要 1–300 行命令');
  if (lines.some(x => /[\x00-\x1f\x7f;`|]/.test(x) || x.length > 500)) throw new Error('自动化命令不允许控制字符、分号、反引号、管道或超长行');
  return lines;
}
// 配置视图命令白名单：只放行明确属于设备配置语法的前缀，破坏性命令另由 blocklist 拦截。
const CONFIG_PREFIX = /^(?:system-view|quit|return|exit|end|configure terminal|vlan|interface|name|description|sysname|hostname|port|switchport|ip|ipv6|router|network|ospf|area|stp|spanning-tree|shutdown|undo|no|acl|rule|traffic-filter|route-policy|port-security|switch|vrrp|dhcp|service|snmp-agent|snmp-server|info-center|ntp-service|ntp|logging|lldp|channel-group|eth-trunk|bridge-aggregation|link-aggregation|stelnet|ssh|enable|monitor|mirror|dot1x|radius-server|loopback-detection|loopback-detect|rldp|mac-address|arp|default-information|passive-interface|passive-int|auto-cost|redistribute|aggregate-address|gateway-list|dns-list|host|hardware-address|client-name|dns-server|default-router|lease|mode)(?:\s|$)/i;
export function assessCommands(lines) {
  const blocked = [], warnings = [];
  for (const cmd of lines) {
    if (!isReadonly(cmd) && !CONFIG_PREFIX.test(cmd)) blocked.push(`不在自动化支持范围内的完整命令（不接受缩写或系统调用）：${cmd}`);
    if (/^(?:reboot|reload|reset\s+(?:saved|configuration)|erase|format|delete|install|boot|upgrade|undo\s+startup|factory|write\s+erase|request\s+system|switch\s+convert|convert\s+mode|tclsh|python|shell|bash)\b/i.test(cmd)) blocked.push(`禁止自动执行破坏性或系统级命令：${cmd}`);
    if (/<[^>]+>|\{[^}]+\}/.test(cmd)) blocked.push(`尚有未替换参数：${cmd}`);
    if (/^(?:save|write(?:\s+memory)?|copy\s+running-config)\b/i.test(cmd)) blocked.push('此版本不自动写入启动配置。请先验证运行状态，再通过厂商终端另行保存。');
    if (/^(?:shutdown|undo|no\s|ip\s+route|vlan|interface|hostname|sysname|router|stp|acl|access-list|aaa|username|local-user|password|enable\s+secret|snmp)/i.test(cmd)) warnings.push(`需要核对影响范围：${cmd.replace(/((?:password|secret|community)\s+).*/i, '$1[已隐藏]')}`);
  }
  if (lines.some(x => !isReadonly(x))) warnings.unshift('包含配置命令：备份成功后逐行执行，任一失败立即停止；不承诺自动回滚。');
  return { blocked: [...new Set(blocked)], warnings: [...new Set(warnings)], backupRequired: lines.some(x => !isReadonly(x)) };
}
const readonlyPatterns = [
  /^display (?:version|device|clock|cpu-usage|memory(?:-usage)?|current-configuration|saved-configuration|startup|vlan(?:\s+\d+)?|ip (?:interface brief|routing-table|arp)|arp(?: all)?|interface(?: brief|\s+[A-Za-z][\w/.:-]*)?|lldp neighbor(?:-information)?(?: list| verbose| detail)?|stp(?: brief)?|mac-address|logbuffer|link-aggregation summary|users|transceiver interface [\w/.:-]+ verbose)$/i,
  /^show (?:version|inventory|clock|running-config|startup-config|vlan(?: brief)?|ip (?:interface brief|route|arp)|arp|interfaces?(?: status| description| brief|\s+[A-Za-z][\w/.:-]*)?|lldp neighbors?(?: detail)?|cdp neighbors(?: detail)?|spanning-tree(?: summary)?|mac address-table|logging|etherchannel summary|users|processes cpu(?: sorted)?|memory)$/i,
];
export function isReadonly(cmd) { return typeof cmd === 'string' && readonlyPatterns.some(p => p.test(cmd.trim())); }
export function cliFailed(output) { return /(?:^|\n)\s*(?:%\s*(?:Invalid|Error|Unknown|Incomplete|Ambiguous|Unrecognized|Authorization|Access denied|Permission|Failed)|Error\s*:|Unrecognized command|Wrong parameter|Invalid (?:input|command)|Permission denied|Incomplete command|Ambiguous command|Command rejected|Failure:)/im.test(output); }
export function digest(value) { return createHash('sha256').update(JSON.stringify(value)).digest('hex'); }
export function isPrivateV4(ip) {
  if (isIP(ip) !== 4) return false; const b = ip.split('.').map(Number);
  return b[0] === 10 || (b[0] === 172 && b[1] >= 16 && b[1] <= 31) || (b[0] === 192 && b[1] === 168);
}
export function parseScopes(text) {
  if (typeof text !== 'string' || text.length > 1500) throw new Error('管理范围格式不正确');
  return text.split(/[,，\s]+/).filter(Boolean).map(s => {
    const [ip, bits] = s.split('/'); const prefix = bits === undefined ? 32 : Number(bits);
    if (!isPrivateV4(ip) || !/^\d+$/.test(bits ?? '32') || !Number.isInteger(prefix) || prefix < 8 || prefix > 32) throw new Error('递归范围仅支持 RFC1918 私有 IPv4 CIDR，例如 192.168.1.0/24');
    const num = ip.split('.').reduce((a, n) => ((a << 8) | Number(n)) >>> 0, 0); const mask = (0xffffffff << (32 - prefix)) >>> 0;
    return { network: (num & mask) >>> 0, mask };
  });
}
export function inScope(ip, text) {
  if (!isPrivateV4(ip)) return false;
  const num = ip.split('.').reduce((a, n) => ((a << 8) | Number(n)) >>> 0, 0);
  return parseScopes(text).some(s => ((num & s.mask) >>> 0) === s.network);
}
export function validHost(host) { if (typeof host !== 'string' || !isPrivateV4(host)) throw new Error('设备连接仅接受明确的私有 IPv4 管理地址'); return host; }
export function validPort(port = 22) { const p = Number(port); if (!Number.isInteger(p) || p < 1 || p > 65535) throw new Error('端口必须是 1–65535'); return p; }
export function validateAi(ai) {
  const url = new URL(ai.baseUrl);
  if (url.username || url.password || url.search || url.hash || url.pathname.includes('..')) throw new Error('模型 Base URL 不允许凭据、查询参数或片段');
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if (url.protocol !== 'https:' && !(local && url.protocol === 'http:')) throw new Error('远程模型必须使用 HTTPS；只有本机模型可使用 HTTP');
  if (!ai.model || typeof ai.model !== 'string' || ai.model.length > 150 || /[\x00-\x1f]/.test(ai.model)) throw new Error('请填写有效模型名称');
  if (!['deepseek', 'openai', 'custom'].includes(ai.provider)) throw new Error('模型提供方无效');
  const timeoutMs = Number(ai.timeoutMs || 90000);
  if (!Number.isInteger(timeoutMs) || timeoutMs < 5000 || timeoutMs > 180000) throw new Error('模型超时需为 5–180 秒');
  return { provider: ai.provider, baseUrl: url.toString().replace(/\/$/, ''), model: ai.model, timeoutMs };
}
