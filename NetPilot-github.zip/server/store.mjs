import { mkdir, readFile, writeFile, rename, rm, readdir, stat } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { randomUUID, randomBytes, createCipheriv, createDecipheriv } from 'node:crypto';

export function redact(value) {
  return String(value ?? '').replace(/\b(sk-[\w-]{8,})\b/g, '[REDACTED]').replace(/((?:password|passwd|secret|token|api[-_ ]?key|community)\s*(?:[:=]|\s)\s*)[^\r\n]+/gi, '$1[REDACTED]').slice(0, 4000);
}
export async function dpapi(value, decrypt = false) {
  if (process.platform !== 'win32') throw new Error('此版本使用 Windows DPAPI 加密，请在 Windows 当前用户下运行。');
  const script = `Add-Type -AssemblyName System.Security; $v=[Console]::In.ReadToEnd(); $b=[Convert]::FromBase64String($v); $r=[System.Security.Cryptography.ProtectedData]::${decrypt ? 'Unprotect' : 'Protect'}($b,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Out.Write([Convert]::ToBase64String($r))`;
  return new Promise((resolve, reject) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '', err = ''; const timer = setTimeout(() => { p.kill(); reject(new Error('Windows 密钥保护服务超时')); }, 15000);
    p.stdout.on('data', x => { out += x; if (out.length > 12_000_000) p.kill(); });
    p.stderr.on('data', x => { err += x; });
    p.on('error', () => { clearTimeout(timer); reject(new Error('无法启动 Windows DPAPI；未保存明文密钥')); });
    p.on('close', code => { clearTimeout(timer); if (code !== 0 || err) reject(new Error('Windows DPAPI 加密或解密失败，请使用创建数据的 Windows 用户')); else resolve(decrypt ? Buffer.from(out.trim(), 'base64').toString('utf8') : out.trim()); });
    p.stdin.on('error', () => {});
    p.stdin.end(decrypt ? value : Buffer.from(value, 'utf8').toString('base64'));
  });
}
export const defaultSettings = () => ({
  ai: { provider: 'deepseek', baseUrl: 'https://api.deepseek.com', model: 'deepseek-chat', timeoutMs: 90000 },
  discovery: { username: '', scope: '', hosts: [], autoRefresh: 0 },
  serial: { path: '', baudRate: 9600, autoConnect: false, vendor: 'auto' },
});

/**
 * 非 Windows 部署（Linux 服务器、容器）没有 DPAPI，改用本机密钥文件的 AES-256-GCM。
 * 密文格式：v1:<iv>:<tag>:<ciphertext>，全部 base64。
 */
export async function localVault(directory) {
  const keyPath = join(directory, '.netpilot.key');
  let key;
  try { key = await readFile(keyPath); }
  catch (error) {
    if (error.code !== 'ENOENT') throw new Error(`读取本机密钥文件失败：${error.message}`);
    key = randomBytes(32);
    await writeFile(keyPath, key, { mode: 0o600 });
  }
  if (key.length !== 32) throw new Error('本机密钥文件已损坏（长度不是 32 字节），请确认数据来源。');
  return async (value, decrypt = false) => {
    if (!decrypt) {
      const iv = randomBytes(12);
      const cipher = createCipheriv('aes-256-gcm', key, iv);
      const encrypted = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
      return `v1:${iv.toString('base64')}:${cipher.getAuthTag().toString('base64')}:${encrypted.toString('base64')}`;
    }
    const [version, ivText, tagText, dataText] = String(value).split(':');
    if (version !== 'v1' || !ivText || !tagText || !dataText) throw new Error('密文格式不受支持，可能来自其它部署方式');
    const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(ivText, 'base64'));
    decipher.setAuthTag(Buffer.from(tagText, 'base64'));
    return Buffer.concat([decipher.update(Buffer.from(dataText, 'base64')), decipher.final()]).toString('utf8');
  };
}
export async function createStore(directory, vault) {
  await mkdir(directory, { recursive: true }); await mkdir(join(directory, 'backups'), { recursive: true });
  // Windows 用 DPAPI 按当前用户加密；其它平台用本机 32 字节密钥的 AES-256-GCM。
  const protect = vault || (process.platform === 'win32' ? dpapi : await localVault(directory));
  const encryption = vault ? '注入式加解密（测试）' : process.platform === 'win32' ? 'Windows DPAPI · CurrentUser' : 'AES-256-GCM · 本机密钥文件';
  const backupDir = join(directory, 'backups');
  let state;
  try { state = JSON.parse(await readFile(join(directory, 'state.json'), 'utf8')); }
  catch (e) { if (e.code !== 'ENOENT') throw new Error('本机数据损坏，已停止启动以避免覆盖原有数据。'); state = { settings: defaultSettings(), devices: [], links: [], jobs: [], audit: [], backups: [] }; }
  // 旧版本数据可能缺少新增字段，按默认值补齐后再合并，避免 undefined 进入校验逻辑。
  const defaults = defaultSettings();
  state.settings = {
    ...defaults, ...state.settings,
    ai: { ...defaults.ai, ...state.settings?.ai },
    discovery: { ...defaults.discovery, ...state.settings?.discovery },
    serial: { ...defaults.serial, ...state.settings?.serial },
  };
  state.backups = Array.isArray(state.backups) ? state.backups.filter(item => item && typeof item.id === 'string') : [];
  // 配置备份只保留最近 120 份：启动时清一次，之后每写一份顺手清一次；元数据同步剔除。
  const pruneBackups = async () => {
    try {
      const files = (await readdir(backupDir)).filter(name => name.endsWith('.dpapi'));
      const removed = new Set();
      if (files.length > 120) {
        const entries = await Promise.all(files.map(async name => ({ name, time: (await stat(join(backupDir, name))).mtimeMs })));
        entries.sort((a, b) => b.time - a.time);
        for (const entry of entries.slice(120)) {
          await rm(join(backupDir, entry.name), { force: true });
          removed.add(entry.name.replace(/\.dpapi$/, ''));
        }
      }
      const present = new Set(files.map(name => name.replace(/\.dpapi$/, '')).filter(id => !removed.has(id)));
      state.backups = state.backups.filter(item => present.has(item.id));
    } catch { /* 备份目录异常不阻塞启动 */ }
  };
  await pruneBackups();
  let secrets = { apiKey: '', sshPassword: '' };
  try { secrets = JSON.parse(await protect(await readFile(join(directory, 'secrets.dpapi'), 'utf8'), true)); }
  catch (e) { if (e.code !== 'ENOENT') throw e; }
  state.devices = state.devices.map(d => ({ ...d, connected: false, status: 'stale' }));
  state.jobs = state.jobs.map(j => ['running', 'queued'].includes(j.status) ? { ...j, status: 'interrupted', endedAt: new Date().toISOString(), message: '后台重启：任务结果不确定，请核对设备；不会自动重放命令。' } : j);
  let queue = Promise.resolve();
  const serialize = action => { const next = queue.then(action); queue = next.catch(() => {}); return next; };
  const atomic = async (name, content) => {
    const temp = join(directory, `${name}.${randomUUID()}.tmp`);
    try {
      await writeFile(temp, content, { mode: 0o600 });
      for (let attempt = 0; ; attempt++) {
        try { await rename(temp, join(directory, name)); break; }
        catch (error) {
          // Windows scanners can briefly hold the destination. Retry only the same
          // atomic file rename, never a device command or an external operation.
          if (process.platform !== 'win32' || !['EPERM', 'EBUSY', 'EACCES'].includes(error.code) || attempt >= 4) throw error;
          await delay(25 * 2 ** attempt);
        }
      }
    } finally { await rm(temp, { force: true }).catch(() => {}); }
  };
  const persist = () => serialize(() => atomic('state.json', JSON.stringify(state, null, 2)));
  const safeSettings = () => ({ ...structuredClone(state.settings), ai: { ...state.settings.ai, hasKey: Boolean(secrets.apiKey) }, discovery: { ...structuredClone(state.settings.discovery), hasPassword: Boolean(secrets.sshPassword) }, security: { encryption, loopbackOnly: true } });
  await persist();
  return {
    state, secrets, safeSettings, persist,
    async saveSettings(settings, newSecrets) {
      return serialize(async () => {
        const nextSecrets = { ...secrets, ...newSecrets };
        await atomic('secrets.dpapi', await protect(JSON.stringify(nextSecrets)));
        state.settings = settings; secrets = nextSecrets; this.secrets = secrets;
        await atomic('state.json', JSON.stringify(state, null, 2));
      });
    },
    async audit(action, detail, status = 'ok') {
      state.audit.unshift({ id: randomUUID(), time: new Date().toISOString(), action, detail: redact(detail), status }); state.audit = state.audit.slice(0, 1500); await persist();
    },
    async saveBackup(meta, content) {
      const id = randomUUID();
      const time = new Date().toISOString();
      const bytes = Buffer.byteLength(content, 'utf8');
      const ciphertext = await protect(JSON.stringify({ deviceId: meta.deviceId, time, content }));
      await writeFile(join(backupDir, `${id}.dpapi`), ciphertext, { mode: 0o600 });
      state.backups.unshift({ id, deviceId: meta.deviceId, deviceName: meta.deviceName || '', vendor: meta.vendor || '', time, bytes });
      state.backups = state.backups.slice(0, 120);
      await pruneBackups();
      return id;
    },
    async readBackup(id) {
      if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('备份编号无效');
      return JSON.parse(await protect(await readFile(join(directory, 'backups', `${id}.dpapi`), 'utf8'), true));
    },
  };
}
