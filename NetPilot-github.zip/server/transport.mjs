import { EventEmitter } from 'node:events';
import { createHash, timingSafeEqual } from 'node:crypto';
import { StringDecoder } from 'node:string_decoder';

export const MAX_OUTPUT_BYTES = 1024 * 1024;
const CONTROL = /[\x00-\x1f\x7f-\x9f\u2028\u2029]/u;
const HOSTNAME = '[A-Za-z0-9_][A-Za-z0-9_.:/-]{0,127}';
const PROMPT = new RegExp(`^(?:<${HOSTNAME}>|\\[[~*]?${HOSTNAME}\\]|(?:${HOSTNAME})?(?:\\([A-Za-z0-9_./:-]{1,128}\\))[#>]|${HOSTNAME}[#>])$`);
const PAGER = /(?:--+\s*More\s*--+|More:)(?:[ \t]*\([^\n)]{0,80}\))?[ \t]*$/i;
const LOGIN_FAILURE = /(?:^|\n)[ \t%]*(?:(?:error|failure):\s*)?(?:authentication (?:fail(?:ed|ure)?|error)|login (?:incorrect|invalid|failed|failure)|(?:access|permission) denied|invalid (?:password|username)|(?:user\s*name or password) (?:error|incorrect|invalid)|bad passwords?)\b/im;

function problem(code, message) {
  return Object.assign(new Error(message), { code });
}

function validTimeout(value) {
  if (!Number.isInteger(value) || value < 1 || value > 2_147_483_647) {
    throw problem('INVALID_TIMEOUT', '超时时间必须是有效的正整数毫秒数');
  }
  return value;
}

function singleLine(value, label, allowEmpty = false) {
  if (typeof value !== 'string' || CONTROL.test(value) || (!allowEmpty && !value.trim())) {
    throw problem('INVALID_INPUT', `${label}必须是单行文本，且不能包含控制字符`);
  }
  return value;
}

function endpoint({ host, port = 22, timeoutMs = 8000 }) {
  singleLine(host, 'SSH 主机');
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw problem('INVALID_PORT', 'SSH 端口必须在 1–65535 之间');
  }
  return { host, port, timeoutMs: validTimeout(timeoutMs) };
}

export function fingerprintForKey(key) {
  return `SHA256:${createHash('sha256').update(key).digest('base64').replace(/=+$/, '')}`;
}

export function matchesFingerprint(key, expected) {
  if (typeof expected !== 'string' || !/^SHA256:[A-Za-z0-9+/]{43}$/.test(expected)) return false;
  const actual = Buffer.from(fingerprintForKey(key));
  return timingSafeEqual(actual, Buffer.from(expected));
}

function lastLine(text) {
  return text.replace(/[\s\u0000]+$/u, '').split('\n').at(-1) ?? '';
}

// Only a complete final line may be a prompt; prose, indentation and inline '#' are not prompts.
export function findPrompt(text) {
  const line = lastLine(text);
  return PROMPT.test(line) ? line : null;
}

function credentialPrompt(text) {
  const line = lastLine(text).trim();
  if (/^(?:(?:please\s+)?(?:enter|input)\s+)?(?:(?:[\w.-]+)\s+)?(?:login|user\s*name|用户名)\s*[:：]$/i.test(line)) return 'username';
  if (/^(?:(?:please\s+)?(?:enter|input)\s+)?(?:password|口令|密码)\s*[:：]$/i.test(line)) return 'password';
  return null;
}

function needsConfirmation(text) {
  const line = lastLine(text).trim();
  return /(?:\[(?:confirm|(?:y(?:es)?\s*\/\s*n(?:o)?|n(?:o)?\s*\/\s*y(?:es)?)(?:\s*\/\s*cancel)?)\]|\((?:yes\/no|y\/n)\))[\s:：?.]*$/i.test(line)
    || /(?:are you sure|(?:do you want to|please) (?:continue|confirm)|确认|是否继续).*?[?:：]$/i.test(line)
    || /(?:press|hit)\s+(?:enter|return|any key|<enter>|<return>).*(?:continue|confirm)/i.test(line)
    || /(?:destination (?:file\s*name|filename)|overwrite|replace existing).*?[?]$/i.test(line);
}

// Incremental UTF-8/ANSI handling also works when escape sequences span data events.
// This is a readable CLI transcript, not a full-screen terminal emulator.
export class CLIText {
  constructor() {
    this.decoder = new StringDecoder('utf8');
    this.history = '';
    this.line = '';
    this.cursor = 0;
    this.escape = '';
    this.csi = '';
  }

  get text() { return this.history + this.line; }
  get complete() { return !this.escape && this.decoder.lastNeed === 0; }

  push(data) {
    const text = this.decoder.write(Buffer.isBuffer(data) ? data : Buffer.from(data));
    for (const char of text) {
      if (this.escape === 'string' || this.escape === 'string-esc') {
        if (char === '\x07' || (this.escape === 'string-esc' && char === '\\')) this.escape = '';
        else this.escape = char === '\x1b' ? 'string-esc' : 'string';
        continue;
      }
      if (this.escape === 'esc') {
        this.escape = char === '[' ? 'csi' : ']PX^_'.includes(char) ? 'string' : '';
        this.csi = '';
        continue;
      }
      if (this.escape === 'csi') {
        if (char >= '@' && char <= '~') {
          const n = Number.parseInt(this.csi, 10) || 0;
          if (char === 'K') {
            if (n === 2) this.line = '';
            else if (n === 1) this.line = ' '.repeat(Math.min(this.cursor + 1, this.line.length)) + this.line.slice(this.cursor + 1);
            else this.line = this.line.slice(0, this.cursor);
          } else if (char === 'D') this.cursor = Math.max(0, this.cursor - (n || 1));
          else if (char === 'C') this.cursor = Math.min(8192, this.cursor + (n || 1));
          else if (char === 'G') this.cursor = Math.min(8192, Math.max(0, (n || 1) - 1));
          this.escape = '';
          this.csi = '';
        } else if (this.csi.length < 64) this.csi += char;
        continue;
      }
      if (char === '\x1b') { this.escape = 'esc'; continue; }
      if (char === '\u009b') { this.escape = 'csi'; this.csi = ''; continue; }
      if (char === '\u009d') { this.escape = 'string'; continue; }
      if (char === '\r') { this.cursor = 0; continue; }
      if (char === '\n') {
        this.history += `${this.line}\n`;
        this.line = '';
        this.cursor = 0;
        this._checkSize();
        continue;
      }
      if (char === '\b') { this.cursor = Math.max(0, this.cursor - 1); continue; }
      if (char !== '\t' && CONTROL.test(char)) continue;
      if (this.cursor > this.line.length) this.line = this.line.padEnd(this.cursor);
      this.line = this.line.slice(0, this.cursor) + char + this.line.slice(this.cursor + char.length);
      this.cursor += char.length;
      this._checkSize();
    }
    if (Buffer.byteLength(this.text) > MAX_OUTPUT_BYTES) this._tooLarge();
  }

  _checkSize() {
    if (this.history.length + this.line.length > MAX_OUTPUT_BYTES) this._tooLarge();
  }

  _tooLarge() {
    throw problem('OUTPUT_LIMIT', '设备输出超过 1 MiB，已断开并停止后续命令');
  }

  removePager(index) {
    const prefix = this.text.slice(0, index);
    // Isolate subsequent pager erasure/backspaces from the preceding output.
    this.history = prefix.endsWith('\n') || !prefix ? prefix : `${prefix}\n`;
    this.line = '';
    this.cursor = 0;
  }
}

export function cleanCLIOutput(text) {
  const terminal = new CLIText();
  terminal.push(text);
  return terminal.text;
}

async function loadSerialPort() {
  try { return (await import('serialport')).SerialPort; }
  catch { throw problem('DEPENDENCY_MISSING', '串口依赖未就绪，请等待安装完成'); }
}

async function loadSSHClient() {
  try { return (await import('ssh2')).Client; }
  catch { throw problem('DEPENDENCY_MISSING', 'SSH 依赖未就绪，请等待安装完成'); }
}

export async function listSerialPorts() {
  const SerialPort = await loadSerialPort();
  try { return await SerialPort.list(); }
  catch { throw problem('SERIAL_LIST_FAILED', '无法列出本机串口'); }
}

// Keep a transport-only error sink until its actual close; never emit an unhandled 'error'.
// Serial opens are not cancellable: a late successful open is immediately closed, never written to.
function retire(record) {
  const { source, kind } = record;
  if (record.closed || source.closed === true) return Promise.resolve();
  return new Promise((resolve) => {
    const ignore = () => {};
    const finish = () => {
      source.removeListener('error', ignore);
      source.removeListener('close', finish);
      source.removeListener('open', closeSerial);
      source.removeListener('error', openFailed);
      record.openFinished = undefined;
      resolve();
    };
    const closeSerial = () => {
      if (source.isOpen) {
        try { source.close(finish); } catch { finish(); }
      } else if (!source.opening) finish();
    };
    const openFailed = () => { if (!source.isOpen && !source.opening) finish(); };
    source.on('error', ignore);
    source.once('close', finish);
    if (kind === 'serial') {
      record.openFinished = closeSerial;
      if (source.opening) {
        source.once('open', closeSerial);
        source.on('error', openFailed);
      } else closeSerial();
    } else {
      try { source.destroy(); } catch { finish(); }
    }
  });
}

// Dependency seam for fake-client tests. The production API below always loads ssh2 itself.
export function probeSSHWithClient(options, Client) {
  const { host, port, timeoutMs } = endpoint(options);
  return new Promise((resolve, reject) => {
    const client = new Client();
    const record = { source: client, kind: 'ssh', closed: false };
    let candidate;
    let settled = false;
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      void retire(record);
      client.removeListener('error', onError);
      client.removeListener('close', onClose);
      client.removeListener('end', onEnd);
      if (error) reject(error);
      else resolve({ host, port, fingerprint: candidate });
    };
    const onError = () => finish(candidate ? null : problem('SSH_PROBE_FAILED', 'SSH 握手失败，无法获取主机指纹'));
    const onEnd = () => finish(candidate ? null : problem('SSH_PROBE_CLOSED', 'SSH 握手在取得指纹前断开'));
    const onClose = () => { record.closed = true; onEnd(); };
    const timer = setTimeout(() => finish(problem('SSH_PROBE_TIMEOUT', 'SSH 指纹探测超时')), timeoutMs);
    client.on('error', onError).on('close', onClose).on('end', onEnd);
    try {
      client.connect({
        host, port, readyTimeout: timeoutMs,
        // ssh2 requires a string locally. Host rejection occurs BEFORE userauth;
        // neither this empty placeholder nor any credentials are sent to the peer.
        username: '',
        authHandler: () => false,
        hostVerifier(key) {
          if (!settled) {
            candidate = fingerprintForKey(key);
            queueMicrotask(() => finish(null));
          }
          return false;
        },
      });
    } catch { onError(); }
  });
}

export async function probeSSH(options) {
  endpoint(options);
  return probeSSHWithClient(options, await loadSSHClient());
}

export class DeviceConnection extends EventEmitter {
  constructor() {
    super();
    this.info = {};
    this.isConnected = false;
    this._state = 'new';
    this._pending = null;
    this._stream = null;
    this._resources = [];
    this._listeners = [];
    this._queue = Promise.resolve();
    this._failure = null;
    this._closePromise = null;
    this._idle = new CLIText();
    this._idleBytes = 0;
  }

  // Override only these seams in hardware-free tests; production constructor takes no options.
  _loadSerialPort() { return loadSerialPort(); }
  _loadSSHClient() { return loadSSHClient(); }
  get _connectionTimeoutMs() { return 15000; }
  get _maxPages() { return 100; }

  _listen(source, event, listener) {
    source.on(event, listener);
    this._listeners.push(() => source.removeListener(event, listener));
  }

  _track(source, kind) {
    const record = { source, kind, closed: false };
    this._resources.push(record);
    this._listen(source, 'error', () => this._fail(problem('TRANSPORT_ERROR', this._state === 'connecting' ? '登录失败或连接异常，请检查设备及凭据' : '设备连接异常，已停止后续命令')));
    this._listen(source, 'end', () => this._fail(problem('DISCONNECTED', '设备连接已断开，命令未确认完成')));
    this._listen(source, 'close', () => {
      record.closed = true;
      this._fail(problem('DISCONNECTED', '设备连接已断开，命令未确认完成'));
    });
    return record;
  }

  _attachStream(stream) {
    this._stream = stream;
    this._listen(stream, 'data', (data) => this._onData(data));
    if (stream.stderr) {
      this._listen(stream.stderr, 'data', (data) => this._onData(data));
      this._listen(stream.stderr, 'error', () => this._fail(problem('TRANSPORT_ERROR', '设备终端输出异常，已停止后续命令')));
    }
    this._pending.armed = true;
    this._write('\r');
  }

  async connect(options) {
    if (this._state !== 'new') throw problem('CONNECTION_USED', '连接对象已使用；重连请创建新的 DeviceConnection');
    if (!options || !['serial', 'ssh'].includes(options.kind)) throw problem('INVALID_KIND', '连接类型必须是 serial 或 ssh');
    const { baudRate = 9600, dataBits = 8, stopBits = 1, parity = 'none', port = 22 } = options;
    const opts = { ...options, baudRate, dataBits, stopBits, parity, port };
    if (opts.username !== undefined) singleLine(opts.username, '用户名');
    if (opts.password !== undefined) singleLine(opts.password, '密码', true);
    if (opts.kind === 'serial') {
      singleLine(opts.path, '串口路径');
      if (!Number.isInteger(opts.baudRate) || opts.baudRate < 1 || ![5, 6, 7, 8].includes(opts.dataBits)
          || ![1, 1.5, 2].includes(opts.stopBits) || !['none', 'even', 'odd', 'mark', 'space'].includes(opts.parity)) {
        throw problem('INVALID_SERIAL_OPTIONS', '串口参数无效');
      }
      this.info = { kind: 'serial', path: opts.path };
    } else {
      endpoint(opts);
      if (typeof opts.fingerprint !== 'string' || !/^SHA256:[A-Za-z0-9+/]{43}$/.test(opts.fingerprint)) {
        throw problem('FINGERPRINT_REQUIRED', '必须提供人工核对过的精确 SHA256 主机指纹（无尾部等号）');
      }
      if (!opts.username || typeof opts.password !== 'string') throw problem('CREDENTIALS_REQUIRED', 'SSH 登录需要用户名和密码');
      this.info = { kind: 'ssh', host: opts.host, port: opts.port };
    }
    this._state = 'connecting';
    const response = this._begin('login', this._connectionTimeoutMs, { username: opts.username, password: opts.password });
    this.emit('status', { state: 'connecting', ...this.info });
    // The pending promise and all parser state exist before any open/write can respond synchronously.
    void this._open(opts).catch((error) => this._fail(error?.code === 'DEPENDENCY_MISSING' ? error : problem('CONNECT_FAILED', '设备连接或登录失败，请检查连接参数')));
    return response;
  }

  async _open(opts) {
    if (opts.kind === 'serial') {
      const SerialPort = await this._loadSerialPort();
      if (this._state !== 'connecting') return;
      const port = new SerialPort({ path: opts.path, baudRate: opts.baudRate, dataBits: opts.dataBits, stopBits: opts.stopBits, parity: opts.parity, autoOpen: false });
      const record = this._track(port, 'serial');
      port.open((error) => {
        if (this._state !== 'connecting') { record.openFinished?.(); return; }
        if (error) this._fail(problem('SERIAL_OPEN_FAILED', '串口打开失败，请检查端口是否存在、被占用或无权限'));
        else this._attachStream(port);
      });
      return;
    }
    const Client = await this._loadSSHClient();
    if (this._state !== 'connecting') return;
    const client = new Client();
    this._track(client, 'ssh');
    let verified = false;
    let keyboardPasswordSent = false;
    let keyboardUsernameSent = false;
    let challenges = 0;
    const keyboard = (_name, _instructions, _language, prompts, finish) => {
      const answer = (responses) => {
        try { finish(responses); }
        catch { this._fail(problem('SSH_AUTH_FAILED', 'SSH 交互认证失败，已停止登录')); }
      };
      if (this._state !== 'connecting' || !verified) { answer([]); return; }
      if (++challenges > 3 || !Array.isArray(prompts) || prompts.length > 2) {
        this._fail(problem('SSH_INTERACTION', 'SSH 交互认证次数或提示异常，已停止登录'));
        answer([]);
        return;
      }
      const answers = [];
      for (const prompt of prompts) {
        if (!prompt.echo && /^(?:(?:please\s+)?enter\s+)?(?:(?:your|[\w.@-]+['’]s)\s+)?(?:password|密码|口令)\s*[:：]?\s*$/i.test(prompt.prompt) && !keyboardPasswordSent) {
          keyboardPasswordSent = true;
          answers.push(opts.password);
        } else if (prompt.echo && /(?:login|user\s*name)\s*[:：]?\s*$/i.test(prompt.prompt) && !keyboardUsernameSent) {
          keyboardUsernameSent = true;
          answers.push(opts.username);
        } else {
          this._fail(problem('SSH_INTERACTION', 'SSH 需要不支持的交互认证或重复凭据，已停止登录'));
          answer([]);
          return;
        }
      }
      answer(answers);
    };
    this._listen(client, 'keyboard-interactive', keyboard);
    this._listen(client, 'ready', () => {
      if (this._state !== 'connecting') return;
      if (!verified) { this._fail(problem('FINGERPRINT_MISMATCH', 'SSH 主机指纹尚未通过校验')); return; }
      client.removeListener('keyboard-interactive', keyboard);
      const onShell = (error, stream) => {
        if (this._state !== 'connecting') {
          if (stream) void retire({ source: stream, kind: 'stream', closed: false });
          return;
        }
        if (error || !stream) { this._fail(problem('SSH_SHELL_FAILED', 'SSH 登录后无法打开设备终端')); return; }
        this._track(stream, 'stream');
        this._attachStream(stream);
      };
      try { client.shell({ term: 'vt100', cols: 160, rows: 48 }, onShell); }
      catch { this._fail(problem('SSH_SHELL_FAILED', 'SSH 登录后无法打开设备终端')); }
    });
    client.connect({
      host: opts.host, port: opts.port, username: opts.username, password: opts.password,
      readyTimeout: this._connectionTimeoutMs, tryKeyboard: true,
      authHandler: ['password', 'keyboard-interactive'],
      hostVerifier: (key) => {
        if (this._state === 'closed') return false;
        verified = matchesFingerprint(key, opts.fingerprint);
        if (!verified) this._fail(problem('FINGERPRINT_MISMATCH', 'SSH 主机指纹不匹配，已拒绝连接；请重新人工核对'));
        return verified;
      },
    });
  }

  _begin(mode, timeoutMs, credentials) {
    return new Promise((resolve, reject) => {
      const pending = {
        mode, resolve, reject, credentials, terminal: new CLIText(), bytes: 0, pages: 0,
        armed: false, usernameSent: false, passwordSent: false, returnSent: false,
      };
      pending.timer = setTimeout(() => this._fail(problem(mode === 'login' ? 'LOGIN_TIMEOUT' : 'COMMAND_TIMEOUT', mode === 'login' ? '设备登录超时，未识别到 CLI 提示符' : '命令执行超时，结果未确认；已断开并停止后续命令')), timeoutMs);
      this._pending = pending;
    });
  }

  _write(text) {
    if (this._state === 'closed' || !this._stream) return;
    try {
      this._stream.write(text, (error) => {
        if (error) this._fail(problem('WRITE_FAILED', '设备写入失败，已停止后续命令'));
      });
    } catch { this._fail(problem('WRITE_FAILED', '设备写入失败，已停止后续命令')); }
  }

  _onData(data) {
    if (this._state === 'closed') return;
    const pending = this._pending;
    const bytes = Buffer.isBuffer(data) ? data.length : Buffer.byteLength(data);
    if (!pending) {
      this._idleBytes += bytes;
      if (this._idleBytes > MAX_OUTPUT_BYTES) { this._fail(problem('OUTPUT_LIMIT', '设备空闲输出超过 1 MiB，已断开')); return; }
      try { this._idle.push(data); } catch (error) { this._fail(error); return; }
      if (this._idle.complete && (credentialPrompt(this._idle.text) || needsConfirmation(this._idle.text))) {
        this._fail(problem('SESSION_CHANGED', '设备会话进入登录或交互状态，已停止后续命令'));
      }
      return;
    }
    if (!pending.armed) return;
    pending.bytes += bytes;
    if (pending.bytes > MAX_OUTPUT_BYTES) { this._fail(problem('OUTPUT_LIMIT', '设备输出超过 1 MiB，已断开并停止后续命令')); return; }
    try { pending.terminal.push(data); } catch (error) { this._fail(error); return; }
    if (!pending.terminal.complete) return;
    const text = pending.terminal.text;
    if (pending.mode === 'login' && (LOGIN_FAILURE.test(text) || /认证失败|登录失败|用户名或密码错误/.test(text))) {
      this._fail(problem('LOGIN_FAILED', '设备登录失败，请核对用户名、密码及认证策略'));
      return;
    }
    const credential = credentialPrompt(text);
    if (credential) {
      if (pending.mode !== 'login' || this.info.kind !== 'serial') {
        this._fail(problem('UNEXPECTED_LOGIN', '设备意外要求再次登录，已停止后续命令'));
        return;
      }
      if (pending[`${credential}Sent`] || (credential === 'username' && pending.passwordSent)) {
        this._fail(problem('LOGIN_FAILED', '设备重复要求登录凭据，登录失败且不会重试'));
        return;
      }
      const value = pending.credentials[credential];
      if (value === undefined) { this._fail(problem('CREDENTIALS_REQUIRED', `串口设备要求${credential === 'username' ? '用户名' : '密码'}，但未提供登录凭据`)); return; }
      pending[`${credential}Sent`] = true;
      pending.terminal = new CLIText();
      this._write(`${value}\r`);
      return;
    }
    if (needsConfirmation(text)) { this._fail(problem('INTERACTION_REQUIRED', '设备要求交互确认，结果未确认；已断开并停止后续命令')); return; }
    if (pending.mode === 'login' && /(?:press|hit)\s+(?:return|enter|<return>|<enter>)\s+to\s+(?:get started|begin|start)[.!]?\s*$/i.test(text)) {
      if (pending.returnSent) { this._fail(problem('LOGIN_FAILED', '设备重复要求进入终端，登录未完成')); return; }
      pending.returnSent = true;
      pending.terminal = new CLIText();
      this._write('\r');
      return;
    }
    const page = PAGER.exec(text);
    if (page) {
      if (++pending.pages > this._maxPages) { this._fail(problem('PAGING_LIMIT', '设备分页超过安全上限，已断开并停止后续命令')); return; }
      pending.terminal.removePager(page.index);
      this._write(' ');
      return;
    }
    const prompt = findPrompt(text);
    if (pending.mode === 'command' && pending.requireEcho && !pending.echoSeen) {
      pending.echoSeen = text.split('\n').some(line => line.trim() === pending.command || (line.startsWith(pending.startPrompt) && line.slice(pending.startPrompt.length).trim() === pending.command));
    }
    // Configuration requires the exact command echo before accepting a prompt. A late prompt
    // from the preceding operation cannot silently acknowledge a new write.
    if (prompt && (!pending.requireEcho || pending.echoSeen) && !(pending.mode === 'command' && text.trimEnd() === pending.command)) {
      clearTimeout(pending.timer);
      this._pending = null;
      pending.credentials = undefined;
      this.info = { ...this.info, prompt };
      this.isConnected = true;
      this._state = 'connected';
      this._idle = new CLIText();
      this._idleBytes = 0;
      this.emit('status', { state: pending.mode === 'login' ? 'connected' : 'idle', ...this.info });
      pending.resolve(pending.mode === 'login' ? { ...this.info } : text.trimEnd());
    }
  }

  async run(command, { timeoutMs = 15000, requireEcho = false } = {}) {
    singleLine(command, '命令');
    validTimeout(timeoutMs);
    if (!this.isConnected || this._state === 'closed') throw this._failure ?? problem('NOT_CONNECTED', '设备尚未连接');
    const result = this._queue.then(() => {
      if (!this.isConnected || this._state === 'closed') throw this._failure ?? problem('NOT_CONNECTED', '设备连接已关闭，未发送命令');
      this._idle = new CLIText();
      this._idleBytes = 0;
      const response = this._begin('command', timeoutMs);
      this._pending.command = command;
      this._pending.requireEcho = requireEcho;
      this._pending.startPrompt = this.info.prompt || '';
      this._pending.armed = true;
      this.emit('status', { state: 'running', ...this.info });
      this._write(`${command}\r`);
      return response;
    });
    this._queue = result.catch(() => {});
    return result;
  }

  _fail(error) {
    if (this._state === 'closed') return;
    this._failure ??= error;
    this.isConnected = false;
    this.emit('status', { state: 'failed', code: this._failure.code, message: this._failure.message });
    void this._shutdown(this._failure);
  }

  _shutdown(error) {
    if (this._state === 'closed') return this._closePromise ?? Promise.resolve();
    this._state = 'closed';
    this.isConnected = false;
    this._failure ??= error;
    if (this._pending) {
      clearTimeout(this._pending.timer);
      this._pending.credentials = undefined;
      this._pending.reject(error);
      this._pending = null;
    }
    // Install temporary transport error sinks before detaching our active listeners.
    const closing = this._resources.map(retire);
    for (const remove of this._listeners.splice(0)) remove();
    this._resources = [];
    this._stream = null;
    this._idle = new CLIText();
    this._closePromise = Promise.all(closing).then(() => undefined);
    this.emit('status', { state: 'closed' });
    this.emit('close');
    return this._closePromise;
  }

  async close() {
    return this._shutdown(this._failure ?? problem('CONNECTION_CLOSED', '设备连接已关闭，未完成的命令已取消'));
  }
}
