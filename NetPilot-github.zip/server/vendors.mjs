import { isIP } from 'node:net';

// 常见交换机 CLI 子集，不保证所有型号/版本通用。此模块没有网络或执行副作用。
// 发现仅查询已存在的 LLDP/CDP 信息；不自动启用协议。调用者负责授权、备份、
// 预览确认、权限/视图检查及执行失败后的停止，不得直接执行未替换的目录占位符。
export const VENDORS = Object.freeze([
  { id: 'huawei', label: '华为', os: 'VRP', color: '#e53935', versionCommand: 'display version', neighborsCommands: ['display lldp neighbor'], pagingCommand: 'screen-length 0 temporary', backupCommand: 'display current-configuration' },
  { id: 'h3c', label: '新华三', os: 'Comware', color: '#e95513', versionCommand: 'display version', neighborsCommands: ['display lldp neighbor-information verbose'], pagingCommand: 'screen-length 0 temporary', backupCommand: 'display current-configuration' },
  { id: 'ruijie', label: '锐捷', os: 'RGOS', color: '#d92335', versionCommand: 'show version', neighborsCommands: ['show lldp neighbors detail'], pagingCommand: 'terminal length 0', backupCommand: 'show running-config' },
  { id: 'cisco', label: 'Cisco', os: 'IOS / IOS-XE', color: '#0096d6', versionCommand: 'show version', neighborsCommands: ['show lldp neighbors detail', 'show cdp neighbors detail'], pagingCommand: 'terminal length 0', backupCommand: 'show running-config' },
].map((profile) => Object.freeze({ ...profile, neighborsCommands: Object.freeze(profile.neighborsCommands) })));

// 官方资料入口须按具体型号、软件发行版选择命令参考，而非全版本兼容证明。
// 华为入口在本次自动抓取中返回 403；保留官方产品入口，未宣称核实该站正文。
export const SOURCES = Object.freeze([
  { vendor: 'huawei', label: '华为 S5700 官方产品文档入口（按版本查阅）', url: 'https://support.huawei.com/enterprise/en/switches/s5700-pid-6691579' },
  { vendor: 'h3c', label: 'H3C 官方技术文档中心（Comware 命令参考入口）', url: 'https://www.h3c.com/en/Support/Resource_Center/Technical_Documents/' },
  { vendor: 'ruijie', label: '锐捷官方文档中心（按 RGOS 产品和版本筛选）', url: 'https://www.ruijie.com/en-global/resources/products/' },
  { vendor: 'cisco', label: 'Cisco IOS CDP Command Reference', url: 'https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/cdp/command/cdp-cr-book/cdp-cr-a1.html' },
].map(Object.freeze));

const compatibilityNote = '常见交换机语法示例；请按型号、版本、功能许可及权限核对，不涵盖所有版本。';
// 每行的四种命令顺序与 VENDORS 一致。目录命令本身不代表执行授权。
const commandRows = [
  ['version', '系统', '软件版本', ['display version', 'display version', 'show version', 'show version'], '读取设备型号、系统版本及运行时间。'],
  ['config', '系统', '当前配置 / 备份读取', ['display current-configuration', 'display current-configuration', 'show running-config', 'show running-config'], '读取当前配置供本地备份，不执行保存。', 'read', '', '输出可能包含密钥或凭据，需安全保管与脱敏。'],
  ['startup', '系统', '启动配置', ['display saved-configuration', 'display saved-configuration', 'show startup-config', 'show startup-config'], '读取重启时加载的配置。', 'read', '', '输出可能包含敏感信息；不等同于当前配置。'],
  ['clock', '系统', '系统时钟', ['display clock', 'display clock', 'show clock', 'show clock'], '检查设备时间与日志时间基准。'],
  ['cpu', '系统', 'CPU 使用率', ['display cpu-usage', 'display cpu-usage', 'show cpu', 'show processes cpu'], '检查 CPU 负载。'],
  ['memory', '系统', '内存使用率', ['display memory-usage', 'display memory', 'show memory', 'show processes memory'], '检查内存占用。'],
  ['interfaces', '接口', '接口状态摘要', ['display interface brief', 'display interface brief', 'show interfaces status', 'show interfaces status'], '查看交换机端口连接状态。'],
  ['interface', '接口', '接口详细计数', ['display interface <接口>', 'display interface <接口>', 'show interfaces <接口>', 'show interfaces <接口>'], '查看速率、双工、错误及流量计数。'],
  ['ip-interfaces', '接口', '三层接口摘要', ['display ip interface brief', 'display ip interface brief', 'show ip interface brief', 'show ip interface brief'], '查看接口 IPv4 地址和协议状态。'],
  ['vlans', 'VLAN', 'VLAN 列表', ['display vlan', 'display vlan', 'show vlan', 'show vlan brief'], '查看已创建 VLAN 及端口成员。'],
  ['vlan', 'VLAN', '指定 VLAN', ['display vlan <VLAN>', 'display vlan <VLAN>', 'show vlan id <VLAN>', 'show vlan id <VLAN>'], '查看单个 VLAN 的成员信息。'],
  ['mac', '接口', 'MAC 地址表', ['display mac-address', 'display mac-address', 'show mac-address-table', 'show mac address-table'], '定位二层地址所在端口。'],
  ['routes', '路由', 'IPv4 路由表', ['display ip routing-table', 'display ip routing-table', 'show ip route', 'show ip route'], '查看目的网络、下一跳和路由来源。'],
  ['arp', '路由', 'ARP 表', ['display arp', 'display arp', 'show arp', 'show ip arp'], '查看 IPv4 到 MAC 地址的邻接关系。'],
  ['ospf', '路由', 'OSPF 邻居', ['display ospf peer', 'display ospf peer', 'show ip ospf neighbor', 'show ip ospf neighbor'], '查看已配置 OSPF 的邻居状态。', 'read', '', '依赖设备三层能力及已启用的 OSPF 功能。'],
  ['lldp', '邻居', 'LLDP 邻居详情', ['display lldp neighbor', 'display lldp neighbor-information verbose', 'show lldp neighbors detail', 'show lldp neighbors detail'], '只读获取远端名称、端口、机箱标识及通告地址。', 'read', '', '若协议未启用或对端未通告则无数据；不会自动开启 LLDP。'],
  ['lldp-local', '邻居', '本地 LLDP 信息', ['display lldp local', 'display lldp local-information', 'show lldp local-information', 'show lldp local-information'], '查看本地通告信息，不作为远端邻居解析输入。'],
  ['stp', '接口', '生成树状态', ['display stp brief', 'display stp brief', 'show spanning-tree', 'show spanning-tree'], '检查生成树角色及阻塞端口。'],
  ['acl', '安全', '访问控制列表', ['display acl all', 'display acl all', 'show access-lists', 'show access-lists'], '只读查看 ACL 规则与命中情况。'],
  ['ssh', '安全', '远程管理服务状态', ['display ssh server status', 'display ssh server status', 'show service', 'show ip ssh'], '检查 SSH 或管理服务状态。'],
  ['users', '安全', '登录会话', ['display users', 'display users', 'show users', 'show users'], '查看当前登录终端，不断开会话。'],
  ['log', '诊断', '系统日志', ['display logbuffer', 'display logbuffer', 'show logging', 'show logging'], '读取近期日志，排查链路和协议异常。', 'read', '', '输出可能较长且包含敏感运维信息。'],
  ['ping', '诊断', '连通性测试', ['ping -c 5 <IP地址>', 'ping -c 5 <IP地址>', 'ping <IP地址>', 'ping <IP地址>'], '发出 ICMP 探测，不修改持久配置。', 'read', '', '会产生网络探测流量；不是被动发现步骤。'],
  ['traceroute', '诊断', '路径追踪', ['tracert <IP地址>', 'tracert <IP地址>', 'traceroute <IP地址>', 'traceroute <IP地址>'], '探测到目标的三层路径。', 'read', '', '会发送探测报文，耗时取决于目标与超时设置。'],
  ['vlan-create', 'VLAN', '创建 VLAN', ['vlan <VLAN>', 'vlan <VLAN>', 'vlan <VLAN>', 'vlan <VLAN>'], '创建 VLAN 并进入 VLAN 视图。', 'write', 'global', 'VLAN 范围 1–4094，平台保留 VLAN 仍须人工核对。'],
  ['vlan-name', 'VLAN', '设置 VLAN 名称', ['name <名称>', 'name <名称>', 'name <名称>', 'name <名称>'], '设置当前 VLAN 的名称。', 'write', 'vlan'],
  ['access-vlan', 'VLAN', '设置 Access VLAN', ['port default vlan <VLAN>', 'port access vlan <VLAN>', 'switchport access vlan <VLAN>', 'switchport access vlan <VLAN>'], '为当前二层 Access 接口指定 VLAN。', 'write', 'interface', '先确认 VLAN 已存在且接口已处于 Access 模式；可能中断管理流量。'],
  ['trunk-vlan', 'VLAN', '追加 Trunk 放行 VLAN', ['port trunk allow-pass vlan <VLAN列表>', 'port trunk permit vlan <VLAN列表>', 'switchport trunk allowed vlan add <VLAN列表>', 'switchport trunk allowed vlan add <VLAN列表>'], '在 Trunk 接口追加放行 VLAN，不删除既有放行列表。', 'write', 'interface', '华为/H3C 列表使用空格及 to；锐捷/Cisco 使用逗号及短横线。先确认 Trunk 模式。'],
  ['hostname', '系统', '修改设备名称', ['sysname <名称>', 'sysname <名称>', 'hostname <名称>', 'hostname <名称>'], '修改名称及 CLI 提示符。', 'write', 'global', '会改变后续命令提示符匹配；执行器须正确跟踪。'],
  ['shutdown', '接口', '关闭接口', ['shutdown', 'shutdown', 'shutdown', 'shutdown'], '管理性关闭当前接口。', 'danger', 'interface', '可能导致业务或管理连接中断；必须单独预览确认。'],
  ['save', '系统', '保存启动配置', ['save', 'save', 'write', 'write memory'], '把当前运行配置写入启动配置。', 'danger', 'global', '自动化执行默认禁止 save/write；需人工在终端确认后再保存。'],
  ['ntp', '系统', 'NTP 同步状态', ['display ntp-service status', 'display ntp-service status', 'show ntp status', 'show ntp status'], '检查时间同步状态与时钟源。', 'read', '', '时间偏差会影响日志与证书校验。'],
  ['snmp', '安全', 'SNMP 配置摘要', ['display snmp-agent sys-info', 'display snmp-agent sys-info', 'show snmp', 'show snmp'], '查看 SNMP 版本、团体名与 Trap 目标。', 'read', '', '输出可能包含团体名，导出前需脱敏。'],
  ['dhcp-snooping', '安全', 'DHCP Snooping 状态', ['display dhcp snooping', 'display dhcp snooping', 'show ip dhcp snooping', 'show ip dhcp snooping binding'], '查看信任端口与绑定表。', 'read', '', '仅在已部署 DHCP Snooping 的设备上有数据。'],
  ['port-security', '安全', '端口安全状态', ['display port-security', 'display port-security', 'show port-security', 'show port-security'], '查看端口安全策略与违规计数。', 'read', '', '依赖设备是否支持并启用了端口安全。'],
  ['vrrp', '路由', 'VRRP 备份组', ['display vrrp brief', 'display vrrp brief', 'show vrrp brief', 'show vrrp brief'], '查看虚拟路由器角色与优先级。', 'read', '', '仅三层设备且已配置 VRRP 时有输出。'],
  ['aggregation', '接口', '链路聚合状态', ['display eth-trunk', 'display link-aggregation verbose', 'show aggregateport summary', 'show etherchannel summary'], '查看聚合组成员端口与协商状态。', 'read', '', '不同型号聚合组编号与上限不同。'],
  ['transceiver', '接口', '光模块信息', ['display transceiver interface', 'display transceiver interface', 'show interfaces transceiver', 'show interfaces transceiver'], '查看光模块型号、波长与收发光功率。', 'read', '', '仅光口有数据；部分低端型号不支持。'],
  ['poe', '接口', 'PoE 供电状态', ['display poe power', 'display poe power', 'show poe', 'show power inline'], '查看端口供电功率与预算。', 'read', '', '仅 PoE 型号支持。'],
  ['interface-description', '接口', '设置接口描述', ['description <描述>', 'description <描述>', 'description <描述>', 'description <描述>'], '给当前接口写入可读描述。', 'write', 'interface', '描述不能包含空格以外的特殊字符；建议使用 ASCII。'],
  ['stp-edge', '接口', '配置边缘端口', ['stp edged-port enable', 'stp edged-port', 'spanning-tree portfast', 'spanning-tree portfast'], '把接终端的端口设为边缘端口，跳过监听学习。', 'write', 'interface', '接交换机或集线器的端口不要开启，可能引起环路。'],
  ['bpdu-protection', '安全', 'BPDU 保护', ['stp bpdu-protection', 'stp bpdu-protection', 'spanning-tree bpduguard enable', 'spanning-tree bpduguard enable'], '收到 BPDU 时自动关闭边缘端口。', 'write', 'global', '误配会导致接交换机的端口被 err-disable / down。'],
  ['static-route', '路由', '配置静态路由', ['ip route-static <目的网段> <掩码> <下一跳>', 'ip route-static <目的网段> <掩码> <下一跳>', 'ip route <目的网段> <掩码> <下一跳>', 'ip route <目的网段> <掩码> <下一跳>'], '添加一条 IPv4 静态路由。', 'write', 'global', '下一跳必须三层可达；错误默认路由会导致管理中断。'],
  ['acl-rule', '安全', '新增 ACL 规则', ['rule <序号> permit source <源地址> <通配符>', 'rule <序号> permit source <源地址> <通配符>', 'permit <源地址> <通配符>', 'permit <源地址> <通配符>'], '在已存在的 ACL 中追加放行规则。', 'write', '', '需先创建 ACL；通配符与掩码语义相反。'],
  ['ssh-enable', '安全', '启用 SSH 服务', ['stelnet server enable', 'ssh server enable', 'enable service ssh-server', 'ip ssh version 2'], '开启 SSH 远程管理。', 'write', 'global', '开启后仍需配置本地用户与权限级别。'],
  ['ntp-server', '系统', '配置 NTP 服务器', ['ntp-service unicast-server <IP地址>', 'ntp-service unicast-server <IP地址>', 'ntp server <IP地址>', 'ntp server <IP地址>'], '指定上游时间源。', 'write', 'global', '需要管理地址能路由到该 NTP 服务器。'],
  ['syslog-host', '诊断', '配置日志服务器', ['info-center loghost <IP地址>', 'info-center loghost <IP地址>', 'logging <IP地址>', 'logging <IP地址>'], '把系统日志发往远端 Syslog。', 'write', 'global', '发送前确认日志服务器已就绪，避免日志丢失。'],
  ['lldp-enable', '邻居', '启用 LLDP', ['lldp enable', 'lldp enable', 'lldp enable', 'lldp run'], '全局开启 LLDP，供拓扑发现使用。', 'write', 'global', 'Cisco 需在全局开启后再按接口 lldp transmit/receive。'],
  ['inventory', '系统', '硬件清单与序列号', ['display device manuinfo', 'display device manuinfo', 'show version', 'show inventory'], '读取序列号、制造信息与模块清单。', 'read', '', '序列号属于资产信息，导出前请评估。'],
  ['startup-file', '系统', '下次启动配置文件', ['display startup', 'display startup', 'show boot', 'show boot'], '查看下次启动使用的配置/镜像文件。', 'read', '', '与当前运行配置可能不同；修改启动文件属于高风险操作。'],
  ['license', '系统', 'License 授权信息', ['display license', 'display license', 'show license', 'show license'], '查看已激活的功能授权与到期状态。', 'read', '', '部分型号无 License 概念，命令可能不识别。'],
  ['temperature', '系统', '温度与风扇', ['display temperature all', 'display environment temperature', 'show temperature', 'show environment temperature'], '读取各单板温度，判断散热是否正常。', 'read', '', '阈值随型号差异较大，以设备手册为准。'],
  ['fan', '系统', '风扇状态', ['display fan', 'display fan', 'show fan', 'show environment fan'], '查看风扇转速与在位状态。', 'read', '', '仅机框式或带风扇模块的型号有数据。'],
  ['power-supply', '系统', '电源模块', ['display power', 'display power', 'show power', 'show environment power'], '查看电源在位、功率与冗余状态。', 'read', '', '双电源机型需确认两路都正常。'],
  ['stack', '系统', '堆叠 / IRF / VSU 状态', ['display stack', 'display irf', 'show switch virtual', 'show switch'], '查看成员编号、主备角色与堆叠链路。', 'read', '', '华为叫堆叠，华三叫 IRF，锐捷叫 VSU，Cisco 叫 StackWise。'],
  ['bfd', '路由', 'BFD 会话', ['display bfd session all', 'display bfd session', 'show bfd neighbors', 'show bfd neighbors'], '查看双向转发检测会话与抖动。', 'read', '', '仅已配置 BFD 的设备有会话。'],
  ['interface-counters', '接口', '接口流量与错误计数', ['display interface counters', 'display counters', 'show interfaces counters', 'show interfaces counters'], '查看各端口收发包、错包与丢弃计数。', 'read', '', '建议配合接口详细命令一起看。'],
  ['mac-aging', '接口', 'MAC 老化时间', ['mac-address aging-time <秒>', 'mac-address aging-time <秒>', 'mac-address-table aging-time <秒>', 'mac address-table aging-time <秒>'], '调整动态 MAC 表项老化时间。', 'write', 'global', '过短会加剧泛洪，过长会占满表项。'],
  ['mac-static', '接口', '静态 MAC 绑定', ['mac-address static <MAC地址> vlan <VLAN> interface <接口>', 'mac-address static <MAC地址> vlan <VLAN> interface <接口>', 'mac-address static <MAC地址> vlan <VLAN> interface <接口>', 'mac address-table static <MAC地址> vlan <VLAN> interface <接口>'], '把指定 MAC 固定到端口。', 'write', 'global', '接口必须是二层物理口或聚合口；换口后需重新绑定。'],
  ['port-isolate', '接口', '端口隔离', ['port-isolate enable', 'port-isolate enable', 'switchport protected', 'switchport protected'], '同 VLAN 内端口互相隔离，只与上行口通信。', 'write', 'interface', '隔离组编号与上行口策略随型号不同。'],
  ['storm-control', '接口', '广播风暴抑制', ['storm-control broadcast min-rate <阈值>', 'storm-control broadcast min-rate <阈值>', 'storm-control broadcast level <阈值>', 'storm-control broadcast level <阈值>'], '限制广播报文速率，防止环路打满。', 'write', 'interface', '阈值单位与百分比/pps 语义按厂商区分，先小范围验证。'],
  ['port-channel', '接口', '创建聚合接口', ['interface Eth-Trunk <编号>', 'interface Bridge-Aggregation <编号>', 'interface AggregatePort <编号>', 'interface Port-channel <编号>'], '新建链路聚合逻辑接口。', 'write', 'global', '成员口速率双工必须一致；跨设备聚合需堆叠支持。'],
  ['lacp', '接口', '加入 LACP 聚合组', ['mode lacp-static', 'link-aggregation mode dynamic', 'port-group <编号>', 'channel-group <编号> mode active'], '把当前物理口加入动态聚合组。', 'write', 'interface', '两端模式需匹配；静态模式对接动态模式通常可协商。'],
  ['lldp-statistics', '邻居', 'LLDP 统计', ['display lldp statistics', 'display lldp statistics', 'show lldp statistics', 'show lldp traffic'], '查看 LLDP 报文收发与丢弃计数。', 'read', '', '计数长期为 0 说明协议未启用或对端未发。'],
  ['vlan-interface', 'VLAN', '创建 VLAN 三层接口', ['interface Vlanif <VLAN>', 'interface Vlan-interface <VLAN>', 'interface Vlan <VLAN>', 'interface Vlan <VLAN>'], '进入 VLAN 三层接口视图配置网关地址。', 'write', 'global', 'VLAN 必须先创建；地址冲突会导致管理中断。'],
  ['interface-ip', '接口', '配置接口 IP 地址', ['ip address <IP地址> <掩码>', 'ip address <IP地址> <掩码>', 'ip address <IP地址> <掩码>', 'ip address <IP地址> <掩码>'], '给当前三层接口配置 IPv4 地址。', 'write', 'interface', '修改管理地址会立即断开当前会话。'],
  ['voice-vlan', 'VLAN', '语音 VLAN', ['voice-vlan <VLAN> enable', 'voice vlan <VLAN>', 'voice vlan <VLAN>', 'switchport voice vlan <VLAN>'], '把 IP 话机流量划入独立 VLAN。', 'write', 'interface', '需先在全局创建语音 VLAN 并配置 QoS 信任。'],
  ['qinq', 'VLAN', 'QinQ 双层标签', ['port link-type dot1q-tunnel', 'port link-type dot1q-tunnel', 'switchport mode dot1q-tunnel', 'switchport mode dot1q-tunnel'], '把接口设为 QinQ 接入，外层打运营商 VLAN。', 'write', 'interface', '会改变报文封装，必须与运营商侧确认。'],
  ['default-route', '路由', '配置默认路由', ['ip route-static 0.0.0.0 0.0.0.0 <下一跳>', 'ip route-static 0.0.0.0 0.0.0.0 <下一跳>', 'ip route 0.0.0.0 0.0.0.0 <下一跳>', 'ip route 0.0.0.0 0.0.0.0 <下一跳>'], '添加默认路由指向网关。', 'write', 'global', '下一跳不可达会导致流量黑洞，先确认直连可达。'],
  ['arp-static', '路由', '静态 ARP 绑定', ['arp static <IP地址> <MAC地址>', 'arp static <IP地址> <MAC地址>', 'arp <IP地址> <MAC地址> arpa', 'arp <IP地址> <MAC地址> arpa'], '把 IP 与 MAC 固定绑定，防止 ARP 欺骗。', 'write', 'global', '终端换网卡后需同步更新，否则不通。'],
  ['ospf-interface', '路由', 'OSPF 接口状态', ['display ospf interface', 'display ospf interface', 'show ip ospf interface brief', 'show ip ospf interface brief'], '查看接口所属区域、开销与邻居数。', 'read', '', '仅已启用 OSPF 的设备有输出。'],
  ['ospf-config', '路由', '启用 OSPF 进程', ['ospf <进程号>', 'ospf <进程号>', 'router ospf <进程号>', 'router ospf <进程号>'], '创建 OSPF 进程并进入配置视图。', 'write', 'global', '还需宣告网段；错误宣告可能引起路由环路。'],
  ['bgp-summary', '路由', 'BGP 邻居摘要', ['display bgp peer', 'display bgp peer', 'show ip bgp summary', 'show ip bgp summary'], '查看 BGP 邻居状态与收发的路由数。', 'read', '', '仅运行 BGP 的设备有输出。'],
  ['bgp-config', '路由', '启用 BGP 进程', ['bgp <AS号>', 'bgp <AS号>', 'router bgp <AS号>', 'router bgp <AS号>'], '创建 BGP 进程并进入配置视图。', 'write', 'global', 'AS 号与对端必须匹配，误配会导致邻居震荡。'],
  ['vrrp-config', '路由', '配置 VRRP 备份组', ['vrrp vrid <备份组> virtual-ip <虚拟IP>', 'vrrp vrid <备份组> virtual-ip <虚拟IP>', 'vrrp <备份组> ip <虚拟IP>', 'vrrp <备份组> ip <虚拟IP>'], '在三层接口上启用 VRRP 网关冗余。', 'write', 'interface', '两端 vrid 与虚拟 IP 必须一致，优先级决定主备。'],
  ['acl-create', '安全', '创建 ACL', ['acl number <ACL编号>', 'acl number <ACL编号>', 'access-list <ACL编号>', 'access-list <ACL编号>'], '创建基本/高级访问控制列表。', 'write', 'global', '华为/华三 2000-2999 为基本，3000-3999 为高级。'],
  ['acl-apply', '安全', '接口应用 ACL', ['traffic-filter inbound acl <ACL编号>', 'packet-filter <ACL编号> inbound', 'ip access-group <ACL编号> in', 'ip access-group <ACL编号> in'], '把 ACL 应用到接口入方向。', 'write', 'interface', '误拦管理流量会立刻失去连接，先放行管理网段。'],
  ['port-security-config', '安全', '启用端口安全', ['port-security enable', 'port-security enable', 'port-security enable', 'switchport port-security'], '开启端口安全，限制学习到的 MAC 数量。', 'write', 'global', 'Cisco 需在接口下配置；违规动作默认 shutdown。'],
  ['dhcp-snooping-config', '安全', '启用 DHCP Snooping', ['dhcp snooping enable', 'dhcp snooping enable', 'ip dhcp snooping', 'ip dhcp snooping'], '开启 DHCP Snooping 防私接服务器。', 'write', 'global', '必须把上行口设为信任口，否则客户端拿不到地址。'],
  ['dot1x', '安全', '802.1X 认证状态', ['display dot1x', 'display dot1x', 'show dot1x', 'show dot1x'], '查看认证端口、在线用户与失败计数。', 'read', '', '仅已部署 802.1X 的设备有数据。'],
  ['radius', '安全', 'RADIUS 服务器配置', ['display radius-server configuration', 'display radius scheme', 'show radius-server', 'show radius server'], '查看认证/计费服务器地址与共享密钥状态。', 'read', '', '共享密钥不会明文回显，属正常现象。'],
  ['stp-mode', '接口', '生成树模式', ['stp mode rstp', 'stp mode rstp', 'spanning-tree mode rstp', 'spanning-tree mode rapid-pvst'], '切换生成树协议模式。', 'write', 'global', '全网模式必须一致，混用可能造成环路。'],
  ['stp-root', '接口', '指定根桥', ['stp root primary', 'stp root primary', 'spanning-tree priority 4096', 'spanning-tree vlan 1 root primary'], '把本设备设为生成树根桥。', 'write', 'global', '核心双机建议一主一备，避免抢占震荡。'],
  ['qos-queue', '接口', 'QoS 队列统计', ['display qos queue statistics interface <接口>', 'display qos queue-statistics interface <接口>', 'show mls qos interface <接口> statistics', 'show mls qos interface <接口> statistics'], '查看各优先级队列的收发与丢弃。', 'read', '', '需先启用 QoS；字段随型号差异较大。'],
  ['igmp-snooping', '路由', 'IGMP Snooping 状态', ['display igmp-snooping', 'display igmp-snooping', 'show ip igmp snooping', 'show ip igmp snooping'], '查看组播组与成员端口。', 'read', '', '仅部署组播业务的网络有数据。'],
  ['debugging', '诊断', '当前调试开关', ['display debugging', 'display debugging', 'show debugging', 'show debugging'], '查看已开启的调试项，避免误开影响性能。', 'read', '', '生产环境不建议开启调试，可能打满 CPU。'],
  ['tech-support', '诊断', '一键诊断信息', ['display diagnostic-information', 'display diagnostic-information', 'show tech-support', 'show tech-support'], '一次性采集版本、配置与运行状态。', 'read', '', '输出很长（可能数万行），执行前确认终端超时。'],
  ['trunk-only', 'VLAN', 'Trunk 精确放行（覆盖）', ['port trunk allow-pass vlan <VLAN列表>', 'port trunk permit vlan <VLAN列表>', 'switchport trunk allowed vlan only <VLAN列表>', 'switchport trunk allowed vlan <VLAN列表>'], '用指定列表整体覆盖 Trunk 放行 VLAN。', 'write', 'interface', '锐捷的 only 与 Cisco 的无关键字写法会清掉原有列表，务必先备份。'],
  ['trunk-remove', 'VLAN', 'Trunk 移除放行 VLAN', ['undo port trunk allow-pass vlan <VLAN列表>', 'undo port trunk permit vlan <VLAN列表>', 'switchport trunk allowed vlan remove <VLAN列表>', 'switchport trunk allowed vlan remove <VLAN列表>'], '从 Trunk 放行列表里移除指定 VLAN。', 'write', 'interface', '移除本征或管理 VLAN 会立即断开链路。'],
  ['rldp', '接口', '环路 / 单向链路检测', ['loopback-detect enable', 'loopback-detection enable', 'rldp enable', 'udld enable'], '开启环路或单向链路检测，防止二层环路。', 'write', 'global', '锐捷为 RLDP，华三为 loopback-detection，Cisco 用 UDLD；动作与恢复时间需按厂商单独配置。'],
  ['dhcp-trust', '安全', 'DHCP Snooping 信任口', ['dhcp snooping trusted', 'dhcp snooping trust', 'ip dhcp snooping trust', 'ip dhcp snooping trust'], '把上行口设为信任口，允许其下发 DHCP 应答。', 'write', 'interface', '必须先全局开启 DHCP Snooping；信任口设错会导致终端拿不到地址。'],
  ['dhcp-relay', '路由', 'DHCP 中继', ['dhcp select relay', 'dhcp select relay', 'ip helper-address <DHCP服务器>', 'ip helper-address <DHCP服务器>'], '把本网段 DHCP 请求转发到远端服务器。', 'write', 'interface', '华为/华三还需在接口下指定 relay server-ip 或 server-address。'],
  ['floating-route', '路由', '浮动静态路由', ['ip route-static 0.0.0.0 0.0.0.0 <下一跳> preference <优先级>', 'ip route-static 0.0.0.0 0.0.0.0 <下一跳> preference <优先级>', 'ip route 0.0.0.0 0.0.0.0 <下一跳> <管理距离>', 'ip route 0.0.0.0 0.0.0.0 <下一跳> <管理距离>'], '配置备份默认路由，主链路故障时自动切换。', 'write', 'global', '数值越大越不优先；华为/华三叫 preference，锐捷/Cisco 叫管理距离。'],
  ['ospf-passive', '路由', 'OSPF 静默接口', ['silent-interface <接口>', 'silent-interface <接口>', 'passive-interface <接口>', 'passive-interface <接口>'], '接口不发送 OSPF 报文，只宣告网段。', 'write', 'global', '需在 OSPF 进程视图下配置，接终端的接口建议静默。'],
];

function commandMode(vendor, view) {
  const vrpStyle = vendor === 'huawei' || vendor === 'h3c';
  if (view === 'global') return vrpStyle ? '系统视图' : '全局配置模式';
  if (view === 'interface') return vrpStyle ? '接口视图' : '接口配置模式';
  if (view === 'vlan') return vrpStyle ? 'VLAN 视图' : 'VLAN 配置模式';
  return vrpStyle ? '用户视图（需相应权限）' : '特权 EXEC';
}

export const COMMANDS = Object.freeze([
  ...VENDORS.flatMap(({ id: vendor }, index) => commandRows.map(([id, category, title, commands, description, risk = 'read', view = '', notes = '']) => Object.freeze({
    id: `${vendor}-${id}`, vendor, category, title, command: commands[index], description,
    mode: commandMode(vendor, view), risk, notes: `${notes}${notes ? ' ' : ''}${compatibilityNote}`,
  }))),
  Object.freeze({ id: 'cisco-cdp', vendor: 'cisco', category: '邻居', title: 'CDP 邻居详情', command: 'show cdp neighbors detail', description: '只读获取已发现的 CDP 邻居。', mode: '特权 EXEC', risk: 'read', notes: `不自动启用 CDP。${compatibilityNote}` }),
]);

export function vendorProfile(id) {
  const profile = VENDORS.find((item) => item.id === id);
  if (!profile) throw new RangeError('不支持的厂商 ID');
  return profile;
}

function supportedVendor(id) {
  return VENDORS.some((profile) => profile.id === id);
}

function cleanText(text) {
  if (typeof text !== 'string') return '';
  // 仅清理传输格式，不从任意文本猜 IP；终端解析不执行收到的控制序列。
  const plain = text
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, '')
    .replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '')
    .replace(/\r\n?/g, '\n');
  const chars = [];
  for (const char of plain) {
    if (char === '\b') {
      if (chars.at(-1) !== '\n') chars.pop();
    } else if (char === '\n' || char === '\t' || char >= ' ') {
      chars.push(char);
    }
  }
  return chars.join('').replace(/-{2,}\s*More\s*-{2,}(?:\s*\([^\n)]*\))?/gi, '');
}

const promptLine = /^(?:<[^<>\n]+>|\[[^\]\n]+\]|[\w.:/-]+(?:\([^()\n]+\))?[#>])\s*(.*)$/;
const echoLine = /^(?:display|show|screen-length|terminal\s+length)\b/i;
const errorLine = /^(?:%|Error\s*:|Unrecognized command\b|Invalid (?:input|command)\b|Incomplete command\b|Wrong parameter\b|Info\s*:.*(?:not enabled|disabled|no neighbor))/i;
const neighborStart = /^(?:LLDP\s+neighbor|Local\s+(?:Intf|Interface|Port)\s*:|Chassis\s*ID\s*:|Device\s*ID\s*:|\S+\s+has\s+\d+\s+neighbor)/i;

function deviceBody(text) {
  const lines = [];
  for (const raw of cleanText(text).split('\n')) {
    const line = raw.trim();
    const prompt = line.match(promptLine);
    const command = prompt ? prompt[1] : line;
    // 拼接多个发现命令时，远端系统描述不能覆盖本机身份。
    if (/^(?:display|show)\s+(?:lldp|cdp)\b/i.test(command) || neighborStart.test(line)) break;
    if (!line || prompt || echoLine.test(line) || errorLine.test(line)) continue;
    lines.push(line);
  }
  return lines.join('\n');
}

export function detectVendor(text) {
  const body = deviceBody(text);
  // OS 特征优先于版权/品牌字符串；历史 Huawei-3Com 和 Comware 不属于 VRP。
  if (/\bComware\b|\bHuawei[- ]3Com\b/i.test(body)) return 'h3c';
  if (/\bVRP\b|Versatile Routing Platform/i.test(body)) return 'huawei';
  if (/\bRGOS\b/i.test(body)) return 'ruijie';
  if (/\bCisco\s+(?:IOS(?:[- ]XE)?|Internetwork Operating System)\b|\bIOS\s*\(tm\)/i.test(body)) return 'cisco';
  if (/\bH3C\b/i.test(body)) return 'h3c';
  if (/\bHuawei\b|\bQuidway\b/i.test(body)) return 'huawei';
  if (/\bRuijie\b/i.test(body)) return 'ruijie';
  if (/\bCisco\b/i.test(body)) return 'cisco';
  return 'unknown';
}

function trailingHostname(text) {
  const line = cleanText(text).trim().split('\n').at(-1)?.trim() || '';
  let match = line.match(/^<([\w.-]+)>$/);
  if (match) return match[1];
  match = line.match(/^\[([~*]?)([\w./:-]+)\]$/);
  if (match) {
    // 只删除已知视图后缀，不能简单按 '-' 截断合法主机名。
    return match[2].replace(/-(?:(?:GigabitEthernet|XGigabitEthernet|Ten-GigabitEthernet|Ethernet|GE|XGE|\d+GE|Eth-Trunk|Bridge-Aggregation|Vlanif|Vlan-interface|vlan)\d[\w/.-]*|aaa|sys|system-view)$/i, '');
  }
  match = line.match(/^([\w.-]+)(?:\(config[^()]*\))?[#>]$/);
  return match?.[1] || '';
}

function firstCapture(text, patterns) {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return match[1].trim();
  }
  return '';
}

export function parseDevice(text, vendor) {
  const body = deviceBody(text);
  const name = trailingHostname(text) || firstCapture(body, [
    /^(?:sysname|hostname)\s+([\w.-]+)$/im,
    /^([\w.-]+) uptime is\b/im,
    /^System\s+name\s*:\s*([^\n]+)$/im,
  ]);
  if (!supportedVendor(vendor)) return { name, model: '', version: '' };
  let model = firstCapture(body, [/^(?:Device\s+model|Model(?:\s+(?:number|name))?|Product\s+model)\s*:\s*([\w.+/-]+)\b/im]);
  let version = '';
  if (vendor === 'huawei') {
    model ||= firstCapture(body, [
      /^(?:HUAWEI|Quidway)\s+([\w.-]+)(?:\s+(?:Routing\s+)?Switch)?\s+uptime\b/im,
      /^VRP[^\n]*\(([A-Z]+\d[\w-]*)\s+V\d/im,
    ]);
    version = firstCapture(body, [/^VRP[^\n]*?\bVersion\s+([^\n]+)/im]);
  } else if (vendor === 'h3c') {
    model ||= firstCapture(body, [/^(?:H3C|Huawei-3Com)\s+([\w.-]+)(?:\s+Switch)?\s+uptime\b/im]);
    version = firstCapture(body, [/^[^\n]*\bComware\s+(?:Software,?\s*)?Version\s+([^\n]+)/im]);
  } else if (vendor === 'ruijie') {
    model ||= firstCapture(body, [/\b(RG-[A-Z0-9][A-Z0-9()._-]*)\b/i]);
    version = firstCapture(body, [
      /^System\s+software\s+version\s*:\s*([^\n]+)/im,
      /^(?:Ruijie[^\n]*?\b)?RGOS[^\n]*?\bVersion\s*:?\s*([^\n]+)/im,
    ]);
  } else {
    model ||= firstCapture(body, [/^PID\s*:\s*([\w.-]+)/im, /^cisco\s+([\w.-]+)\s+\([^\n]*\)\s+processor\b/im]);
    version = firstCapture(body, [
      /^Cisco IOS(?:[- ]XE| XE)? Software[^\n]*?\bVersion\s+([^\n,]+)/im,
      /^IOS\s*\(tm\)[^\n]*?\bVersion\s+([^\n,]+)/im,
    ]);
  }
  return { name, model, version };
}

function fieldValue(value) {
  const trimmed = value.trim();
  return /^(?:[-]+|not (?:advertised|available)|n\/?a|none|null|unknown)$/i.test(trimmed) ? '' : trimmed;
}

function advertisedIp(value) {
  // 只在明确地址字段或地址节内调用。绝不从描述、Chassis ID 或任意数字提取。
  return value.split(/[\s,()[\]]+/).filter((part) => isIP(part) && part !== '0.0.0.0' && part !== '::');
}

/**
 * 解析常见英文详细输出，不解析 brief 表格或所有本地化/版本变体。
 * 缺失值为空字符串；不按名称、IP 或 chassis 合并，保留端口及协议维度。
 * 单地址契约：管理节优先于 CDP entry 地址，同一优先级优先 IPv4。
 */
export function parseNeighbors(text, vendor) {
  if (!supportedVendor(vendor)) return [];
  const neighbors = [];
  let current = null;
  let sectionPort = '';
  let addressSection = '';
  let inDescription = false;
  let suppress = false;

  function start(protocol = 'LLDP') {
    current = { name: '', chassisId: '', managementIp: '', localPort: sectionPort, remotePort: '', description: '', protocol, ipRank: 0, platform: '' };
    return current;
  }
  function flush() {
    if (current && (current.name || current.chassisId) && (current.localPort || current.remotePort)) {
      const { ipRank, platform, ...neighbor } = current;
      neighbor.description ||= platform;
      neighbors.push(neighbor);
    }
    current = null;
    addressSection = '';
    inDescription = false;
  }
  function setIp(value) {
    if (!current || !addressSection) return;
    for (const ip of advertisedIp(value)) {
      const rank = (addressSection === 'management' ? 4 : 2) + (isIP(ip) === 4 ? 1 : 0);
      if (rank > current.ipRank) {
        current.managementIp = ip;
        current.ipRank = rank;
      }
    }
  }

  for (const raw of cleanText(text).split('\n')) {
    const line = raw.trim();
    if (!line) continue;
    if (promptLine.test(line) || echoLine.test(line)) {
      flush();
      sectionPort = '';
      suppress = false;
      continue;
    }
    if (errorLine.test(line)) {
      // 错误后的帮助文本不能成为邻居，但保留之前成功命令的记录。
      current = null;
      sectionPort = '';
      addressSection = '';
      inDescription = false;
      suppress = true;
      continue;
    }
    if (suppress) continue;
    if (/^[-=]{3,}$/.test(line) || /^(?:Total (?:entries|neighbors)|Number of (?:entries|neighbors))/i.test(line)) {
      flush();
      continue;
    }
    let match = line.match(/^(.+?)\s+has\s+\d+\s+neighbors?(?:\(s\))?\s*:/i)
      || line.match(/^LLDP\s+neighbor-information\s+of\s+port\s+(?:\d+\s*)?\[([^\]]+)\]\s*:/i)
      || line.match(/^LLDP\s+neighbors?\s+on\s+(?:interface|port)\s+(.+?)\s*:/i);
    if (match) {
      flush();
      sectionPort = match[1].trim();
      continue;
    }
    if (/^(?:LLDP\s+)?Neighbor\s+(?:index|\d+)\s*:?/i.test(line)) {
      const port = current?.localPort || sectionPort;
      flush();
      start().localPort = port;
      continue;
    }
    match = line.match(/^Device\s*ID\s*:\s*(.*)$/i);
    if (match && vendor === 'cisco') {
      flush();
      sectionPort = '';
      start('CDP').name = fieldValue(match[1]);
      if (/^(?:[\da-f]{4}(?:[.-][\da-f]{4}){2}|[\da-f]{2}(?:[:-][\da-f]{2}){5})$/i.test(current.name)) {
        current.chassisId = current.name;
      }
      continue;
    }
    match = line.match(/^Interface\s*:\s*(.+?),\s*Port\s*ID\s*\(outgoing port\)\s*:\s*(.*)$/i);
    if (match && current?.protocol === 'CDP') {
      current.localPort = fieldValue(match[1]);
      current.remotePort = fieldValue(match[2]);
      addressSection = '';
      inDescription = false;
      continue;
    }
    match = line.match(/^Local\s*(?:Intf|Interface|Port(?:\s*ID)?)\s*:\s*(.*)$/i)
      || (vendor === 'ruijie' && line.match(/^(?:Interface|Port)\s*:\s*(.*)$/i));
    if (match) {
      // Cisco/RGOS 每个 Local Intf 开启独立记录，不继承上一个端口。
      flush();
      sectionPort = '';
      start().localPort = fieldValue(match[1]);
      continue;
    }

    const field = line.match(/^([^:]{1,80}?)\s*:\s*(.*)$/);
    const key = field?.[1].toLowerCase().replace(/[\s_()/-]/g, '') || '';
    const value = field?.[2] || '';
    if (key === 'chassisid') {
      if (current?.chassisId) flush();
      (current || start()).chassisId = fieldValue(value);
    } else if (key === 'portid' || key === 'remoteport') {
      (current || start()).remotePort = fieldValue(value);
    } else if (key === 'systemname' || key === 'sysname') {
      (current || start()).name = fieldValue(value);
    } else if (key === 'systemdescription' || key === 'sysdescr' || (key === 'version' && current?.protocol === 'CDP')) {
      (current || start()).description = fieldValue(value);
      inDescription = true;
      addressSection = '';
      continue;
    } else if (/^(?:management(?:address(?:es)?|ip|ipv[46]address)|mgmtaddress)$/.test(key)) {
      addressSection = 'management';
      inDescription = false;
      setIp(value);
      continue;
    } else if (key === 'entryaddresses' && current?.protocol === 'CDP') {
      addressSection = 'entry';
      inDescription = false;
      setIp(value);
      continue;
    } else if (/^(?:ip|ipv[46])(?:address)?$/.test(key) && addressSection) {
      setIp(value);
      continue;
    } else if (addressSection && advertisedIp(line).length && (!field || isIP(line))) {
      setIp(line);
      continue;
    } else if (key === 'platform' && current?.protocol === 'CDP') {
      current.platform = value.replace(/,\s*Capabilities\s*:.*$/i, '').trim();
    } else if (inDescription && (key === 'technicalsupport' || (!field && !/^(?:Auto Negotiation|Physical media|Media attachment|LLDP agent|System capabilities|Enabled capabilities|Time remaining|Time to live)\b/i.test(line)))) {
      current.description += `${current.description ? '\n' : ''}${line}`;
      continue;
    }
    // 其他 TLV 及 subtype 字段是描述/地址节的终点，不误认 Port description 为 Port ID。
    inDescription = false;
    addressSection = '';
  }
  flush();
  return neighbors;
}

export function vlanId(value) {
  if (!((typeof value === 'number' && Number.isInteger(value)) || (typeof value === 'string' && /^[0-9]{1,4}$/.test(value)))) {
    throw new TypeError('VLAN 必须是完整十进制整数');
  }
  const number = Number(value);
  if (number < 1 || number > 4094) throw new RangeError('VLAN 必须在 1–4094 之间');
  return number;
}

export function vlanRanges(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > 256 || /[^0-9, -]/.test(value)) {
    throw new TypeError('VLAN 列表须为逗号分隔的数字或范围，例如 10,20-30（最多 256 字符）');
  }
  const ids = new Set();
  for (const token of value.split(',')) {
    const match = token.trim().match(/^([0-9]{1,4})(?: *- *([0-9]{1,4}))?$/);
    if (!match) throw new TypeError('VLAN 列表包含无效项');
    const first = vlanId(match[1]);
    const last = match[2] === undefined ? first : vlanId(match[2]);
    if (first > last) throw new RangeError('VLAN 范围起点不能大于终点');
    for (let id = first; id <= last; id += 1) ids.add(id);
  }
  const ranges = [];
  for (const id of [...ids].sort((a, b) => a - b)) {
    const previous = ranges.at(-1);
    if (previous && previous[1] + 1 === id) previous[1] = id;
    else ranges.push([id, id]);
  }
  return ranges;
}

const interfaceTypes = {
  huawei: ['Ethernet', 'GigabitEthernet', 'XGigabitEthernet', 'MultiGE', 'GE', 'XGE', '10GE', '25GE', '40GE', '50GE', '100GE', '200GE', '400GE', 'Eth-Trunk'],
  h3c: ['Ethernet', 'GigabitEthernet', 'Ten-GigabitEthernet', 'Twenty-FiveGigE', 'TwentyFiveGigE', 'FortyGigE', 'HundredGigE', 'GE', 'XGE', 'Bridge-Aggregation'],
  ruijie: ['Ethernet', 'FastEthernet', 'GigabitEthernet', 'TenGigabitEthernet', 'TwentyFiveGigabitEthernet', 'FortyGigabitEthernet', 'HundredGigabitEthernet', 'Fa', 'Gi', 'Te', 'AggregatePort', 'Ag'],
  cisco: ['Ethernet', 'FastEthernet', 'GigabitEthernet', 'TwoGigabitEthernet', 'FiveGigabitEthernet', 'TenGigabitEthernet', 'TwentyFiveGigE', 'FortyGigabitEthernet', 'HundredGigE', 'Eth', 'Fa', 'Gi', 'Te', 'Twe', 'Fo', 'Hu', 'Port-channel', 'Po'],
};

export function interfaceName(vendor, value) {
  if (typeof value !== 'string' || value.length > 64 || /[^A-Za-z0-9/ -]/.test(value)) {
    throw new TypeError('接口必须是白名单内的单个二层接口');
  }
  const pattern = new RegExp(`^(${interfaceTypes[vendor].join('|')}) ?([0-9]{1,5}(?:/[0-9]{1,5}){0,3})$`, 'i');
  const match = value.match(pattern);
  if (!match || match[2].split('/').some((part) => Number(part) > 65535)) throw new TypeError('接口格式或类型不受支持');
  if (/^(?:Eth-Trunk|Bridge-Aggregation|AggregatePort|Ag|Port-channel|Po)$/i.test(match[1]) && (match[2].includes('/') || Number(match[2]) === 0)) {
    throw new TypeError('聚合接口须为单个正整数编号');
  }
  return value;
}

export function safeName(value, hostname = false) {
  const max = hostname ? 63 : 32;
  const pattern = hostname ? /^[A-Za-z](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/ : /^[A-Za-z0-9][A-Za-z0-9_-]*$/;
  if (typeof value !== 'string' || value.length < 1 || value.length > max || /[^\x21-\x7e]/.test(value) || !pattern.test(value)) {
    throw new TypeError(hostname ? '主机名须为 1–63 位字母/数字/短横线，字母开头且不能以短横线结尾' : 'VLAN 名称须为 1–32 位字母/数字/下划线/短横线，字母或数字开头');
  }
  return value;
}

/**
 * 仅构建待确认命令；不执行、不 save/write，不启用 LLDP、不 no shutdown。
 * 前提：华为/H3C 在用户视图，IOS/RGOS 在特权 EXEC；目标为已存在的二层接口。
 * access/trunk 要求 VLAN 已存在。trunk 为追加，不清理既有列表/native VLAN。
 * 使用即时生效配置视图；需要 commit 的 VRP、特殊封装/保留 VLAN 须人工适配。
 * vlan.name 可省略；提供时不可为空。vlans 使用字符串“10,20-30”。
 * 名称及接口使用保守 ASCII 白名单；不支持 interface range、子接口和任意 CLI。
 */
export function buildTemplate(vendor, template, params) {
  const profile = vendorProfile(vendor);
  const allowed = { vlan: ['vlan', 'name'], access: ['vlan', 'interface'], trunk: ['vlans', 'interface'], hostname: ['name'], health: [], backup: [] };
  if (typeof template !== 'string' || !Object.hasOwn(allowed, template)) throw new RangeError('不支持的配置模板');
  if (!params || typeof params !== 'object' || Array.isArray(params) || ![Object.prototype, null].includes(Object.getPrototypeOf(params))) {
    throw new TypeError('模板参数必须是普通对象');
  }
  for (const key of Reflect.ownKeys(params)) {
    const descriptor = Object.getOwnPropertyDescriptor(params, key);
    if (!allowed[template].includes(key) || !Object.hasOwn(descriptor, 'value')) throw new TypeError('包含未知参数或访问器');
  }
  for (const key of allowed[template]) {
    if (!(template === 'vlan' && key === 'name') && !Object.hasOwn(params, key)) throw new TypeError(`缺少参数 ${key}`);
  }
  // 无参数方案：只读巡检 / 读取配置，天然支持多厂商混选。
  if (template === 'health') {
    return vendor === 'huawei' || vendor === 'h3c'
      ? ['display version', 'display interface brief', 'display cpu-usage', 'display memory-usage', 'display lldp neighbor', 'display logbuffer']
      : ['show version', 'show interfaces status', 'show processes cpu', 'show memory', 'show lldp neighbors detail', 'show logging'];
  }
  if (template === 'backup') return [profile.backupCommand];
  const vrpStyle = vendor === 'huawei' || vendor === 'h3c';
  const enter = vrpStyle ? 'system-view' : 'configure terminal';
  const exit = vrpStyle ? 'quit' : 'exit';
  const finish = vrpStyle ? 'return' : 'end';
  if (template === 'hostname') return [enter, `${vrpStyle ? 'sysname' : 'hostname'} ${safeName(params.name, true)}`, finish];
  if (template === 'vlan') {
    const commands = [enter, `vlan ${vlanId(params.vlan)}`];
    if (Object.hasOwn(params, 'name')) commands.push(`name ${safeName(params.name)}`);
    return [...commands, exit, finish];
  }
  const port = interfaceName(vendor, params.interface);
  if (template === 'access') {
    const vlan = vlanId(params.vlan);
    const mode = vrpStyle ? 'port link-type access' : 'switchport mode access';
    const command = vendor === 'huawei' ? 'port default vlan' : vendor === 'h3c' ? 'port access vlan' : 'switchport access vlan';
    return [enter, `interface ${port}`, mode, `${command} ${vlan}`, exit, finish];
  }
  const ranges = vlanRanges(params.vlans);
  const list = ranges.map(([first, last]) => first === last ? String(first) : `${first}${vrpStyle ? ' to ' : '-'}${last}`).join(vrpStyle ? ' ' : ',');
  const mode = vrpStyle ? 'port link-type trunk' : 'switchport mode trunk';
  const command = vendor === 'huawei' ? 'port trunk allow-pass vlan' : vendor === 'h3c' ? 'port trunk permit vlan' : 'switchport trunk allowed vlan add';
  return [enter, `interface ${port}`, mode, `${command} ${list}`, exit, finish];
}
