import { VENDORS, vendorProfile, vlanId, vlanRanges, interfaceName, safeName } from './vendors.mjs';

// 配置向导：把「场景 → 步骤 → 参数」翻译成各厂商 CLI。
// 只生成待审核命令；不执行、不保存启动配置。

const isVrp = vendor => vendor === 'huawei' || vendor === 'h3c';

function ipv4(value, label = 'IPv4 地址') {
  if (typeof value !== 'string' || !/^(?:\d{1,3}\.){3}\d{1,3}$/.test(value.trim())) throw new TypeError(`${label}格式不正确，例如 192.168.10.1`);
  const parts = value.trim().split('.').map(Number);
  if (parts.some(n => !Number.isInteger(n) || n < 0 || n > 255)) throw new RangeError(`${label}每段必须在 0–255 之间`);
  return parts.join('.');
}

function netmask(value) {
  const raw = String(value || '').trim();
  if (/^\d{1,2}$/.test(raw)) {
    const bits = Number(raw);
    if (bits < 1 || bits > 32) throw new RangeError('掩码前缀必须在 1–32 之间');
    const num = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
    return [24, 16, 8, 0].map(shift => (num >>> shift) & 255).join('.');
  }
  const mask = ipv4(raw, '子网掩码');
  const num = mask.split('.').reduce((acc, n) => ((acc << 8) | Number(n)) >>> 0, 0);
  if (((~num >>> 0) & ((~num >>> 0) + 1)) !== 0) throw new RangeError('子网掩码必须是连续掩码，例如 255.255.255.0');
  return mask;
}

function count(value, label, max = 4096) {
  const n = Number(String(value).trim());
  if (!Number.isInteger(n) || n < 1 || n > max) throw new RangeError(`${label}必须是 1–${max} 的整数`);
  return n;
}

function list(value, label, max = 64) {
  const items = String(value || '').split(/[,，;；]+/).map(x => x.trim()).filter(Boolean);
  if (!items.length || items.length > max) throw new RangeError(`${label}需为 1–${max} 项，用逗号分隔`);
  return items;
}

function hostIp(value) {
  const ip = ipv4(value, '地址');
  if (ip === '0.0.0.0') throw new RangeError('地址不能是 0.0.0.0');
  return ip;
}

const step = (id, group, title, desc, params, build, meta = {}) => Object.freeze({ id, group, title, desc, params: Object.freeze(params), build, ...meta });

export const WIZARD_GROUPS = Object.freeze([
  { id: 'base', title: '基础与带外管理', desc: '设备命名、时钟、日志、SSH、SNMP' },
  { id: 'vlan', title: 'VLAN 与二层', desc: 'VLAN、Access、Trunk、SVI 网关' },
  { id: 'stp', title: '生成树与防环', desc: 'STP 模式、边缘端口、BPDU 保护' },
  { id: 'agg', title: '链路聚合', desc: 'LACP 聚合组与成员口' },
  { id: 'sec', title: '接入安全', desc: '端口安全、DHCP Snooping、地址池' },
  { id: 'route', title: '三层与路由', desc: '默认路由、OSPF' },
  { id: 'ha', title: '高可用', desc: 'VRRP 网关冗余、VSU 堆叠（锐捷）' },
  { id: 'diag', title: '邻居与巡检', desc: 'LLDP、只读体检' },
].map(Object.freeze));

export const WIZARD_STEPS = Object.freeze([
  // ---------------- 基础 ----------------
  step('hostname', 'base', '修改设备名称', '会改变提示符，执行器会自动跟踪。', [{ key: 'name', label: '主机名', placeholder: 'CORE-SW-01' }], (v, p) => {    const name = safeName(p.name, true);
    return isVrp(v) ? ['system-view', `sysname ${name}`, 'return'] : ['configure terminal', `hostname ${name}`, 'end'];
  }),
  step('ntp', 'base', '配置 NTP 服务器', '设备需能路由到该时间源。', [{ key: 'server', label: 'NTP 服务器', placeholder: '192.168.1.10' }], (v, p) => {
    const ip = hostIp(p.server);
    if (v === 'huawei') return ['system-view', `ntp-service unicast-server ${ip}`, 'return'];
    if (v === 'h3c') return ['system-view', `ntp-service unicast-server ${ip}`, 'return'];
    return ['configure terminal', `ntp server ${ip}`, 'end'];
  }),
  step('syslog', 'base', '配置日志服务器', '日志发往远端 Syslog，注意带宽与留存。', [{ key: 'server', label: 'Syslog 服务器', placeholder: '192.168.1.20' }], (v, p) => {
    const ip = hostIp(p.server);
    return isVrp(v) ? ['system-view', `info-center loghost ${ip}`, 'return'] : ['configure terminal', `logging ${ip}`, 'end'];
  }),
  step('ssh', 'base', '启用 SSH 服务', '开启后仍需本地用户与权限级别。', [], (v) => {
    const line = v === 'huawei' ? 'stelnet server enable' : v === 'h3c' ? 'ssh server enable' : v === 'ruijie' ? 'enable service ssh-server' : 'ip ssh version 2';
    return isVrp(v) ? ['system-view', line, 'return'] : ['configure terminal', line, 'end'];
  }),
  step('snmp', 'base', '配置只读 SNMP', '团体名视为凭据，注意保管与脱敏。', [{ key: 'community', label: '只读团体名', placeholder: 'NetPilot-RO' }], (v, p) => {
    const c = String(p.community || '').trim();
    if (!/^[A-Za-z0-9_.:-]{4,32}$/.test(c)) throw new TypeError('团体名需 4–32 位字母/数字/下划线/点/冒号/短横线');
    if (isVrp(v)) return ['system-view', 'snmp-agent', 'snmp-agent sys-info version v2c', `snmp-agent community read ${c}`, 'return'];
    return ['configure terminal', `snmp-server community ${c} ro`, 'end'];
  }),

  // ---------------- VLAN ----------------
  step('vlan-create', 'vlan', '创建并命名 VLAN', '一次可建多个；名称仅在单个 VLAN 时写入。', [
    { key: 'vlans', label: 'VLAN 列表', placeholder: '10,20-30' },
    { key: 'name', label: 'VLAN 名称（可选）', placeholder: 'OFFICE', required: false },
  ], (v, p) => {
    const ranges = vlanRanges(p.vlans);
    const ids = ranges.flatMap(([a, b]) => Array.from({ length: b - a + 1 }, (_, i) => a + i));
    const enter = isVrp(v) ? 'system-view' : 'configure terminal';
    const quit = isVrp(v) ? 'quit' : 'exit';
    const end = isVrp(v) ? 'return' : 'end';
    const lines = [enter];
    for (const id of ids) {
      lines.push(`vlan ${id}`);
      if (p.name && ids.length === 1) lines.push(`name ${safeName(p.name)}`);
      lines.push(quit);
    }
    return [...lines, end];
  }),
  step('access-port', 'vlan', '配置 Access 接口', '接口必须是二层物理口；VLAN 需已存在。', [
    { key: 'interface', label: '接口全名', placeholder: 'GigabitEthernet0/0/1' },
    { key: 'vlan', label: 'VLAN', placeholder: '10' },
  ], (v, p) => {
    const port = interfaceName(v, p.interface);
    const vid = vlanId(p.vlan);
    const enter = isVrp(v) ? 'system-view' : 'configure terminal';
    const mode = isVrp(v) ? 'port link-type access' : 'switchport mode access';
    const cmd = v === 'huawei' ? 'port default vlan' : v === 'h3c' ? 'port access vlan' : 'switchport access vlan';
    return [enter, `interface ${port}`, mode, `${cmd} ${vid}`, isVrp(v) ? 'quit' : 'exit', isVrp(v) ? 'return' : 'end'];
  }),
  step('trunk-port', 'vlan', '配置 Trunk 接口', '追加放行 VLAN，不清空既有列表。', [
    { key: 'interface', label: '接口全名', placeholder: 'GigabitEthernet0/0/24' },
    { key: 'vlans', label: '允许的 VLAN', placeholder: '10,20,30-40' },
  ], (v, p) => {
    const port = interfaceName(v, p.interface);
    const ranges = vlanRanges(p.vlans);
    const text = ranges.map(([a, b]) => a === b ? String(a) : `${a}${isVrp(v) ? ' to ' : '-'}${b}`).join(isVrp(v) ? ' ' : ',');
    const mode = isVrp(v) ? 'port link-type trunk' : 'switchport mode trunk';
    const cmd = v === 'huawei' ? 'port trunk allow-pass vlan' : v === 'h3c' ? 'port trunk permit vlan' : 'switchport trunk allowed vlan add';
    return [isVrp(v) ? 'system-view' : 'configure terminal', `interface ${port}`, mode, `${cmd} ${text}`, isVrp(v) ? 'quit' : 'exit', isVrp(v) ? 'return' : 'end'];
  }),
  step('svi', 'vlan', '配置 VLAN 网关（SVI）', '修改管理地址会立即断开当前会话。', [
    { key: 'vlan', label: 'VLAN', placeholder: '10' },
    { key: 'ip', label: '网关地址', placeholder: '192.168.10.1' },
    { key: 'mask', label: '掩码', placeholder: '255.255.255.0' },
  ], (v, p) => {
    const vid = vlanId(p.vlan);
    const ip = ipv4(p.ip, '网关地址');
    const mask = netmask(p.mask);
    const iface = v === 'huawei' ? `Vlanif ${vid}` : v === 'h3c' ? `Vlan-interface ${vid}` : `Vlan ${vid}`;
    return [isVrp(v) ? 'system-view' : 'configure terminal', `interface ${iface}`, `ip address ${ip} ${mask}`, isVrp(v) ? 'undo shutdown' : 'no shutdown', isVrp(v) ? 'quit' : 'exit', isVrp(v) ? 'return' : 'end'];
  }),

  // ---------------- STP ----------------
  step('stp-mode', 'stp', '设置生成树模式', '全网模式必须一致，混用可能造成环路。', [{
    key: 'mode', label: '模式', placeholder: 'rstp 或 mst', options: ['rstp', 'mst'],
  }], (v, p) => {
    const mode = String(p.mode || 'rstp').trim().toLowerCase();
    if (!['rstp', 'mst'].includes(mode)) throw new TypeError('模式只能是 rstp 或 mst');
    const line = v === 'cisco' ? `spanning-tree mode ${mode === 'mst' ? 'mst' : 'rapid-pvst'}` : v === 'ruijie' ? `spanning-tree mode ${mode}` : `stp mode ${mode === 'mst' ? 'mstp' : 'rstp'}`;
    return isVrp(v) ? ['system-view', line, 'return'] : ['configure terminal', line, 'end'];
  }),
  step('portfast', 'stp', '配置边缘端口', '只接终端；接交换机可能引起环路。', [{ key: 'interface', label: '接口全名', placeholder: 'GigabitEthernet0/0/1' }], (v, p) => {
    const port = interfaceName(v, p.interface);
    const line = v === 'huawei' ? 'stp edged-port enable' : v === 'h3c' ? 'stp edged-port' : 'spanning-tree portfast';
    return [isVrp(v) ? 'system-view' : 'configure terminal', `interface ${port}`, line, isVrp(v) ? 'quit' : 'exit', isVrp(v) ? 'return' : 'end'];
  }),
  step('bpdu-guard', 'stp', 'BPDU 保护', '收到 BPDU 时关闭端口；误配会断接入。', [], (v) => {
    if (isVrp(v)) return ['system-view', 'stp bpdu-protection', 'return'];
    return ['configure terminal', 'spanning-tree portfast bpduguard default', 'end'];
  }),

  // ---------------- 聚合 ----------------
  step('lacp', 'agg', '创建 LACP 聚合组', '成员口速率双工需一致；跨设备聚合需堆叠支持。', [
    { key: 'group', label: '聚合组编号', placeholder: '1' },
    { key: 'interfaces', label: '成员接口', placeholder: 'GigabitEthernet0/0/1,GigabitEthernet0/0/2' },
  ], (v, p) => {
    const group = count(p.group, '聚合组编号', 128);
    const ports = list(p.interfaces, '成员接口', 8).map(item => interfaceName(v, item));
    const enter = isVrp(v) ? 'system-view' : 'configure terminal';
    const end = isVrp(v) ? 'return' : 'end';
    const lines = [enter];
    if (v === 'huawei') lines.push(`interface Eth-Trunk ${group}`, 'mode lacp-static', 'quit');
    if (v === 'h3c') lines.push(`interface Bridge-Aggregation ${group}`, 'link-aggregation mode dynamic', 'quit');
    if (v === 'ruijie' || v === 'cisco') lines.push(`interface Port-channel ${group}`, 'exit');
    for (const port of ports) {
      lines.push(`interface ${port}`);
      if (v === 'huawei') lines.push(`eth-trunk ${group}`);
      else if (v === 'h3c') lines.push(`port link-aggregation group ${group}`);
      else lines.push(`channel-group ${group} mode active`);
      lines.push('exit');
    }
    return [...lines, end];
  }),

  // ---------------- 安全 ----------------
  step('port-security', 'sec', '端口安全', 'Cisco/锐捷默认 sticky；华三按 autolearn 处理。', [
    { key: 'interface', label: '接口全名', placeholder: 'GigabitEthernet0/0/1' },
    { key: 'maximum', label: '最大 MAC 数', placeholder: '1' },
  ], (v, p) => {
    const port = interfaceName(v, p.interface);
    const max = count(p.maximum, '最大 MAC 数', 1024);
    const enter = isVrp(v) ? 'system-view' : 'configure terminal';
    const lines = [enter];
    if (v === 'huawei') lines.push('port-security enable', `interface ${port}`, 'port-security enable', `port-security max-mac-num ${max}`, 'port-security protect-action shutdown');
    else if (v === 'h3c') lines.push('port-security enable', `interface ${port}`, 'port-security port-mode autolearn', `port-security max-mac-count ${max}`, 'port-security intrusion-mode disableport');
    else lines.push(`interface ${port}`, 'switchport port-security', `switchport port-security maximum ${max}`, 'switchport port-security mac-address sticky', 'switchport port-security violation shutdown');
    return [...lines, isVrp(v) ? 'quit' : 'exit', isVrp(v) ? 'return' : 'end'];
  }),
  step('dhcp-snooping', 'sec', 'DHCP Snooping + 信任口', '必须把上行口设为信任口，否则客户端拿不到地址。', [
    { key: 'trust', label: '信任口', placeholder: 'GigabitEthernet0/0/24' },
  ], (v, p) => {
    const port = interfaceName(v, p.trust);
    const enter = isVrp(v) ? 'system-view' : 'configure terminal';
    const global = v === 'huawei' || v === 'h3c' ? 'dhcp snooping enable' : 'ip dhcp snooping';
    const trust = v === 'huawei' ? 'dhcp snooping trusted' : v === 'h3c' ? 'dhcp snooping trust' : 'ip dhcp snooping trust';
    return [enter, global, `interface ${port}`, trust, isVrp(v) ? 'quit' : 'exit', isVrp(v) ? 'return' : 'end'];
  }),
  step('dhcp-pool', 'sec', '创建 DHCP 地址池', '地址池网段必须与网关同网段。', [
    { key: 'name', label: '地址池名称', placeholder: 'VLAN10' },
    { key: 'network', label: '网段', placeholder: '192.168.10.0' },
    { key: 'mask', label: '掩码', placeholder: '255.255.255.0' },
    { key: 'gateway', label: '网关', placeholder: '192.168.10.1' },
    { key: 'dns', label: 'DNS（可选）', placeholder: '8.8.8.8,114.114.114.114', required: false },
  ], (v, p) => {
    const name = safeName(p.name);
    const network = ipv4(p.network, '网段');
    const mask = netmask(p.mask);
    const gateway = ipv4(p.gateway, '网关');
    const dns = p.dns ? list(p.dns, 'DNS', 4).map(item => ipv4(item, 'DNS')).join(' ') : '';
    const enter = isVrp(v) ? 'system-view' : 'configure terminal';
    const end = isVrp(v) ? 'return' : 'end';
    if (v === 'huawei') return [enter, 'dhcp enable', `ip pool ${name}`, `network ${network} mask ${mask}`, `gateway-list ${gateway}`, ...(dns ? [`dns-list ${dns}`] : []), 'quit', end];
    if (v === 'h3c') return [enter, 'dhcp enable', `dhcp server ip-pool ${name}`, `network ${network} mask ${mask}`, `gateway-list ${gateway}`, ...(dns ? [`dns-list ${dns}`] : []), 'quit', end];
    return [enter, ...(v === 'ruijie' ? ['service dhcp'] : []), `ip dhcp pool ${name}`, `network ${network} ${mask}`, `default-router ${gateway}`, ...(dns ? [`dns-server ${dns}`] : []), 'exit', end];
  }),

  // ---------------- 路由 ----------------
  step('default-route', 'route', '配置默认路由', '下一跳必须三层可达，否则形成黑洞。', [{ key: 'nexthop', label: '下一跳', placeholder: '192.168.1.254' }], (v, p) => {
    const ip = hostIp(p.nexthop);
    const line = isVrp(v) ? `ip route-static 0.0.0.0 0.0.0.0 ${ip}` : `ip route 0.0.0.0 0.0.0.0 ${ip}`;
    return isVrp(v) ? ['system-view', line, 'return'] : ['configure terminal', line, 'end'];
  }),
  step('ospf', 'route', '启用 OSPF', '宣告网段用反掩码；错误宣告可能引起环路。', [
    { key: 'process', label: '进程号', placeholder: '1' },
    { key: 'network', label: '宣告网段', placeholder: '192.168.10.0' },
    { key: 'wildcard', label: '反掩码', placeholder: '0.0.0.255' },
    { key: 'area', label: '区域', placeholder: '0' },
  ], (v, p) => {
    const process = count(p.process, '进程号', 65535);
    const network = ipv4(p.network, '宣告网段');
    const wildcard = ipv4(p.wildcard, '反掩码');
    const area = Number(String(p.area).trim());
    if (!Number.isInteger(area) || area < 0 || area > 4294967295) throw new RangeError('区域必须是 0–4294967295 的整数（骨干区域为 0）');
    if (isVrp(v)) return ['system-view', `ospf ${process}`, `area ${area}`, `network ${network} ${wildcard}`, 'quit', 'quit', 'return'];
    return ['configure terminal', `router ospf ${process}`, `network ${network} ${wildcard} area ${area}`, 'exit', 'end'];
  }),

  // ---------------- 高可用 ----------------
  step('vrrp', 'ha', '配置 VRRP 网关冗余', '两端 vrid 与虚拟 IP 必须一致。', [
    { key: 'vlan', label: 'VLAN', placeholder: '10' },
    { key: 'vrid', label: '备份组号', placeholder: '10' },
    { key: 'vip', label: '虚拟 IP', placeholder: '192.168.10.254' },
    { key: 'priority', label: '优先级', placeholder: '120' },
  ], (v, p) => {
    const vid = vlanId(p.vlan);
    const vrid = count(p.vrid, '备份组号', 255);
    const vip = ipv4(p.vip, '虚拟 IP');
    const priority = count(p.priority, '优先级', 254);
    if (priority < 100) throw new RangeError('优先级建议 100–254，低于 100 会处于备状态');
    const iface = v === 'huawei' ? `Vlanif ${vid}` : v === 'h3c' ? `Vlan-interface ${vid}` : `Vlan ${vid}`;
    const lines = isVrp(v)
      ? ['system-view', `interface ${iface}`, `vrrp vrid ${vrid} virtual-ip ${vip}`, `vrrp vrid ${vrid} priority ${priority}`]
      : ['configure terminal', `interface ${iface}`, `vrrp ${vrid} ip ${vip}`, `vrrp ${vrid} priority ${priority}`];
    return [...lines, isVrp(v) ? 'quit' : 'exit', isVrp(v) ? 'return' : 'end'];
  }),
  step('vsu', 'ha', 'VSU 堆叠（仅锐捷）', '仅锐捷 RGOS；改运行模式需重启，务必在维护窗口操作。', [
    { key: 'domain', label: 'VSU 域号', placeholder: '1' },
    { key: 'member', label: '成员编号', placeholder: '1' },
    { key: 'priority', label: '优先级', placeholder: '200' },
  ], (v, p) => {
    if (v !== 'ruijie') throw new RangeError('VSU 为锐捷专有；华为/华三请用堆叠或 IRF，Cisco 用 StackWise，需按型号手册配置');
    const domain = count(p.domain, 'VSU 域号', 255);
    const member = count(p.member, '成员编号', 8);
    const priority = count(p.priority, '优先级', 255);
    return ['configure terminal', `switch virtual domain ${domain}`, `switch ${member}`, `switch ${member} priority ${priority}`, 'exit', 'end'];
  }, { vendors: ['ruijie'] }),

  // ---------------- 诊断 ----------------
  step('lldp', 'diag', '启用 LLDP', '拓扑发现依赖它；Cisco 用 lldp run。', [], (v) => {
    const line = v === 'cisco' ? 'lldp run' : 'lldp enable';
    return isVrp(v) ? ['system-view', line, 'return'] : ['configure terminal', line, 'end'];
  }),
  step('health', 'diag', '只读设备体检', '不改配置，采集版本/接口/CPU/内存/日志/邻居。', [], (v) => (isVrp(v)
    ? ['display version', 'display interface brief', 'display cpu-usage', 'display memory-usage', 'display logbuffer', 'display lldp neighbor']
    : ['show version', 'show interfaces status', 'show processes cpu', 'show memory', 'show logging', 'show lldp neighbors detail'])),
].map(Object.freeze));

export const WIZARD_CATALOG = Object.freeze({
  groups: WIZARD_GROUPS,
  steps: WIZARD_STEPS.map(({ build, ...rest }) => ({
    ...rest,
    params: rest.params.map(param => ({ required: true, ...param })),
  })),
  vendors: VENDORS.map(({ id, label, os, color }) => ({ id, label, os, color })),
});

export function buildWizard(vendor, selections) {
  vendorProfile(vendor);
  if (!Array.isArray(selections) || !selections.length) throw new TypeError('请至少选择一个配置步骤');
  if (selections.length > 40) throw new RangeError('单次最多 40 个步骤');
  const lines = [], notes = [];
  let index = 0;
  for (const item of selections) {
    if (!item || typeof item.id !== 'string') throw new TypeError('步骤格式无效');
    const definition = WIZARD_STEPS.find(entry => entry.id === item.id);
    if (!definition) throw new RangeError(`未知步骤：${item.id}`);
    const params = item.params && typeof item.params === 'object' && !Array.isArray(item.params) ? item.params : {};
    for (const key of Reflect.ownKeys(params)) {
      const descriptor = Object.getOwnPropertyDescriptor(params, key);
      if (!Object.hasOwn(descriptor, 'value')) throw new TypeError('参数不能使用访问器');
    }
    const values = { ...params };
    for (const param of definition.params) {
      // 有枚举的步骤（如 stp 模式）未显式传值时取第一项，避免"没动下拉框就报缺参数"。
      if (!Object.hasOwn(values, param.key) && Array.isArray(param.options) && param.options.length) values[param.key] = param.options[0];
      if (param.required !== false && !Object.hasOwn(values, param.key)) throw new TypeError(`步骤「${definition.title}」缺少参数 ${param.label}`);
    }
    try {
      const block = definition.build(vendor, values);
      if (block.length) {
        lines.push(`# ${String(++index).padStart(2, '0')} · ${definition.title}`, ...block);
      }
    } catch (error) {
      const label = vendorProfile(vendor).label;
      throw new Error(`${definition.title}（${label}）：${error.message}`);
    }
  }
  if (!lines.length) throw new RangeError('所选步骤没有生成任何命令');
  return { commands: lines, notes };
}
