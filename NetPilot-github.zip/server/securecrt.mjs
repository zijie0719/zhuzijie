import { EventEmitter } from 'node:events';
import { randomBytes, randomUUID } from 'node:crypto';

const MAX_OUTPUT = 1024 * 1024;
const PROMPT = /^(?:<[A-Za-z0-9_][A-Za-z0-9_.:/-]{0,127}>|\[[~*]?[A-Za-z0-9_][A-Za-z0-9_.:/-]{0,127}\]|[A-Za-z0-9_][A-Za-z0-9_.:/-]{0,127}(?:\([A-Za-z0-9_./:-]{1,128}\))?[#>])$/;
const fail = (message, status = 400) => { throw Object.assign(new Error(message), { status }); };
export function validBridgePrompt(value) { return typeof value === 'string' && PROMPT.test(value); }

// A bridge capability can only claim/read its own one-at-a-time command queue.
// It cannot access settings, backups, plans or create configuration jobs.
export class SecureCRTConnection extends EventEmitter {
  constructor({ name, prompt, now = Date.now }) {
    super(); this.id = randomUUID(); this.token = randomBytes(32).toString('hex');
    this.info = { kind: 'securecrt', path: name, prompt }; this.isConnected = true;
    this.now = now; this.lastSeen = now(); this.pending = null;
  }
  run(command, { timeoutMs = 15000, requireEcho = false } = {}) {
    if (!this.isConnected) return Promise.reject(new Error('SecureCRT 桥接已断开，请在原标签重新运行桥接脚本。'));
    if (this.pending) return Promise.reject(new Error('SecureCRT 会话已有命令运行，禁止并发下发。'));
    if (typeof command !== 'string' || !command.trim() || command.length > 500 || /[\x00-\x1f\x7f]/.test(command)) return Promise.reject(new Error('桥接命令必须为单行文本。'));
    if (!Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > 90000) return Promise.reject(new Error('桥接命令超时时间无效。'));
    return new Promise((resolve, reject) => {
      const pending = { id: randomUUID(), command, timeoutMs, requireEcho, startPrompt: this.info.prompt, delivered: false, resolve, reject };
      pending.timer = setTimeout(() => void this.close('SecureCRT 命令超时，执行结果不确定；已解绑且不会重发，请到原终端核对。'), timeoutMs + 6000);
      this.pending = pending;
    });
  }
  poll() {
    if (!this.isConnected) fail('桥接已结束，请重新配对。', 410);
    this.lastSeen = this.now();
    const p = this.pending;
    if (!p || p.delivered) return 'WAIT';
    p.delivered = true;
    return [p.id, Math.ceil(p.timeoutMs / 1000), p.requireEcho ? '1' : '0', p.startPrompt, p.command].join('\n');
  }
  result({ taskId, status, prompt, output }) {
    const p = this.pending;
    if (!this.isConnected || !p || !p.delivered || p.id !== taskId) fail('任务已失效或结果已收到，禁止重放。', 409);
    if (typeof output !== 'string' || Buffer.byteLength(output, 'utf8') > MAX_OUTPUT) { void this.close('SecureCRT 输出超出 1 MiB，已停止任务。'); fail('输出过大。', 413); }
    if (status !== 'ok') {
      // Remote error text is not trusted or included in audit (may contain credentials).
      void this.close('SecureCRT 脚本报告超时、交互确认、会话变化或命令回显异常；执行结果不确定，请检查原终端。');
      return;
    }
    const normalized = output.replace(/\r/g, '');
    const lines = normalized.trimEnd().split('\n');
    const echoSeen = lines.some(line => line.trim() === p.command || (line.startsWith(p.startPrompt) && line.slice(p.startPrompt.length).trim() === p.command));
    if (!validBridgePrompt(prompt) || lines.at(-1) !== prompt || (p.requireEcho && !echoSeen)) {
      void this.close('SecureCRT 返回提示符或命令回显未通过校验，已停止后续步骤。'); return;
    }
    clearTimeout(p.timer); this.pending = null; this.info.prompt = prompt; this.lastSeen = this.now(); p.resolve(normalized);
  }
  async close(reason = '已从网页解绑 SecureCRT；原 SecureCRT 会话不会被关闭。') {
    if (!this.isConnected) return;
    this.isConnected = false;
    if (this.pending) { clearTimeout(this.pending.timer); const p = this.pending; this.pending = null; p.reject(new Error(reason)); }
    this.emit('close');
  }
}

export class SecureCRTBridge {
  constructor({ now = Date.now, pairingMs = 10 * 60 * 1000, idleMs = 15000 } = {}) {
    this.now = now; this.pairingMs = pairingMs; this.idleMs = idleMs; this.pairings = new Map(); this.reports = new Map(); this.connections = new Map(); this.attempts = [];
    this.timer = setInterval(() => this.sweep(), 3000); this.timer.unref();
  }
  prepare(vendor = 'auto') {
    this.sweep();
    if (this.pairings.size >= 5) fail('最多同时等待 5 个 SecureCRT 配对，请等待旧配对过期。', 429);
    const code = randomBytes(12).toString('hex'); const expires = this.now() + this.pairingMs, id = randomUUID();
    const pair = { id, vendor, expires, state: 'waiting' };
    this.pairings.set(code, pair); this.reports.set(id, pair);
    if (this.reports.size > 100) this.reports.delete(this.reports.keys().next().value);
    return { id, code, expiresAt: new Date(expires).toISOString() };
  }
  attach({ code, name, prompt }) {
    const now = this.now(); this.attempts = this.attempts.filter(t => t > now - 60000);
    if (this.attempts.length >= 20) fail('配对请求过于频繁，请一分钟后重试。', 429);
    this.attempts.push(now);
    const pair = this.pairings.get(code);
    if (!pair || pair.expires <= now) fail('配对码无效、已使用或过期，请在网页重新生成。', 403);
    if (typeof name !== 'string' || !name.trim() || name.length > 128 || /[\x00-\x1f\x7f]/.test(name) || !validBridgePrompt(prompt)) fail('请先在 SecureCRT 登录设备并停留在完整的 CLI 提示符。');
    if ([...this.connections.values()].some(c => c.isConnected && c.info.path === name)) fail('该 SecureCRT 会话名称已经绑定，请先解绑；同名会话请先改为不同标签名。', 409);
    this.pairings.delete(code);
    const connection = new SecureCRTConnection({ name: name.trim(), prompt, now: this.now });
    this.connections.set(connection.token, connection);
    pair.state = 'identifying';
    connection.on('close', () => { this.connections.delete(connection.token); if (pair.state !== 'failed') pair.state = 'disconnected'; });
    return { connection, vendor: pair.vendor, pairingId: pair.id };
  }
  report(id, state, error = '') { const pair = this.reports.get(id); if (pair) { pair.state = state; pair.error = error; } }
  status(id) {
    this.sweep(); const pair = this.reports.get(id); if (!pair) fail('配对记录不存在，请重新生成。', 404);
    return { state: pair.state, error: pair.error || '', expiresAt: new Date(pair.expires).toISOString() };
  }
  authorize(token) {
    if (typeof token !== 'string' || !/^[a-f0-9]{64}$/.test(token)) fail('桥接身份验证失败。', 403);
    const connection = this.connections.get(token);
    if (!connection?.isConnected) fail('桥接已结束，请重新配对。', 410);
    return connection;
  }
  sweep() {
    for (const [code, pair] of this.pairings) if (pair.expires <= this.now()) { pair.state = 'expired'; this.pairings.delete(code); }
    for (const connection of this.connections.values()) if (!connection.pending && this.now() - connection.lastSeen > this.idleMs) void connection.close('SecureCRT 心跳中断，已解绑；不会自动重连或重发命令。');
  }
  async close() { clearInterval(this.timer); this.pairings.clear(); await Promise.all([...this.connections.values()].map(c => c.close())); }
}
