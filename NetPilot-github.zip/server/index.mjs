import express from 'express';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { existsSync } from 'node:fs';
import { readFile, writeFile, rename } from 'node:fs/promises';
import { gzipSync } from 'node:zlib';
import { SecureCRTBridge } from './securecrt.mjs';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { createStore, redact } from './store.mjs';
import { DeviceConnection, listSerialPorts, probeSSH } from './transport.mjs';
import { VENDORS, COMMANDS, SOURCES, vendorProfile, detectVendor, parseNeighbors, parseDevice, buildTemplate } from './vendors.mjs';
import { WIZARD_CATALOG, buildWizard } from './wizard.mjs';
import { commandLines, assessCommands, isReadonly, cliFailed, digest, inScope, parseScopes, validHost, validPort, validateAi } from './policy.mjs';
import { chatCompletion, chatStream } from './ai.mjs';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const PORT = Number(process.env.NETPILOT_PORT || 47831);
const DATA = process.env.NETPILOT_DATA_DIR || join(ROOT, '.netpilot');
// 默认只监听本机；部署到服务器时用 NETPILOT_BIND=0.0.0.0 + NETPILOT_ACCESS_TOKEN 显式开启。
const BIND = (process.env.NETPILOT_BIND || '127.0.0.1').trim();
const LOOPBACK_BIND = ['127.0.0.1', 'localhost', '::1'].includes(BIND);
const ACCESS_TOKEN = (process.env.NETPILOT_ACCESS_TOKEN || '').trim();
const ALLOWED_HOSTS = (process.env.NETPILOT_ALLOWED_HOSTS || '').split(',').map(value => value.trim().toLowerCase()).filter(Boolean);
if (!LOOPBACK_BIND && ACCESS_TOKEN.length < 12) {
  console.error(`[NetPilot] NETPILOT_BIND=${BIND} 不是回环地址；对外部署必须同时设置至少 12 位的 NETPILOT_ACCESS_TOKEN，已拒绝启动。`);
  process.exit(1);
}
const store = await createStore(DATA);
const secureCRT = new SecureCRTBridge();
const app = express();
const sessions = new Map(), plans = new Map(), streams = new Set(), seenPorts = new Set();
const SESSION_TTL = 12 * 60 * 60 * 1000, SESSION_COOKIE = 'netpilot_session';
const authSessions = new Map(), loginAttempts = new Map();
const csrfToken = randomUUID() + randomUUID();
let activeTask = null, aiBusy = false, aiCalls = [], stopping = false;
const snapshot = () => ({ csrfToken, version: '1.0.0-local', deployment: { bind: BIND, loopback: LOOPBACK_BIND, authRequired: Boolean(ACCESS_TOKEN), allowedHosts: ALLOWED_HOSTS }, devices: store.state.devices, links: store.state.links, jobs: store.state.jobs.slice(0, 50), audit: store.state.audit.slice(0, 500), settings: store.safeSettings(), activeTask });
function writeStream(res, chunk) { try { if (!res.writableEnded && !res.destroyed) res.write(chunk); } catch { /* 客户端已断开，忽略 */ } }
function emit() { const payload = `data: ${JSON.stringify({ type: 'update', at: Date.now() })}\n\n`; for (const res of streams) writeStream(res, payload); }
function fail(message, status = 400) { const e = new Error(message); e.status = status; throw e; }
function busyCheck() { if (activeTask) fail('另一个设备任务正在运行，请等待完成或请求停止后再操作。', 409); }
function connected(id) { const s = sessions.get(id); if (!s?.connection.isConnected) fail('设备会话未连接或已断开，请重新连接后重试。', 409); return s; }
function deviceById(id) { const d = store.state.devices.find(d => d.id === id); if (!d) fail('设备不存在', 404); return d; }
function checkVendor(v, auto = false) { if (!(auto && v === 'auto') && !VENDORS.some(x => x.id === v)) fail('请选择支持的设备厂商'); return v; }
function sameToken(value) { const a = Buffer.from(String(value || '')), b = Buffer.from(csrfToken); return a.length === b.length && timingSafeEqual(a, b); }
function secureEqual(a, b) { const x = Buffer.from(String(a || '')), y = Buffer.from(String(b || '')); return x.length === y.length && timingSafeEqual(x, y); }
function hostAllowed(host) {
  if (typeof host !== 'string' || !host) return false;
  const value = host.trim().toLowerCase();
  if (value === `127.0.0.1:${PORT}` || value === `localhost:${PORT}` || value === `[::1]:${PORT}` || value === '[::1]' || value === '127.0.0.1:5173' || value === 'localhost:5173') return true;
  const name = value.startsWith('[') ? value.slice(0, value.indexOf(']') + 1) : value.split(':')[0];
  if (ALLOWED_HOSTS.includes('*') || ALLOWED_HOSTS.includes(value) || ALLOWED_HOSTS.includes(name)) return true;
  // 对外监听且未配置白名单时放行任意 Host；访问仍受口令与 SameSite Cookie 约束。
  return !LOOPBACK_BIND && ALLOWED_HOSTS.length === 0;
}
function cookieValue(header, name) {
  if (typeof header !== 'string') return '';
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    if (part.slice(0, index).trim() === name) return part.slice(index + 1).trim();
  }
  return '';
}
function authenticated(req) {
  if (!ACCESS_TOKEN) return true;
  const sid = cookieValue(req.headers.cookie, SESSION_COOKIE);
  const expires = authSessions.get(sid);
  if (!expires) return false;
  if (expires <= Date.now()) { authSessions.delete(sid); return false; }
  return true;
}
app.disable('x-powered-by');
app.set('trust proxy', 'loopback');
app.use((req, res, next) => {
  if (!hostAllowed(req.headers.host)) return res.status(403).json({ error: ALLOWED_HOSTS.length ? 'Host 不在允许列表（NETPILOT_ALLOWED_HOSTS）' : (LOOPBACK_BIND ? '仅允许通过本机地址访问' : 'Host 不在允许列表') });
  if (req.headers['sec-fetch-site'] === 'cross-site') return res.status(403).json({ error: '拒绝跨站请求' });
  if (req.headers.origin) {
    try { const origin = new URL(req.headers.origin); if (!['http:', 'https:'].includes(origin.protocol) || !hostAllowed(origin.host)) return res.status(403).json({ error: '请求来源未授权' }); }
    catch { return res.status(403).json({ error: '请求来源无效' }); }
  }
  res.set('X-Content-Type-Options', 'nosniff'); res.set('Referrer-Policy', 'no-referrer'); res.set('X-Frame-Options', 'DENY');
  res.set('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  res.set('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  if (!LOOPBACK_BIND) res.set('Strict-Transport-Security', 'max-age=31536000');
  if (req.path.startsWith('/api') || req.path.startsWith('/bridge')) res.set('Cache-Control', 'no-store');
  const openPath = req.path === '/api/login' || req.path === '/api/session' || req.path === '/api/health';
  if (req.path.startsWith('/api') && !['GET', 'HEAD'].includes(req.method) && !openPath && !sameToken(req.headers['x-netpilot-csrf'])) return res.status(403).json({ error: '操作验证已过期，请刷新页面重试' });
  if (ACCESS_TOKEN && req.path.startsWith('/api') && !openPath && !authenticated(req)) return res.status(401).json({ error: '需要先登录', authRequired: true });
  next();
});
// SecureCRT 桥接只在设备本机运行，永远不接受远程来源。
app.use('/bridge', (req, res, next) => {
  const address = req.socket.remoteAddress || '';
  if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(address)) return res.status(403).json({ error: 'SecureCRT 桥接仅允许本机访问' });
  next();
});
app.use('/bridge', express.text({ type: 'text/plain', limit: '1100kb' }));
app.use(express.json({ limit: '128kb', strict: true }));
// 拓扑快照会随设备数量线性变大：对 JSON 响应按需 gzip，1 KiB 以下不压缩。
app.use((req, res, next) => {
  if (!req.path.startsWith('/api') || !/\bgzip\b/i.test(String(req.headers['accept-encoding'] || ''))) return next();
  const sendJson = res.json.bind(res);
  res.json = payload => {
    const buffer = Buffer.from(JSON.stringify(payload), 'utf8');
    if (buffer.length < 1024) return sendJson(payload);
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Vary', 'Accept-Encoding');
    return res.end(gzipSync(buffer, { level: 5 }));
  };
  next();
});
const route = fn => async (req, res, next) => { try { await fn(req, res); } catch (e) { next(e); } };
app.get('/api/bootstrap', (req, res) => res.json(snapshot()));
app.get('/api/health', (req, res) => res.json({ ok: true, version: '1.0.0-local', uptime: Math.round(process.uptime()), devices: store.state.devices.length, connected: sessions.size }));
app.get('/api/session', (req, res) => res.json({ authRequired: Boolean(ACCESS_TOKEN), authenticated: authenticated(req), bind: BIND, loopback: LOOPBACK_BIND }));
app.post('/api/login', route(async (req, res) => {
  if (!ACCESS_TOKEN) return res.json({ ok: true });
  const address = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const recent = (loginAttempts.get(address) || []).filter(t => t > now - 60000);
  if (recent.length >= 10) return res.status(429).json({ error: '登录尝试过于频繁，请一分钟后再试' });
  const token = typeof req.body.token === 'string' ? req.body.token : '';
  if (!secureEqual(token, ACCESS_TOKEN)) {
    recent.push(now); loginAttempts.set(address, recent);
    await store.audit('登录失败', `来源 ${address}`, 'failed').catch(() => {});
    return res.status(401).json({ error: '访问口令不正确' });
  }
  loginAttempts.delete(address);
  const sid = randomBytes(32).toString('hex');
  authSessions.set(sid, now + SESSION_TTL);
  res.cookie(SESSION_COOKIE, sid, { httpOnly: true, sameSite: 'strict', secure: Boolean(req.secure), maxAge: SESSION_TTL, path: '/' });
  await store.audit('登录成功', `来源 ${address}`).catch(() => {});
  res.json({ ok: true });
}));
app.post('/api/logout', route(async (req, res) => {
  const sid = cookieValue(req.headers.cookie, SESSION_COOKIE);
  if (sid) authSessions.delete(sid);
  res.clearCookie(SESSION_COOKIE, { path: '/' });
  res.json({ ok: true });
}));
app.get('/api/catalog', (req, res) => res.json({ vendors: VENDORS, commands: COMMANDS, sources: SOURCES }));
app.get('/api/wizard', (req, res) => res.json(WIZARD_CATALOG));
app.post('/api/wizard/build', route(async (req, res) => {
  const vendor = checkVendor(req.body.vendor);
  const result = buildWizard(vendor, req.body.steps);
  const plain = result.commands.filter(line => !line.startsWith('#'));
  if (plain.length > 300) fail(`本次生成 ${plain.length} 行，超过单次 300 行上限；请拆分批次（例如少选几个 VLAN 或多分几个步骤）。`);
  let warnings = [];
  try { warnings = assessCommands(commandLines(plain.join('\n'))).warnings; } catch { warnings = []; }
  res.json({ ...result, lines: plain.length, warnings });
}));
app.get('/api/ports', route(async (req, res) => res.json({ ports: await listSerialPorts() })));
app.get('/api/events', (req, res) => {
  if (streams.size >= 64) { const oldest = streams.values().next().value; try { oldest.end(); } catch { /* 已断开 */ } streams.delete(oldest); }
  res.set({ 'Content-Type': 'text/event-stream', Connection: 'keep-alive', 'Cache-Control': 'no-store' }); res.flushHeaders(); streams.add(res); writeStream(res, 'data: {"type":"connected"}\n\n');
  const heartbeat = setInterval(() => writeStream(res, ': heartbeat\n\n'), 20000); req.on('close', () => { clearInterval(heartbeat); streams.delete(res); });
});
app.post('/api/ssh/probe', route(async (req, res) => {
  busyCheck(); const host = validHost(req.body.host), port = validPort(req.body.port);
  res.json(await probeSSH({ host, port, timeoutMs: 8000 }));
}));
async function identify(connection, selectedVendor = 'auto') {
  let vendor = selectedVendor, version = '';
  if (vendor === 'auto') {
    version = await connection.run('display version');
    if (cliFailed(version) || detectVendor(version) === 'unknown') version = await connection.run('show version');
    vendor = detectVendor(version);
    if (vendor === 'unknown') throw new Error('未能自动识别厂商，请核对登录提示符、权限并手动选择厂商后重连。');
  } else {
    version = await connection.run(vendorProfile(vendor).versionCommand);
    if (cliFailed(version)) throw new Error('版本查询失败，请检查所选厂商、命令视图和设备权限。');
    const detected = detectVendor(version); if (detected !== 'unknown' && detected !== vendor) throw new Error('设备返回的厂商与所选厂商不一致，请核对后重连。');
  }
  const pagingOutput = await connection.run(vendorProfile(vendor).pagingCommand);
  const info = parseDevice(version, vendor);
  return { vendor, ...info, pagingWarning: cliFailed(pagingOutput) };
}
function upsertDevice(input) {
  let d = store.state.devices.find(x => x.id === input.id || (input.managementIp && x.managementIp === input.managementIp) || (input.chassisId && x.chassisId === input.chassisId) || (input.name && x.name === input.name && (!input.managementIp || !x.managementIp) && (!input.chassisId || !x.chassisId)));
  if (d) {
    const prev = { ...d };
    for (const [k, v] of Object.entries(input)) if (v !== undefined && v !== '') d[k] = v;
    d.id = prev.id;
    if (input.vendor === 'unknown' && prev.vendor !== 'unknown') d.vendor = prev.vendor;
    if (sessions.has(d.id)) { d.connected = true; d.kind = prev.kind; d.path = prev.path; d.status = prev.status; d.vendor = prev.vendor; d.model = prev.model; d.version = prev.version; d.source = prev.source; }
    if (prev.depth != null) d.depth = Math.min(prev.depth, input.depth ?? prev.depth);
  } else { d = { discoveredAt: new Date().toISOString(), ...input }; store.state.devices.push(d); }
  return d;
}
function registerConnection(d, connection) {
  const sessionKey = randomUUID(); sessions.set(d.id, { connection, sessionKey });
  connection.on('close', () => {
    if (sessions.get(d.id)?.sessionKey !== sessionKey) return;
    sessions.delete(d.id); d.connected = false; d.status = 'disconnected'; if (d.kind === 'serial' && d.path) seenPorts.delete(d.path); store.persist().then(emit).catch(e => console.error('设备状态保存失败:', e.message));
  });
}
async function connectDevice(options) {
  if (store.state.devices.length >= 250) fail('当前最多保存 250 台设备，请先导出并清理旧拓扑。');
  if (options.kind === 'serial') {
    const ports = await listSerialPorts(); if (!ports.some(p => p.path === options.path)) fail('所选串口不存在，请刷新串口列表。');
    if (![9600, 19200, 38400, 57600, 115200].includes(Number(options.baudRate || 9600))) fail('不支持的波特率');
  } else if (options.kind === 'ssh') { validHost(options.host); validPort(options.port); if (!options.fingerprint || options.fingerprint.length > 150) fail('SSH 连接必须提供经核对的主机指纹'); }
  else fail('连接方式无效');
  checkVendor(options.vendor || 'auto', true);
  if (typeof (options.username || '') !== 'string' || typeof (options.password || '') !== 'string' || (options.username || '').length > 128 || (options.password || '').length > 1024 || /[\r\n\x00]/.test((options.username || '') + (options.password || ''))) fail('登录凭据格式无效');
  const existing = store.state.devices.find(d => (options.kind === 'serial' && d.path === options.path) || (options.kind === 'ssh' && d.managementIp === options.host));
  if (existing?.connected) fail('此设备已有连接，请先断开原会话。', 409);
  const connection = new DeviceConnection();
  try {
    const safeOptions = { ...options, baudRate: Number(options.baudRate || 9600), port: Number(options.port || 22), fingerprint: options.fingerprint?.trim().replace(/=+$/, '') };
    if (!safeOptions.username) delete safeOptions.username;
    if (!safeOptions.password) delete safeOptions.password;
    await connection.connect(safeOptions);
    const info = await identify(connection, options.vendor || 'auto');
    const d = upsertDevice({ id: existing?.id || `device-${randomUUID()}`, name: info.name || options.host || options.path, vendor: info.vendor, model: info.model, version: info.version, managementIp: options.kind === 'ssh' ? options.host : '', kind: options.kind, path: options.kind === 'serial' ? options.path : '', connected: true, status: 'connected', source: options.kind, depth: 0, lastSeen: new Date().toISOString() });
    registerConnection(d, connection); await store.persist(); await store.audit('设备连接', `${d.name} · ${options.kind} · ${info.pagingWarning ? '分页关闭命令未获支持，使用传输层分页处理' : '只读身份查询完成'}`); emit(); return d;
  } catch (e) { await connection.close().catch(() => {}); throw e; }
}
function addLog(job, message, level = 'info') { job.logs.push({ time: new Date().toISOString(), message: redact(message), level }); job.logs = job.logs.slice(-120); job.message = redact(message); emit(); }
async function startJob(type, work) {
  busyCheck(); const job = { id: randomUUID(), type, status: 'queued', createdAt: new Date().toISOString(), progress: 0, total: 1, logs: [], message: '任务已排队', backupIds: [] };
  activeTask = job.id; store.state.jobs.unshift(job); store.state.jobs = store.state.jobs.slice(0, 60); await store.persist(); emit();
  setImmediate(async () => {
    job.status = 'running'; emit();
    try { await work(job); job.status = job.cancelRequested ? 'cancelled' : 'completed'; addLog(job, job.cancelRequested ? '已停止后续步骤；已完成的配置不会撤销，请核对设备。' : '任务完成，请根据日志核对结果。'); }
    catch (e) { job.status = job.cancelRequested ? 'cancelled' : 'failed'; addLog(job, e.message, 'error'); }
    finally { job.endedAt = new Date().toISOString(); activeTask = null; await store.audit(type === 'discover' ? '拓扑发现' : '配置执行', `${job.id} · ${job.message}`, job.status).catch(e => console.error('审计保存失败', e.message)); await store.persist().catch(e => console.error('任务保存失败', e.message)); emit(); }
  });
  return job;
}
function checkCancelled(job) { if (job.cancelRequested) throw new Error('用户已请求停止；不会继续发送下一条命令。'); }
async function collectNeighbors(d, connection, job) {
  const profile = vendorProfile(d.vendor); const all = [];
  for (const cmd of profile.neighborsCommands) {
    checkCancelled(job); addLog(job, `${d.name} > ${cmd}`);
    const output = await connection.run(cmd);
    if (cliFailed(output)) { addLog(job, `${d.name}：${cmd} 不支持或权限不足`, 'warning'); continue; }
    const parsed = parseNeighbors(output, d.vendor); all.push(...parsed);
    if (!parsed.length && output.trim()) addLog(job, `${d.name}：未解析到邻居；可能未启用邻居协议、无邻居或输出格式暂不支持。`, 'warning');
  }
  const now = new Date().toISOString(); const found = [], newLinks = [];
  for (const n of all) {
    if (!n.name && !n.chassisId && !n.managementIp) continue;
    if (store.state.devices.length >= 250) { addLog(job, '达到设备数量上限，后续邻居不再入库。', 'warning'); break; }
    const name = n.name || n.chassisId || n.managementIp;
    const neighbor = upsertDevice({ id: `neighbor-${digest([n.managementIp || n.chassisId || name]).slice(0, 20)}`, name, vendor: detectVendor(`${n.description || ''} ${name}`), managementIp: n.managementIp || '', chassisId: n.chassisId || '', model: '', source: n.protocol, status: 'discovered', depth: (d.depth || 0) + 1, lastSeen: now });
    if (neighbor.id === d.id) continue;
    const key = digest([d.id, neighbor.id, n.localPort, n.remotePort]).slice(0, 24);
    const reverse = store.state.links.find(l => l.source === neighbor.id && l.target === d.id && l.localPort === n.remotePort && l.remotePort === n.localPort);
    const link = { id: reverse?.id || key, source: d.id, target: neighbor.id, localPort: n.localPort || '未知端口', remotePort: n.remotePort || '未知端口', protocol: n.protocol || 'LLDP', lastSeen: now };
    if (!newLinks.some(l => l.id === link.id)) newLinks.push(link);
    if (!found.some(x => x.id === neighbor.id)) found.push(neighbor);
  }
  // Preserve historical links when parsing is empty; never silently call missing neighbors offline.
  if (all.length) { store.state.links = store.state.links.filter(l => l.source !== d.id && !newLinks.some(n => n.id === l.id)); store.state.links.push(...newLinks); }
  d.lastSeen = now; addLog(job, `${d.name}：发现 ${found.length} 个邻居。`); await store.persist(); emit(); return found;
}
async function discover(rootId, options = {}) {
  const root = deviceById(rootId); connected(rootId); const recursive = options.recursive === true;
  const maxNodes = Math.min(50, Math.max(1, Number(options.maxNodes) || 20)), depth = Math.min(5, Math.max(1, Number(options.depth) || 3));
  const cfg = structuredClone(store.state.settings.discovery), sshPassword = store.secrets.sshPassword;
  if (recursive && (!cfg.scope || !cfg.username || !sshPassword)) fail('递归发现需要先保存管理范围、SSH 用户名和密码。');
  return startJob('discover', async job => {
    const queue = [{ d: root, depth: 0 }], visited = new Set();
    while (queue.length && visited.size < maxNodes) {
      checkCancelled(job); const entry = queue.shift(); const d = entry.d; if (visited.has(d.id)) continue; visited.add(d.id); job.total = Math.min(maxNodes, visited.size + queue.length);
      let connection = sessions.get(d.id)?.connection, temporary = false;
      try {
        if (!connection?.isConnected) {
          const known = cfg.hosts.find(h => h.host === d.managementIp);
          if (!d.managementIp || !inScope(d.managementIp, cfg.scope) || !known?.fingerprint) { addLog(job, `${d.name}：仅显示邻居；缺少允许范围内的管理 IP 或已核对主机指纹。`, 'warning'); job.progress++; continue; }
          connection = new DeviceConnection(); temporary = true;
          await connection.connect({ kind: 'ssh', host: d.managementIp, port: known.port || 22, username: cfg.username, password: sshPassword, fingerprint: known.fingerprint, vendor: known.vendor });
          const info = await identify(connection, known.vendor === 'unknown' ? 'auto' : known.vendor || 'auto'); Object.assign(d, { vendor: info.vendor, model: info.model, version: info.version });
        }
        const found = await collectNeighbors(d, connection, job);
        if (recursive && entry.depth < depth) for (const n of found) if (!visited.has(n.id) && !queue.some(q => q.d.id === n.id)) queue.push({ d: n, depth: entry.depth + 1 });
      } catch (e) { if (d.id === root.id || job.cancelRequested) throw e; addLog(job, `${d.name}：${e.message}；该邻居未继续发现。`, 'warning'); }
      finally { if (temporary && connection) await connection.close().catch(() => {}); }
      job.progress++; await store.persist(); emit();
      if (!recursive) break;
    }
    if (queue.length) addLog(job, '达到发现设备数上限，剩余设备未继续访问。', 'warning');
    root.lastDiscoveryAt = new Date().toISOString();
    await store.persist();
    addLog(job, '只读发现结束。图中仅含协议可见邻居，不能据此断言已覆盖整个网络。');
  });
}

// 定时只读刷新：不新建任务记录，只在有变化时写审计，避免污染任务列表。
async function refreshTopology(id) {
  const device = store.state.devices.find(item => item.id === id);
  const session = sessions.get(id);
  if (!device || !session?.connection.isConnected) return null;
  busyCheck();
  activeTask = 'topology-refresh'; emit();
  try {
    const knownLinks = new Set(store.state.links.map(link => link.id));
    const deviceCount = store.state.devices.length;
    await collectNeighbors(device, session.connection, { logs: [], progress: 0, total: 1 });
    const addedDevices = store.state.devices.length - deviceCount;
    const addedLinks = store.state.links.filter(link => !knownLinks.has(link.id)).length;
    device.lastDiscoveryAt = new Date().toISOString();
    device.lastSeen = device.lastDiscoveryAt;
    device.autoRefreshError = '';
    await store.persist();
    if (addedDevices || addedLinks) await store.audit('拓扑自动刷新', `${device.name} · 新增 ${addedDevices} 台设备 / ${addedLinks} 条链路`).catch(() => {});
    return { addedDevices, addedLinks };
  } finally {
    activeTask = null; emit();
  }
}
// 每 10 秒检查一次，只对到期的已连接设备做一次只读邻居刷新。
let refreshCursor = 0;
const topologyTimer = setInterval(async () => {
  if (stopping || activeTask) return;
  const interval = Math.max(0, Number(store.state.settings.discovery.autoRefresh) || 0);
  if (!interval) return;
  const now = Date.now();
  const candidates = [...sessions.keys()].filter(id => {
    const device = store.state.devices.find(item => item.id === id);
    if (!device || device.status !== 'connected') return false;
    const last = device.lastDiscoveryAt ? Date.parse(device.lastDiscoveryAt) : 0;
    return !last || now - last >= interval * 1000;
  });
  if (!candidates.length) return;
  refreshCursor %= candidates.length;
  const id = candidates[refreshCursor++];
  try {
    await refreshTopology(id);
  } catch (error) {
    const device = store.state.devices.find(item => item.id === id);
    const name = device?.name || id;
    if (device) {
      // 失败也推进时间戳：否则每 10 秒重试一次，审计会被同一错误刷屏。
      device.lastDiscoveryAt = new Date().toISOString();
      device.autoRefreshError = redact(error.message);
      await store.persist().catch(() => {});
    }
    await store.audit('拓扑自动刷新', `${name}：${error.message}`, 'failed').catch(() => {});
    emit();
  }
}, 10000);
topologyTimer.unref();

// 桥接脚本内容只与端口有关：进程内缓存 + 原子写入，避免并发配对时互相覆盖。
let bridgeScript = null;
async function ensureBridgeScript() {
  if (bridgeScript) return bridgeScript;
  bridgeScript = (async () => {
    const scriptPath = join(DATA, 'NetPilot-SecureCRT.vbs');
    const template = await readFile(join(ROOT, 'scripts', 'NetPilot-SecureCRT.vbs'), 'utf8');
    const script = template.replace('Const NETPILOT_PORT = 47831', `Const NETPILOT_PORT = ${PORT}`);
    const temporary = `${scriptPath}.${randomUUID()}.tmp`;
    // WSH 只在 UTF-16LE + BOM 下可靠识别中文；UTF-8 会被按 ANSI 解释成乱码。
    await writeFile(temporary, '\ufeff' + script, 'utf16le');
    await rename(temporary, scriptPath);
    return scriptPath;
  })().catch(error => { bridgeScript = null; throw new Error(`无法生成 SecureCRT 桥接脚本：${error.message}`); });
  return bridgeScript;
}
app.post('/api/securecrt/prepare', route(async (req, res) => {
  const vendor = checkVendor(req.body.vendor || 'auto', true);
  const scriptPath = await ensureBridgeScript();
  const pair = secureCRT.prepare(vendor);
  res.json({ ...pair, scriptPath });
}));
app.get('/api/securecrt/status/:id', route(async (req, res) => res.json(secureCRT.status(req.params.id))));
// Native SecureCRT scripts use a separate, limited bridge capability, never the browser CSRF token.
app.post('/bridge/attach', route(async (req, res) => {
  if (typeof req.body !== 'string' || req.body.length > 512) fail('桥接配对数据无效');
  if (store.state.devices.length >= 250) fail('设备记录已达到上限，请先清理旧拓扑');
  const fields = req.body.replace(/\r/g, '').split('\n');
  if (fields.length !== 3) fail('桥接配对数据格式无效');
  const { connection, vendor, pairingId } = secureCRT.attach({ code: fields[0], name: fields[1], prompt: fields[2] });
  // 绑定本身不占用全局任务锁：多台设备可以接连配对，识别在后台串行落库。
  res.type('text/plain').send(connection.token);
  setImmediate(async () => {
    let device;
    try {
      const info = await identify(connection, vendor);
      const existing = store.state.devices.find(d => d.kind === 'securecrt' && d.path === connection.info.path);
      if (store.state.devices.some(d => d.connected && (d.id === existing?.id || (info.name && d.name === info.name)))) fail('同名设备已有活动会话，请先解绑旧会话，避免将命令下发到错误的标签。', 409);
      device = upsertDevice({ id: existing?.id || `device-${randomUUID()}`, name: info.name || connection.info.path, vendor: info.vendor, model: info.model, version: info.version, managementIp: '', kind: 'securecrt', path: connection.info.path, source: 'SecureCRT', connected: true, status: 'connected', depth: 0, lastSeen: new Date().toISOString() });
      registerConnection(device, connection);
      await store.persist(); await store.audit('SecureCRT 绑定', `${device.name} · 已绑定脚本所在会话，仅查询身份和邻居。`);
      secureCRT.report(pairingId, 'connected');
    } catch (e) { await connection.close(); secureCRT.report(pairingId, 'failed', redact(e.message)); await store.audit('SecureCRT 绑定', e.message, 'failed').catch(() => {}); }
    finally { emit(); }
    if (!device?.connected) return;
    // 另一台设备可能正在发现中（全局任务锁），最多重试 3 次再放弃。
    for (let attempt = 0; attempt < 3; attempt++) {
      try { await discover(device.id); return; }
      catch (error) {
        if (error.status !== 409 || attempt === 2) { await store.audit('拓扑发现', error.message, 'failed').catch(() => {}); emit(); return; }
        await new Promise(resolve => setTimeout(resolve, 2500));
      }
    }
  });
}));
app.post('/bridge/poll', route(async (req, res) => { res.type('text/plain').send(secureCRT.authorize(req.headers['x-netpilot-bridge']).poll()); }));
app.post('/bridge/result', route(async (req, res) => {
  const connection = secureCRT.authorize(req.headers['x-netpilot-bridge']);
  connection.result({ taskId: req.headers['x-netpilot-task'], status: req.headers['x-netpilot-status'], prompt: req.headers['x-netpilot-prompt'], output: req.body });
  res.type('text/plain').send('ACK');
}));
app.post('/bridge/close', route(async (req, res) => { await secureCRT.authorize(req.headers['x-netpilot-bridge']).close(); res.type('text/plain').send('CLOSED'); }));
app.use('/bridge', (req, res) => res.status(404).json({ error: '桥接接口不存在' }));
app.post('/api/connect', route(async (req, res) => {
  busyCheck(); activeTask = 'connecting'; emit(); let device;
  try { device = await connectDevice(req.body); }
  catch (e) { await store.audit('设备连接', e.message, 'failed'); throw e; }
  finally { activeTask = null; emit(); }
  let job = null, warning = '';
  if (req.body.discover === true) {
    // 设备已经连上了：发现失败不应该让用户以为连接失败，单独提示并要求手动重试。
    try { job = await discover(device.id); }
    catch (error) { warning = `设备已连接，但邻居发现未开始：${error.message}`; await store.audit('拓扑发现', warning, 'failed').catch(() => {}); }
  }
  res.json({ device, ...(job ? { jobId: job.id } : {}), ...(warning ? { warning } : {}) });
}));
app.post('/api/disconnect', route(async (req, res) => { busyCheck(); const d = deviceById(req.body.deviceId); await sessions.get(d.id)?.connection.close(); sessions.delete(d.id); d.connected = false; d.status = 'disconnected'; await store.audit('断开连接', d.name); emit(); res.json({ ok: true }); }));
app.post('/api/discover', route(async (req, res) => res.json({ jobId: (await discover(req.body.deviceId, req.body)).id })));
app.post('/api/terminal', route(async (req, res) => {
  busyCheck(); const lines = commandLines(req.body.command); if (lines.length !== 1 || !isReadonly(lines[0])) fail('只读终端仅允许白名单内的完整查询命令；其它命令请使用配置预检。');
  const d = deviceById(req.body.deviceId), s = connected(d.id); activeTask = 'terminal'; emit();
  try { const output = await s.connection.run(lines[0]); await store.audit('只读查询', `${d.name} · ${lines[0]}`, cliFailed(output) ? 'failed' : 'ok'); res.json({ output, ok: !cliFailed(output) }); }
  finally { activeTask = null; emit(); }
}));
app.post('/api/plans', route(async (req, res) => {
  busyCheck(); const ids = req.body.deviceIds;
  if (!Array.isArray(ids) || !ids.length || ids.length > 20 || new Set(ids).size !== ids.length) fail('请选中 1–20 台不同的已连接设备');
  const devices = ids.map(id => { connected(id); return deviceById(id); });
  let perDevice;
  if (req.body.template) {
    // 内置方案按每台设备自己的厂商生成命令，因此允许华为/华三/锐捷/Cisco 混选。
    perDevice = devices.map(d => ({ id: d.id, name: d.name, vendor: d.vendor, commands: commandLines(buildTemplate(d.vendor, req.body.template, req.body.params || {}).join('\n')) }));
  } else {
    if (new Set(devices.map(d => d.vendor)).size > 1) fail('自定义命令只能用于同厂商设备；多厂商请改用内置方案（设备体检 / 读取配置 / VLAN / Trunk / Access / 改名）。');
    const shared = commandLines(req.body.commands);
    perDevice = devices.map(d => ({ id: d.id, name: d.name, vendor: d.vendor, commands: shared }));
  }
  const commands = [...new Set(perDevice.flatMap(item => item.commands))];
  const assessment = assessCommands(commands);
  for (const [id, p] of plans) if (p.expires < Date.now()) plans.delete(id);
  if (plans.size > 100) plans.clear();
  const id = randomUUID(), expires = Date.now() + 5 * 60 * 1000;
  const plan = { id, commands, perDevice, devices: structuredClone(devices), expiresAt: new Date(expires).toISOString(), ...assessment };
  plans.set(id, { ...plan, expires, bindings: devices.map(d => [d.id, connected(d.id).sessionKey]) });
  await store.audit('配置预检', `${devices.map(d => d.name).join(', ')} · ${perDevice.reduce((n, item) => n + item.commands.length, 0)} 行 · ${assessment.blocked.length ? '已拦截' : '等待确认'}`);
  res.json(plan);
}));
app.post('/api/execute', route(async (req, res) => {
  busyCheck(); const plan = plans.get(req.body.planId); if (!plan || plan.expires < Date.now()) fail('预检已过期或已使用，请重新预检。', 409);
  if (req.body.confirmation !== '确认执行' || req.body.acceptRisk !== true) fail('必须确认影响范围并输入“确认执行”');
  if (plan.blocked.length) fail('预检未通过，禁止执行');
  for (const [id, key] of plan.bindings) if (connected(id).sessionKey !== key) fail('设备连接已变化，请重新预检。', 409);
  plans.delete(plan.id);
  const job = await startJob('configure', async job => {
    job.total = plan.perDevice.reduce((sum, item) => sum + item.commands.length, 0);
    if (plan.backupRequired) {
      for (const d of plan.devices) {
        checkCancelled(job); const connection = connected(d.id).connection;
        const vrp = ['huawei', 'h3c'].includes(d.vendor);
        const prompt = connection.info?.prompt || '';
        const promptOk = vrp ? /^<[^<>]+>$/.test(prompt) : /^[\w.:-]+#$/.test(prompt);
        if (!promptOk) throw new Error(`${d.name} 当前提示符 ${prompt || '未知'} 不适合下发配置；${vrp ? '请先 return 回到用户视图（<设备名>）' : '请先 enable 进入特权模式（设备名#）'}，再重新连接。`);
        addLog(job, `${d.name}：备份当前配置…`);
        const backup = await connection.run(vendorProfile(d.vendor).backupCommand, { timeoutMs: 45000 });
        if (cliFailed(backup) || backup.trim().length < 40 || !/(?:^|\n)\s*(?:version\s|sysname\s|hostname\s|interface\s|vlan\s|!|#)/i.test(backup)) throw new Error(`${d.name} 配置备份失败或内容异常，未继续写配置。`);
        const id = await store.saveBackup({ deviceId: d.id, deviceName: d.name, vendor: d.vendor }, backup); job.backupIds.push(id); await store.persist();
        addLog(job, `${d.name}：配置备份已用 Windows DPAPI 加密保存。`);
      }
    }
    for (const d of plan.devices) {
      const connection = connected(d.id).connection;
      const entry = plan.perDevice.find(item => item.id === d.id) || { commands: [] };
      for (const command of entry.commands) {
        checkCancelled(job); addLog(job, `${d.name} > ${command}`);
        const output = await connection.run(command, { requireEcho: !isReadonly(command) });
        if (cliFailed(output)) throw new Error(`${d.name} 拒绝命令，任务已停止。部分命令可能已经生效；请在设备上检查，不会自动重放或回滚。`);
        job.progress++; await store.persist(); emit();
      }
      addLog(job, `${d.name}：命令已返回提示符；请验证业务状态。未自动保存到启动配置。`);
    }
  });
  res.json({ jobId: job.id });
}));
app.post('/api/jobs/:id/cancel', route(async (req, res) => {
  const job = store.state.jobs.find(j => j.id === req.params.id); if (!job || !['queued', 'running'].includes(job.status)) fail('没有可停止的运行任务');
  job.cancelRequested = true; addLog(job, '已请求停止：等待当前命令返回或超时后，不再发送下一条命令。', 'warning'); await store.persist(); res.json({ ok: true });
}));
app.get('/api/backups', (req, res) => res.json({ backups: store.state.backups, encryption: store.safeSettings().security.encryption }));
app.get('/api/backups/:id', route(async (req, res) => { const backup = await store.readBackup(req.params.id); res.type('text/plain').send(backup.content); }));
app.put('/api/settings', route(async (req, res) => {
  if (aiBusy) fail('模型请求正在进行，请完成后再修改设置。', 409);
  const current = structuredClone(store.state.settings), body = req.body, nextSecrets = {};
  if (body.ai) {
    const nextAi = validateAi({ ...current.ai, ...body.ai });
    if (new URL(nextAi.baseUrl).origin !== new URL(current.ai.baseUrl).origin && store.secrets.apiKey && !body.ai.apiKey && body.ai.clearKey !== true) fail('模型服务地址已变化：请提供新服务的密钥或明确删除旧密钥，禁止将旧密钥转发到新地址。');
    current.ai = nextAi;
    if (body.ai.apiKey) { if (typeof body.ai.apiKey !== 'string' || body.ai.apiKey.length > 4096 || /[\r\n]/.test(body.ai.apiKey)) fail('API Key 格式无效'); nextSecrets.apiKey = body.ai.apiKey.trim(); }
    if (body.ai.clearKey === true) nextSecrets.apiKey = '';
  }
  if (body.discovery) {
    const v = body.discovery; parseScopes(v.scope ?? current.discovery.scope);
    const username = v.username ?? current.discovery.username; if (typeof username !== 'string' || username.length > 128 || /[\r\n\x00]/.test(username)) fail('SSH 用户名格式无效');
    const hosts = v.hosts ?? current.discovery.hosts; if (!Array.isArray(hosts) || hosts.length > 50) fail('最多保存 50 个 SSH 指纹');
    const autoRefresh = Number(v.autoRefresh ?? current.discovery.autoRefresh ?? 0);
    if (!Number.isInteger(autoRefresh) || autoRefresh < 0 || autoRefresh > 3600 || (autoRefresh > 0 && autoRefresh < 30)) fail('自动刷新间隔需为 0（关闭）或 30–3600 秒');
    current.discovery = { username, scope: v.scope ?? current.discovery.scope, autoRefresh, hosts: hosts.map(h => ({ host: validHost(h.host), port: validPort(h.port), vendor: checkVendor(h.vendor || 'auto', true), fingerprint: (() => { if (typeof h.fingerprint !== 'string' || !/^SHA256:[A-Za-z0-9+/]{43}$/.test(h.fingerprint.trim())) fail('指纹必须为 SHA256: 格式'); return h.fingerprint.trim(); })() })) };
    if (v.password) { if (typeof v.password !== 'string' || v.password.length > 1024 || /[\r\n\x00]/.test(v.password)) fail('SSH 密码格式无效'); nextSecrets.sshPassword = v.password; }
    if (v.clearPassword === true) nextSecrets.sshPassword = '';
  }
  if (body.serial) {
    const s = { ...current.serial, ...body.serial };
    // Windows 用 COM3，Linux 用 /dev/ttyUSB0 / /dev/ttyACM0 / /dev/ttyS0。
    if (typeof s.path !== 'string' || (s.path && !/^(?:COM\d+|\/dev\/tty(?:USB|ACM|S)\d+)$/i.test(s.path))) fail('串口格式应为 COM3（Windows）或 /dev/ttyUSB0（Linux）');
    if (![9600, 19200, 38400, 57600, 115200].includes(Number(s.baudRate))) fail('不支持的波特率');
    current.serial = { path: s.path, baudRate: Number(s.baudRate), autoConnect: s.autoConnect === true, vendor: checkVendor(s.vendor || 'auto', true) };
    if (current.serial.autoConnect && !current.serial.path) fail('启用自动连接前请指定唯一串口');
  }
  await store.saveSettings(current, nextSecrets); plans.clear(); await store.audit('设置保存', '已更新本机设置；密钥值不写入审计日志。'); emit(); res.json(store.safeSettings());
}));
function aiGate(req) {
  if (req.body.consent !== true) fail('调用模型前需要明确同意发送本次问题。');
  if (aiBusy) fail('已有模型请求正在进行，请稍后再试。', 429);
  aiCalls = aiCalls.filter(t => t > Date.now() - 10 * 60 * 1000);
  if (aiCalls.length >= 30) fail('10 分钟内最多 30 次模型请求，请稍后再试。', 429);
  aiBusy = true; aiCalls.push(Date.now());
}
function aiContext(req) {
  const topology = req.body.includeContext === true ? { devices: store.state.devices.map(({ name, vendor, model, managementIp, connected }) => ({ name, vendor, model, managementIp, connected })), links: store.state.links.map(({ source, target, localPort, remotePort, protocol }) => ({ source, target, localPort, remotePort, protocol })) } : null;
  // 目标设备只带厂商/型号/版本：足够让模型选对语法，又不泄露地址与配置。
  const raw = req.body.target;
  const text = (v, max) => typeof v === 'string' ? v.replace(/[\x00-\x1f\x7f]/g, '').slice(0, max) : '';
  const target = raw && typeof raw === 'object' && !Array.isArray(raw) ? {
    vendor: VENDORS.some(v => v.id === raw.vendor) ? raw.vendor : 'unknown',
    model: text(raw.model, 80), version: text(raw.version, 80),
    transport: ['securecrt', 'serial', 'ssh'].includes(raw.kind) ? raw.kind : 'unknown',
  } : null;
  return { context: topology ? { ...topology, ...(target ? { target } : {}) } : target ? { target } : null, topology, target };
}
async function aiRequest(req, test = false) {
  aiGate(req);
  try {
    const { context, topology, target } = aiContext(req);
    const result = await chatCompletion(store.state.settings.ai, store.secrets.apiKey, test ? [{ role: 'user', content: '请用一句简短中文确认网络运维助手连接已建立，不要输出任何配置命令。' }] : req.body.messages, context);
    await store.audit(test ? '模型连接测试' : 'AI 请求', `${store.state.settings.ai.provider} · ${result.model} · ${topology ? '用户同意附加拓扑' : target ? '仅附加目标设备型号' : '未附加拓扑'}`); emit(); return result;
  } catch (e) { await store.audit('AI 请求失败', e.name === 'TimeoutError' ? '模型响应超时' : e.message, 'failed'); throw e; }
  finally { aiBusy = false; }
}
app.post('/api/ai/test', route(async (req, res) => { const r = await aiRequest(req, true); res.json({ model: r.model, reply: r.content }); }));
app.post('/api/ai/chat', route(async (req, res) => res.json(await aiRequest(req))));
// 流式对话：边生成边回传，前端可逐字显示并随时中止。
app.post('/api/ai/chat/stream', route(async (req, res) => {
  aiGate(req);
  res.set({ 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders();
  const abort = new AbortController();
  res.on('close', () => abort.abort());
  const send = payload => { if (!res.writableEnded) res.write(`data: ${JSON.stringify(payload)}\n\n`); };
  const { context, topology, target } = aiContext(req);
  try {
    const result = await chatStream(store.state.settings.ai, store.secrets.apiKey, req.body.messages, context, text => send({ t: text }), { signal: abort.signal });
    send({ done: true, model: result.model });
    await store.audit('AI 请求（流式）', `${store.state.settings.ai.provider} · ${result.model} · ${topology ? '用户同意附加拓扑' : target ? '仅附加目标设备型号' : '未附加拓扑'}`).catch(() => {});
  } catch (e) {
    const aborted = e.name === 'AbortError' || abort.signal.aborted;
    send({ error: aborted ? '已停止生成' : (e.name === 'TimeoutError' ? '模型响应超时' : redact(e.message)) });
    if (!aborted) await store.audit('AI 请求失败', e.name === 'TimeoutError' ? '模型响应超时' : e.message, 'failed').catch(() => {});
  } finally {
    aiBusy = false;
    if (!res.writableEnded) res.end();
    emit();
  }
}));
app.post('/api/topology/clear', route(async (req, res) => {
  busyCheck(); if (sessions.size) fail('请先断开全部设备连接'); if (req.body.confirmation !== '清空拓扑') fail('需输入“清空拓扑”确认');
  store.state.devices = []; store.state.links = []; plans.clear(); await store.audit('清空拓扑', '仅删除本机设备与邻接记录，不修改设备、审计或配置备份。'); emit(); res.json({ ok: true });
}));
app.use('/api', (req, res) => res.status(404).json({ error: '接口不存在' }));
const dist = join(ROOT, 'dist');
if (existsSync(join(dist, 'index.html'))) {
  // Vite 产物带内容哈希：静态资源可强缓存，入口 HTML 每次校验。
  app.use(express.static(dist, {
    dotfiles: 'deny', etag: true, maxAge: 0,
    setHeaders: (res, filePath) => {
      if (filePath.includes(`${dist}\\assets\\`) || filePath.includes(`${dist}/assets/`)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      else res.setHeader('Cache-Control', 'no-cache');
    },
  }));
  app.get('/', (req, res) => res.sendFile(join(dist, 'index.html')));
}
else app.get('/', (req, res) => res.type('text/plain').send('NetPilot API 已运行。开发预览请打开 http://127.0.0.1:5173，正式使用前执行 npm run build。'));
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const status = err.status || (err.name === 'TimeoutError' ? 504 : 400);
  const message = err.name === 'TimeoutError' || err.name === 'AbortError' ? '操作已超时；请检查服务或设备状态，不要直接重复配置任务。' : err.type === 'entity.parse.failed' ? '请求 JSON 无效' : err.message || '操作失败';
  res.status(status).json({ error: redact(message) });
});
const server = app.listen(PORT, BIND, () => console.log(`NetPilot server: http://${LOOPBACK_BIND ? '127.0.0.1' : BIND}:${PORT}\nMode=${LOOPBACK_BIND ? '本机' : '对外部署'}${ACCESS_TOKEN ? ' · 已启用访问口令' : ''}\nPID=${process.pid}\nProject=${ROOT}`));
server.on('error', e => { console.error(e.code === 'EADDRINUSE' ? `端口 ${PORT} 已被占用，请使用原工作台或设置 NETPILOT_PORT。` : e.message); process.exitCode = 1; });
const sessionTimer = setInterval(() => {
  const now = Date.now();
  for (const [sid, expires] of authSessions) if (expires <= now) authSessions.delete(sid);
  for (const [address, list] of loginAttempts) {
    const kept = list.filter(t => t > now - 60000);
    if (kept.length) loginAttempts.set(address, kept); else loginAttempts.delete(address);
  }
}, 300000);
sessionTimer.unref();
// Opt-in: a specific configured serial path gets one attempt per physical appearance.
let lastAutoSignature = '';
const autoTimer = setInterval(async () => {
  if (stopping || activeTask || secureCRT.connections.size || secureCRT.pairings.size) return;
  const cfg = store.state.settings.serial;
  const signature = JSON.stringify(cfg); if (signature !== lastAutoSignature) { seenPorts.clear(); lastAutoSignature = signature; }
  if (!cfg.autoConnect || !cfg.path || store.state.devices.some(d => d.path === cfg.path && d.connected)) return;
  try {
    const ports = await listSerialPorts(); const present = ports.some(p => p.path === cfg.path);
    if (!present) { seenPorts.delete(cfg.path); return; }
    if (seenPorts.has(cfg.path) || activeTask) return;
    seenPorts.add(cfg.path); activeTask = 'auto-connect'; emit(); let d;
    try { d = await connectDevice({ kind: 'serial', path: cfg.path, baudRate: cfg.baudRate, vendor: cfg.vendor }); }
    finally { activeTask = null; emit(); }
    if (d) await discover(d.id);
  } catch (e) { await store.audit('自动连接', `尝试已停止：${e.message}。需要口令时请手动连接。`, 'failed').catch(() => {}); emit(); }
}, 5000);
autoTimer.unref();
export async function shutdown() { if (stopping) return; stopping = true; clearInterval(autoTimer); clearInterval(sessionTimer); clearInterval(topologyTimer); await secureCRT.close(); for (const s of sessions.values()) await s.connection.close().catch(() => {}); for (const res of streams) res.end(); await store.persist().catch(() => {}); await new Promise(resolve => server.close(resolve)); }
function onSignal() { const force = setTimeout(() => process.exit(0), 4000); force.unref(); shutdown().then(() => { clearTimeout(force); process.exit(0); }); }
process.on('SIGINT', onSignal); process.on('SIGTERM', onSignal);
export { server, store };
