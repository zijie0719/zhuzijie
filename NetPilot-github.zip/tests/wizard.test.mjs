import test from 'node:test';
import assert from 'node:assert/strict';
import { WIZARD_CATALOG, WIZARD_STEPS, buildWizard } from '../server/wizard.mjs';
import { commandLines, assessCommands, isReadonly } from '../server/policy.mjs';
import { buildTemplate } from '../server/vendors.mjs';

const standard = [
  { id: 'hostname', params: { name: 'CORE-SW-01' } },
  { id: 'ssh', params: {} },
  { id: 'vlan-create', params: { vlans: '10,20-22' } },
  { id: 'access-port', params: { interface: 'GigabitEthernet0/0/1', vlan: '10' } },
  { id: 'trunk-port', params: { interface: 'GigabitEthernet0/0/24', vlans: '10,20-22' } },
  { id: 'svi', params: { vlan: '10', ip: '192.168.10.1', mask: '24' } },
  { id: 'stp-mode', params: {} },
  { id: 'portfast', params: { interface: 'GigabitEthernet0/0/1' } },
  { id: 'lacp', params: { group: '1', interfaces: 'GigabitEthernet0/0/2,GigabitEthernet0/0/3' } },
  { id: 'port-security', params: { interface: 'GigabitEthernet0/0/5', maximum: '2' } },
  { id: 'dhcp-snooping', params: { trust: 'GigabitEthernet0/0/24' } },
  { id: 'dhcp-pool', params: { name: 'VLAN10', network: '192.168.10.0', mask: '255.255.255.0', gateway: '192.168.10.1' } },
  { id: 'default-route', params: { nexthop: '192.168.1.254' } },
  { id: 'ospf', params: { process: '1', network: '192.168.10.0', wildcard: '0.0.0.255', area: '0' } },
  { id: 'vrrp', params: { vlan: '10', vrid: '10', vip: '192.168.10.254', priority: '120' } },
  { id: 'lldp', params: {} },
  { id: 'health', params: {} },
];

test('目录结构完整，VSU 标记为仅锐捷', () => {
  assert.equal(WIZARD_CATALOG.groups.length, 8);
  assert.equal(WIZARD_CATALOG.steps.length, 22);
  const vsu = WIZARD_CATALOG.steps.find(step => step.id === 'vsu');
  assert.deepEqual(vsu.vendors, ['ruijie']);
  for (const step of WIZARD_CATALOG.steps) {
    assert.ok(step.title && step.desc && Array.isArray(step.params));
    assert.equal(Object.hasOwn(step, 'build'), false, '前端目录不应包含构建函数');
  }
});

for (const vendor of ['huawei', 'h3c', 'ruijie', 'cisco']) {
  test(`${vendor}: 标准方案可生成且能通过预检白名单`, () => {
    const result = buildWizard(vendor, standard);
    const plain = result.commands.filter(line => !line.startsWith('#'));
    assert.ok(plain.length >= 45);
    const lines = commandLines(plain.join('\n'));
    const assessment = assessCommands(lines);
    assert.deepEqual(assessment.blocked, []);
    assert.equal(assessment.backupRequired, true);
    const text = plain.join('\n');
    assert.match(text, vendor === 'huawei' || vendor === 'h3c' ? /system-view/ : /configure terminal/);
    assert.match(text, /vlan 10/);
    assert.match(text, /vrrp (vrid )?10/);
  });
}

test('枚举参数缺省时使用第一项，而不是报缺参数', () => {
  const result = buildWizard('huawei', [{ id: 'stp-mode', params: {} }]);
  assert.match(result.commands.join('\n'), /stp mode rstp/);
});

test('VSU 在其他厂商上明确报错', () => {
  assert.throws(() => buildWizard('cisco', [{ id: 'vsu', params: { domain: 1, member: 1, priority: 200 } }]), /锐捷/);
  assert.doesNotThrow(() => buildWizard('ruijie', [{ id: 'vsu', params: { domain: 1, member: 1, priority: 200 } }]));
});

test('非法接口 / VLAN / IP / 掩码在生成阶段就被拦住', () => {
  assert.throws(() => buildWizard('huawei', [{ id: 'svi', params: { vlan: '5000', ip: '192.168.1.1', mask: '24' } }]), /VLAN/);
  assert.throws(() => buildWizard('huawei', [{ id: 'svi', params: { vlan: '10', ip: '999.1.1.1', mask: '24' } }]), /地址/);
  assert.throws(() => buildWizard('huawei', [{ id: 'svi', params: { vlan: '10', ip: '192.168.1.1', mask: '255.0.255.0' } }]), /掩码/);
  assert.throws(() => buildWizard('huawei', [{ id: 'access-port', params: { interface: 'GigabitEthernet0/0/1;reboot', vlan: '10' } }]), /接口/);
  assert.throws(() => buildWizard('huawei', [{ id: 'lacp', params: { group: '1', interfaces: 'GigabitEthernet0/0/1,notaport' } }]), /接口/);
});

test('未知步骤、空方案与超量步骤都被拒绝', () => {
  assert.throws(() => buildWizard('huawei', []), /至少选择一个/);
  assert.throws(() => buildWizard('huawei', [{ id: 'rm-rf', params: {} }]), /未知步骤/);
  const many = Array.from({ length: 41 }, () => ({ id: 'lldp', params: {} }));
  assert.throws(() => buildWizard('huawei', many), /最多 40/);
  assert.throws(() => buildWizard('huawei', [{ id: 'hostname', params: {} }]), /缺少参数/);
});

test('内置模板 health / backup 在四厂商上都是只读命令', () => {
  for (const vendor of ['huawei', 'h3c', 'ruijie', 'cisco']) {
    const health = buildTemplate(vendor, 'health', {});
    assert.ok(health.length >= 5, `${vendor} 巡检命令过少`);
    for (const command of health) assert.ok(isReadonly(command), `${vendor} 的 ${command} 必须是只读命令`);
    const backup = buildTemplate(vendor, 'backup', {});
    assert.equal(backup.length, 1);
    assert.ok(isReadonly(backup[0]));
  }
  assert.throws(() => buildTemplate('huawei', 'health', { extra: 1 }), /未知参数/);
  assert.throws(() => buildTemplate('huawei', 'rm-rf', {}), /不支持的配置模板/);
});

test('步骤元数据不含可被前端执行的函数', () => {
  for (const step of WIZARD_STEPS) assert.equal(typeof step.build, 'function');
  assert.equal(WIZARD_CATALOG.steps.some(step => typeof step.build === 'function'), false);
});
