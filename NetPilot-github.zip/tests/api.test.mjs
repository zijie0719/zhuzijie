import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdir, mkdtemp, rm, rmdir } from 'node:fs/promises';
import { createServer } from 'node:net';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const fixture = fileURLToPath(new URL('./api-fixture.mjs', import.meta.url));
const temporaryRoot = join(root, '.test-data');

async function availablePort() {
  const listener = createServer();
  await new Promise((resolve, reject) => {
    listener.once('error', reject);
    listener.listen(0, '127.0.0.1', resolve);
  });
  const { port } = listener.address();
  await new Promise((resolve, reject) => listener.close(error => error ? reject(error) : resolve()));
  assert.ok(![47831, 5173].includes(port), 'never use the running application ports');
  return port;
}

function runFixture(port, directory) {
  return new Promise((resolve, reject) => {
    // Run the file directly: node:test still produces TAP, without a runner grandchild.
    // The ordinary npm test command therefore needs no experimental flag of its own.
    const env = { ...process.env, NETPILOT_PORT: String(port), NETPILOT_DATA_DIR: directory };
    delete env.NODE_TEST_CONTEXT;
    const child = spawn(process.execPath, ['--experimental-test-module-mocks', '--test-reporter=tap', fixture], {
      cwd: root, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '', stderr = '', timedOut = false;
    const timer = setTimeout(() => { timedOut = true; child.kill('SIGTERM'); }, 180_000);
    child.stdout.setEncoding('utf8').on('data', text => { stdout += text; });
    child.stderr.setEncoding('utf8').on('data', text => { stderr += text; });
    child.once('error', error => { clearTimeout(timer); reject(error); });
    child.once('close', (code, signal) => {
      clearTimeout(timer);
      resolve({ code, signal, stdout, stderr, timedOut });
    });
  });
}

test('backend API integration: isolated HTTP service and transport-only fixture', async t => {
  let createdParent = false;
  let directory;
  try {
    try { await mkdir(temporaryRoot); createdParent = true; }
    catch (error) { if (error.code !== 'EEXIST') throw error; }
    directory = await mkdtemp(join(temporaryRoot, 'api-regression-'));
    let port = 47839;
    let result = await runFixture(port, directory);
    // Do not probe or connect to an existing service. Retry only after our actual bind failed.
    if (!result.timedOut && /NETPILOT_API_PORT_IN_USE|端口 47839 已被占用/.test(result.stdout + result.stderr)) {
      port = await availablePort();
      t.diagnostic(`47839 was occupied; retrying our fixture on loopback port ${port}`);
      result = await runFixture(port, directory);
    }
    t.diagnostic(result.stdout.trim());
    if (result.stderr.trim()) t.diagnostic(result.stderr.trim());
    assert.equal(result.timedOut, false, 'fixture must terminate without a resident test process');
    assert.equal(result.signal, null, 'fixture should shut down normally');
    assert.equal(result.code, 0, `API fixture failed on port ${port}; see its TAP results above`);
    assert.match(result.stdout, /# fail 0\b/, 'the child must actually execute its node:test assertions');
  } finally {
    if (directory) await rm(directory, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
    if (createdParent) {
      try { await rmdir(temporaryRoot); }
      catch (error) { if (!['ENOENT', 'ENOTEMPTY', 'EEXIST'].includes(error.code)) throw error; }
    }
  }
});
