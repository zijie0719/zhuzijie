import test from 'node:test';
import assert from 'node:assert/strict';
import { SecureCRTBridge, validBridgePrompt } from '../server/securecrt.mjs';

function fixture(t) {
  let now = 1000000;
  const bridge = new SecureCRTBridge({ now: () => now });
  t.after(() => bridge.close());
  const prepared = bridge.prepare('huawei');
  const { connection, vendor } = bridge.attach({ code: prepared.code, name: 'Lab Console', prompt: '<LAB>' });
  return { bridge, prepared, connection, vendor, advance: ms => { now += ms; bridge.sweep(); } };
}

test('SecureCRT pairing is one-use, bounded, and keeps connection capability private', t => {
  const { bridge, prepared, connection, vendor } = fixture(t);
  assert.equal(vendor, 'huawei'); assert.equal(prepared.code.length, 24);
  assert.equal(bridge.authorize(connection.token), connection);
  assert.throws(() => bridge.authorize(prepared.code), /身份验证/);
  assert.throws(() => bridge.attach({ code: prepared.code, name: 'Other', prompt: '<LAB>' }), /已使用/);
  assert.equal(JSON.stringify(prepared).includes(connection.token), false);
});

test('SecureCRT pairing expiration, invalid prompt and duplicate sessions fail closed', t => {
  const { bridge, advance } = fixture(t);
  const p = bridge.prepare();
  assert.throws(() => bridge.attach({ code: p.code, name: 'Lab Console', prompt: '<LAB>' }), /已经绑定/);
  assert.throws(() => bridge.attach({ code: p.code, name: 'B', prompt: 'Password:' }), /CLI/);
  advance(600001);
  assert.throws(() => bridge.attach({ code: p.code, name: 'B', prompt: '<LAB>' }), /过期/);
});

test('SecureCRT queue delivers each command once and records the changed prompt', async t => {
  const { connection } = fixture(t);
  const result = connection.run('system-view', { requireEcho: true });
  const [id, timeout, echo, prompt, command] = connection.poll().split('\n');
  assert.equal(timeout, '15'); assert.equal(echo, '1'); assert.equal(prompt, '<LAB>'); assert.equal(command, 'system-view');
  assert.equal(connection.poll(), 'WAIT');
  await assert.rejects(connection.run('vlan 20'), /禁止并发/);
  connection.result({ taskId: id, status: 'ok', prompt: '[LAB]', output: 'system-view\r\n[LAB]' });
  assert.equal(await result, 'system-view\n[LAB]');
  assert.equal(connection.info.prompt, '[LAB]');
  assert.throws(() => connection.result({ taskId: id, status: 'ok', prompt: '[LAB]', output: '[LAB]' }), /禁止重放/);
});

test('SecureCRT stale prompt cannot acknowledge a configuration write', async t => {
  const { connection } = fixture(t);
  const result = connection.run('vlan 20', { requireEcho: true });
  const [id] = connection.poll().split('\n');
  connection.result({ taskId: id, status: 'ok', prompt: '<LAB>', output: '<LAB>' });
  await assert.rejects(result, /回显未通过/); assert.equal(connection.isConnected, false);
});

test('SecureCRT missing final prompt and script failures stop future commands', async t => {
  for (const failure of ['invalid-final', 'script-error']) {
    const { connection } = fixture(t);
    const result = connection.run('display version'); const [id] = connection.poll().split('\n');
    connection.result({ taskId: id, status: failure === 'script-error' ? 'error' : 'ok', prompt: '<LAB>', output: 'display version\nversion data without prompt' });
    await assert.rejects(result); await assert.rejects(connection.run('display version'), /已断开/);
  }
});

test('SecureCRT disconnected script heartbeat invalidates the connection without retry', t => {
  const { bridge, connection, advance } = fixture(t);
  advance(14000); assert.equal(connection.isConnected, true);
  assert.equal(connection.poll(), 'WAIT'); advance(14000); assert.equal(connection.isConnected, true);
  advance(1001); assert.equal(connection.isConnected, false);
  assert.throws(() => bridge.authorize(connection.token), /重新配对/);
});

test('SecureCRT active commands use their command deadline rather than idle heartbeat', async t => {
  const { connection, advance } = fixture(t);
  const result = connection.run('display current-configuration', { timeoutMs: 45000 });
  const [id] = connection.poll().split('\n'); advance(16000);
  assert.equal(connection.isConnected, true);
  connection.result({ taskId: id, status: 'ok', prompt: '<LAB>', output: 'version 8\n<LAB>' });
  assert.match(await result, /version/);
});

test('SecureCRT disconnect rejects pending work and does not send a terminal close command', async t => {
  const { connection } = fixture(t);
  const result = connection.run('display version');
  let closed = 0; connection.on('close', () => closed++);
  await connection.close(); await connection.close();
  await assert.rejects(result, /原 SecureCRT 会话不会被关闭/);
  assert.equal(closed, 1); assert.equal(connection.pending, null);
});

test('SecureCRT rejects command injection, unsupported prompts and unsolicited results', async t => {
  const { connection } = fixture(t);
  await assert.rejects(connection.run('display version\nreboot'), /单行/);
  await assert.rejects(connection.run('display version', { timeoutMs: 0 }), /超时/);
  assert.throws(() => connection.result({ taskId: 'other', status: 'ok', prompt: '<LAB>', output: '<LAB>' }), /禁止重放/);
  for (const p of ['<HW>', '[~HW]', '[*HW-GigabitEthernet0/0/1]', 'Cisco(config-if)#', 'RG#']) assert.equal(validBridgePrompt(p), true, p);
  for (const p of ['password:', 'Last login>', 'some config #', '<HW>foo']) assert.equal(validBridgePrompt(p), false, p);
});
