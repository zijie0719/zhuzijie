import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { request } from 'node:http';
import { once } from 'node:events';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const TOKEN = 'deploy-test-token-123456';
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function freePort() {
  const listener = createServer();
  await new Promise((resolve, reject) => { listener.once('error', reject); listener.listen(0, '127.0.0.1', resolve); });
  const { port } = listener.address();
  await new Promise(resolve => listener.close(resolve));
  assert.ok(![47831, 5173].includes(port));
  return port;
}

async function startServer(port, extraEnv, directory) {
  const child = spawn(process.execPath, ['server/index.mjs'], {
    cwd: root,
    env: { ...process.env, NETPILOT_PORT: String(port), NETPILOT_DATA_DIR: directory, ...extraEnv },
    stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  });
  let stdout = '', stderr = '';
  child.stdout.setEncoding('utf8').on('data', text => { stdout += text; });
  child.stderr.setEncoding('utf8').on('data', text => { stderr += text; });
  return { child, get stdout() { return stdout; }, get stderr() { return stderr; } };
}

async function waitReady(instance, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (instance.stdout.includes('NetPilot server:')) return true;
    if (instance.child.exitCode !== null) return false;
    await sleep(120);
  }
  return false;
}

const fetchJson = async (url, options) => {
  const response = await fetch(url, options);
  const text = await response.text();
  let body; try { body = JSON.parse(text); } catch { body = text; }
  return { status: response.status, headers: response.headers, body };
};

const rawRequest = (port, path, headers) => new Promise((resolve, reject) => {
  const req = request({ host: '127.0.0.1', port, path, headers }, res => {
    let body = '';
    res.on('data', chunk => { body += chunk; });
    res.on('end', () => resolve({ status: res.statusCode, body }));
  });
  req.on('error', reject);
  req.end();
});

test('对外部署：口令登录、Cookie 会话、CSRF、Host 白名单、桥接仅本机', async t => {
  const port = await freePort();
  const directory = await mkdtemp(join(tmpdir(), 'netpilot-deploy-'));
  const instance = await startServer(port, {
    NETPILOT_BIND: '0.0.0.0',
    NETPILOT_ACCESS_TOKEN: TOKEN,
    NETPILOT_ALLOWED_HOSTS: 'netpilot.example.com',
  }, directory);
  t.after(async () => {
    instance.child.kill('SIGTERM');
    await Promise.race([once(instance.child, 'exit'), sleep(3000)]).catch(() => {});
    await rm(directory, { recursive: true, force: true }).catch(() => {});
  });

  assert.ok(await waitReady(instance), `服务未能启动：${instance.stderr}`);
  const base = `http://127.0.0.1:${port}`;

  // 探活接口不需要登录
  const health = await fetchJson(`${base}/api/health`);
  assert.equal(health.status, 200);
  assert.equal(health.body.ok, true);

  // 未登录读取业务数据必须 401
  const anonymous = await fetchJson(`${base}/api/bootstrap`);
  assert.equal(anonymous.status, 401);
  assert.equal(anonymous.body.authRequired, true);

  // 错误口令
  const wrong = await fetchJson(`${base}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: 'wrong-token-000' }) });
  assert.equal(wrong.status, 401);

  // 正确口令 → HttpOnly + SameSite=Strict Cookie
  const login = await fetchJson(`${base}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: TOKEN }) });
  assert.equal(login.status, 200);
  const setCookie = String(login.headers.get('set-cookie'));
  assert.match(setCookie, /netpilot_session=[a-f0-9]{64}/);
  assert.match(setCookie, /HttpOnly/i);
  assert.match(setCookie, /SameSite=Strict/i);
  const cookie = setCookie.split(';')[0];

  // 带 Cookie 才能读，且拿到 CSRF
  const authed = await fetchJson(`${base}/api/bootstrap`, { headers: { Cookie: cookie } });
  assert.equal(authed.status, 200);
  assert.equal(typeof authed.body.csrfToken, 'string');
  assert.equal(authed.body.deployment.authRequired, true);
  assert.equal(authed.body.deployment.bind, '0.0.0.0');

  // 有 Cookie 无 CSRF 的写操作仍被拒
  const noCsrf = await fetchJson(`${base}/api/topology/clear`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify({ confirmation: '清空拓扑' }),
  });
  assert.equal(noCsrf.status, 403);

  // 没有 Cookie 的写操作先被登录拦住
  const noCookie = await fetchJson(`${base}/api/topology/clear`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-netpilot-csrf': authed.body.csrfToken },
    body: JSON.stringify({ confirmation: '清空拓扑' }),
  });
  assert.equal(noCookie.status, 401);

  // Host 白名单：未知域名 403，白名单域名 200，回环始终放行
  assert.equal((await rawRequest(port, '/api/health', { Host: 'evil.example.com' })).status, 403);
  assert.equal((await rawRequest(port, '/api/health', { Host: 'netpilot.example.com' })).status, 200);
  assert.equal((await rawRequest(port, '/api/health', { Host: `127.0.0.1:${port}` })).status, 200);

  // 桥接不暴露到公网来源：本机可达但需桥接身份
  const bridge = await fetchJson(`${base}/bridge/poll`, { method: 'POST', headers: { 'Content-Type': 'text/plain' } });
  assert.equal(bridge.status, 403);
  assert.match(String(bridge.body.error), /桥接/);

  // 退出登录后立即失效
  const logout = await fetchJson(`${base}/api/logout`, { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie, 'x-netpilot-csrf': authed.body.csrfToken }, body: '{}' });
  assert.equal(logout.status, 200);
  assert.equal((await fetchJson(`${base}/api/bootstrap`, { headers: { Cookie: cookie } })).status, 401);
});

test('对外监听但没有口令时必须拒绝启动', async () => {
  const port = await freePort();
  const directory = await mkdtemp(join(tmpdir(), 'netpilot-nopass-'));
  const instance = await startServer(port, { NETPILOT_BIND: '0.0.0.0' }, directory);
  const [code] = await Promise.race([once(instance.child, 'exit'), sleep(8000).then(() => [null])]);
  instance.child.kill('SIGKILL');
  await rm(directory, { recursive: true, force: true }).catch(() => {});
  assert.equal(code, 1, `应当以退出码 1 拒绝启动，实际：${code}`);
  assert.match(instance.stderr, /NETPILOT_ACCESS_TOKEN/);
});
