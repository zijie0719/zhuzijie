import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { setImmediate as nextTurn } from 'node:timers/promises';
import {
  CLIText, DeviceConnection, MAX_OUTPUT_BYTES, cleanCLIOutput, findPrompt,
  fingerprintForKey, matchesFingerprint, probeSSHWithClient,
} from '../server/transport.mjs';

// No SerialPort.list/open or real SSH/network socket is used anywhere in these tests.
class FakeStream extends EventEmitter {
  constructor(handler = () => {}) {
    super();
    this.handler = handler;
    this.writes = [];
    this.destroyed = false;
    this.closed = false;
  }

  feed(...chunks) {
    for (const chunk of chunks) this.emit('data', Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }

  write(text, callback) {
    this.writes.push(text);
    this.handler(text, this);
    callback?.();
    return true;
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.closed = true;
    this.emit('close');
  }
}

function serialFixture(handler, { loginTimeoutMs = 100, maxPages = 100, manualOpen = false } = {}) {
  const ports = [];
  class FakeSerialPort extends FakeStream {
    constructor(options) {
      super(handler);
      this.options = options;
      this.isOpen = false;
      this.opening = false;
      this.closeCount = 0;
      ports.push(this);
    }

    open(callback) {
      this.opening = true;
      this.openCallback = callback;
      if (!manualOpen) this.finishOpen();
    }

    finishOpen(error) {
      this.opening = false;
      if (!error) { this.isOpen = true; this.emit('open'); }
      this.openCallback(error);
    }

    close(callback) {
      this.closeCount++;
      this.isOpen = false;
      this.destroy();
      callback?.();
    }
  }
  class TestConnection extends DeviceConnection {
    async _loadSerialPort() { return FakeSerialPort; }
    get _connectionTimeoutMs() { return loginTimeoutMs; }
    get _maxPages() { return maxPages; }
  }
  return { connection: new TestConnection(), ports };
}

async function connectedSerial(t, handler, settings) {
  const fixture = serialFixture((text, stream) => {
    if (text === '\r' && stream.writes.length === 1) stream.feed('router#');
    else handler?.(text, stream);
  }, settings);
  t.after(() => fixture.connection.close());
  await fixture.connection.connect({ kind: 'serial', path: 'FAKE-ONLY' });
  return { ...fixture, stream: fixture.ports[0] };
}

function rejectsCode(promise, code) {
  return assert.rejects(promise, (error) => {
    assert.equal(error.code, code);
    assert.match(error.message, /[\u3400-\u9fff]/u, 'failures have a Chinese explanation');
    return true;
  });
}

const HOST_KEY = Buffer.from('fake SSH public key blob');
const FINGERPRINT = fingerprintForKey(HOST_KEY);

function sshFixture({ key = HOST_KEY, auth, handler, silent = false, verify = true } = {}) {
  const clients = [];
  class FakeClient extends EventEmitter {
    constructor() {
      super();
      this.stream = new FakeStream(handler ?? ((text, stream) => stream.feed(text === '\r' ? '<VRP>' : `${text}\nOK\n<VRP>`)));
      this.destroyed = false;
      this.authAttempts = 0;
      clients.push(this);
    }

    connect(config) {
      this.config = config;
      if (silent) return;
      if (verify && !config.hostVerifier(key)) return;
      if (this.destroyed) return;
      this.authAttempts++;
      if (auth) auth(this);
      else this.emit('ready');
    }

    shell(options, callback) {
      this.shellOptions = options;
      callback(null, this.stream);
    }

    destroy() {
      if (this.destroyed) return;
      this.destroyed = true;
      this.stream.destroy();
      this.emit('close');
    }
  }
  class TestConnection extends DeviceConnection {
    async _loadSSHClient() { return FakeClient; }
    get _connectionTimeoutMs() { return 50; }
  }
  return { connection: new TestConnection(), clients, Client: FakeClient };
}

const SSH_OPTIONS = { kind: 'ssh', host: 'fake.invalid', username: 'operator', password: 'secret-not-for-events', fingerprint: FINGERPRINT };

test('configuration echo barrier rejects a late previous prompt before exact command echo', async (t) => {
  const { connection, stream } = await connectedSerial(t, (_text, stream) => stream.feed('router#'));
  let complete = false;
  const result = connection.run('configure terminal', { requireEcho: true, timeoutMs: 1000 }).then(text => { complete = true; return text; });
  await nextTurn();
  assert.equal(complete, false, 'a stale prompt must not acknowledge a configuration command');
  stream.feed('\r\nconfigure terminal\r\nrouter(config)#');
  assert.match(await result, /router\(config\)#$/);
});

test('configuration without a matching echo fails closed and does not run queued writes', async (t) => {
  const { connection, stream } = await connectedSerial(t, (_text, stream) => stream.feed('router#'));
  const first = rejectsCode(connection.run('configure terminal', { requireEcho: true, timeoutMs: 20 }), 'COMMAND_TIMEOUT');
  const second = rejectsCode(connection.run('vlan 20', { requireEcho: true }), 'COMMAND_TIMEOUT');
  await Promise.all([first, second]);
  assert.equal(stream.writes.includes('vlan 20\r'), false);
});

test('prompt grammar accepts VRP/Cisco/config modes only at a complete final line', () => {
  for (const prompt of ['<VRP>', '[VRP]', '[~VRP-GigabitEthernet0/0/1]', '[*VRP]', 'hostname#', 'hostname>', 'hostname(config-if)#', '(config-if)#']) {
    assert.equal(findPrompt(`banner\n${prompt} \n`), prompt);
  }
  for (const text of ['message router#', ' router#', 'text <VRP>', '[Y/N]:', 'router#more', 'router#\nnot done', 'value #', '<VRP> output', 'hostname (config)#']) {
    assert.equal(findPrompt(text), null, text);
  }
});

test('ANSI, OSC, split UTF-8, carriage return and backspace are cleaned incrementally', () => {
  const terminal = new CLIText();
  terminal.push('\x1b[3');
  assert.equal(terminal.complete, false);
  terminal.push('2m<VR');
  terminal.push('P>\x1b[0m\r\n\x1b]0;private title');
  terminal.push('\x1b\\');
  const chinese = Buffer.from('接口正常');
  terminal.push(chinese.subarray(0, 4));
  assert.equal(terminal.complete, false);
  terminal.push(chinese.subarray(4));
  terminal.push('\r\nprogress 1\rprogress 2\r\nabcd\b \bX');
  assert.equal(terminal.text, '<VRP>\n接口正常\nprogress 2\nabcX');
  assert.equal(cleanCLIOutput('\x1b[31mrouter#\x1b[0m\x07'), 'router#');
});

test('serial handshake sends only a newline, uses only the selected port and exposes public info', async (t) => {
  const { connection, ports } = serialFixture((text, stream) => stream.feed('\x1b[32m<VRP>\x1b[0m'));
  const statuses = [];
  connection.on('status', (event) => statuses.push(event));
  t.after(() => connection.close());
  const info = await connection.connect({ kind: 'serial', path: 'FAKE-ONLY', vendor: 'huawei' });
  assert.deepEqual(info, { kind: 'serial', path: 'FAKE-ONLY', prompt: '<VRP>' });
  assert.deepEqual(connection.info, info);
  assert.equal(connection.isConnected, true);
  assert.equal(ports.length, 1);
  assert.deepEqual(ports[0].writes, ['\r']);
  assert.deepEqual(ports[0].options, { path: 'FAKE-ONLY', baudRate: 9600, dataBits: 8, stopBits: 1, parity: 'none', autoOpen: false });
  assert.deepEqual(statuses.map((event) => event.state), ['connecting', 'connected']);
});

test('undefined optional values use defaults and invalid options never open a device', async (t) => {
  const serial = serialFixture((text, stream) => stream.feed('router>'));
  const ssh = sshFixture();
  t.after(() => Promise.all([serial.connection.close(), ssh.connection.close()]));
  await serial.connection.connect({ kind: 'serial', path: 'FAKE-ONLY', baudRate: undefined, dataBits: undefined, stopBits: undefined, parity: undefined });
  assert.equal(serial.ports[0].options.baudRate, 9600);
  assert.equal(serial.ports[0].options.parity, 'none');
  assert.equal((await ssh.connection.connect({ ...SSH_OPTIONS, port: undefined })).port, 22);
  const invalid = serialFixture(() => {});
  await rejectsCode(invalid.connection.connect({ kind: 'serial', path: 'FAKE-ONLY', baudRate: 0 }), 'INVALID_SERIAL_OPTIONS');
  await rejectsCode(invalid.connection.connect({ kind: 'serial', path: 'FAKE-ONLY', password: 'secret\ncommand' }), 'INVALID_INPUT');
  assert.equal(invalid.ports.length, 0);
});

test('serial auto-login handles split prompts and sends each credential once without broadcasting', async (t) => {
  const { connection, ports } = serialFixture((text, stream) => {
    if (text === '\r') stream.feed('User', 'name:');
    else if (text === 'operator\r') stream.feed('operator\r\nPass', 'word:');
    else if (text === 'top-secret\r') stream.feed('top-secret\r\n[VRP]');
  });
  const events = [];
  connection.on('status', (event) => events.push(event));
  connection.on('data', (event) => assert.fail(`unexpected raw data event: ${typeof event}`));
  t.after(() => connection.close());
  await connection.connect({ kind: 'serial', path: 'FAKE-ONLY', username: 'operator', password: 'top-secret' });
  assert.deepEqual(ports[0].writes, ['\r', 'operator\r', 'top-secret\r']);
  assert.equal(connection.info.prompt, '[VRP]');
  assert.doesNotMatch(JSON.stringify({ events, info: connection.info }), /top-secret|operator/);
});

test('serial missing credentials and repeated credentials fail without retrying', async (t) => {
  for (const prompt of ['login:', 'Password:']) {
    await t.test(prompt, async () => {
      const { connection, ports } = serialFixture((text, stream) => stream.feed(prompt));
      await rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY' }), 'CREDENTIALS_REQUIRED');
      await connection.close();
      assert.deepEqual(ports[0].writes, ['\r']);
      assert.equal(connection.isConnected, false);
    });
  }
  const { connection, ports } = serialFixture((text, stream) => stream.feed('Password:'));
  await rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY', password: 'once-only' }), 'LOGIN_FAILED');
  await connection.close();
  assert.deepEqual(ports[0].writes, ['\r', 'once-only\r']);
});

test('serial authentication failure and login timeout are explicit Chinese failures', async (t) => {
  for (const output of ['Login incorrect\r\nlogin:', '% Authentication failed\r\n', 'Error: Username or password error.\r\n', '认证失败\r\n']) {
    const { connection } = serialFixture((text, stream) => stream.feed(output));
    await rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY', username: 'operator' }), 'LOGIN_FAILED');
    await connection.close();
  }
  const { connection, ports } = serialFixture(() => {}, { loginTimeoutMs: 15 });
  await rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY' }), 'LOGIN_TIMEOUT');
  await connection.close();
  assert.equal(ports[0].listenerCount('data'), 0);
  assert.equal(ports[0].listenerCount('error'), 0);
  await rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY' }), 'CONNECTION_USED');
});

test('run handles fully synchronous stream responses and observes the new mode prompt', async (t) => {
  const { connection, stream } = await connectedSerial(t, (text, target) => target.feed(`${text}\nentered configuration\r\nrouter(config-if)#`));
  const output = await connection.run('configure terminal');
  assert.equal(output, 'configure terminal\nentered configuration\nrouter(config-if)#');
  assert.equal(connection.info.prompt, 'router(config-if)#');
  assert.deepEqual(stream.writes, ['\r', 'configure terminal\r']);
});

test('a prompt-looking literal command echo is not a completion prompt', async (t) => {
  const { connection, stream } = await connectedSerial(t, (text, target) => target.feed(text));
  let complete = false;
  const result = connection.run('router#').then((output) => { complete = true; return output; });
  await nextTurn();
  assert.equal(complete, false);
  stream.feed('\nrouter#');
  assert.equal(await result, 'router#\nrouter#');
});

test('commands are FIFO; only a command-after-write prompt releases the next command', async (t) => {
  const { connection, stream } = await connectedSerial(t);
  const first = connection.run('first');
  const second = connection.run('second');
  const third = connection.run('third');
  await nextTurn();
  assert.deepEqual(stream.writes, ['\r', 'first\r']);
  stream.feed('first\r\nvalue # in output\r\nrouter#');
  assert.match(await first, /value # in output/);
  await nextTurn();
  assert.deepEqual(stream.writes, ['\r', 'first\r', 'second\r']);
  stream.feed('second\r\nrouter>');
  await second;
  await nextTurn();
  stream.feed('third\r\n<VRP>');
  await third;
  assert.deepEqual(stream.writes, ['\r', 'first\r', 'second\r', 'third\r']);
});

test('split ANSI pagers send spaces and preserve all pages without pager artifacts', async (t) => {
  let page = 0;
  const { connection, stream } = await connectedSerial(t, (text, target) => {
    if (text === 'display current-configuration\r') target.feed('display current-configuration\r\n\x1b[32mpage 1\x1b[0m\r\n--Mo', 're--');
    else if (text === ' ' && ++page === 1) target.feed('\b\b\b\b\b\b\b\b        \r\x1b[2Kpage 2\r\nMore:');
    else if (text === ' ') target.feed('\r\x1b[Kpage 3\r\n<VRP>');
  });
  const output = await connection.run('display current-configuration');
  assert.equal(output, 'display current-configuration\npage 1\npage 2\npage 3\n<VRP>');
  assert.deepEqual(stream.writes, ['\r', 'display current-configuration\r', ' ', ' ']);
  assert.doesNotMatch(output, /More|\x1b|\x08/);
});

test('pagination has a finite limit and never releases the queued command on failure', async (t) => {
  const { connection, stream } = await connectedSerial(t, (text, target) => target.feed('page\r\n---- More ----'), { maxPages: 2 });
  const a = rejectsCode(connection.run('display long'), 'PAGING_LIMIT');
  const b = rejectsCode(connection.run('never-send'), 'PAGING_LIMIT');
  await Promise.all([a, b]);
  assert.deepEqual(stream.writes, ['\r', 'display long\r', ' ', ' ']);
  assert.equal(connection.isConnected, false);
});

test('timeout poisons the session; inline pseudo-prompts, late prompts and queued work cannot recover it', async (t) => {
  const { connection, stream } = await connectedSerial(t, (text, target) => target.feed('output mentions router#'));
  const first = rejectsCode(connection.run('partial-config', { timeoutMs: 15 }), 'COMMAND_TIMEOUT');
  const second = rejectsCode(connection.run('must-not-send'), 'COMMAND_TIMEOUT');
  await Promise.all([first, second]);
  stream.feed('\r\nrouter#');
  await rejectsCode(connection.run('also-never'), 'COMMAND_TIMEOUT');
  assert.deepEqual(stream.writes, ['\r', 'partial-config\r']);
  assert.equal(connection.isConnected, false);
  assert.equal(stream.destroyed, true);
});

test('close, EOF and transport errors abort in-flight and queued commands', async (t) => {
  for (const event of ['close', 'end', 'error']) {
    await t.test(event, async (st) => {
      const { connection, stream } = await connectedSerial(st);
      const code = event === 'error' ? 'TRANSPORT_ERROR' : 'DISCONNECTED';
      const first = rejectsCode(connection.run('first'), code);
      const second = rejectsCode(connection.run('never'), code);
      await nextTurn();
      stream.emit(event, new Error('secret-in-driver-error'));
      await Promise.all([first, second]);
      assert.deepEqual(stream.writes, ['\r', 'first\r']);
      assert.equal(connection.isConnected, false);
    });
  }
});

test('interactive confirmations never count as success or receive automatic confirmation', async (t) => {
  for (const prompt of ['Continue? [Y/N]:', 'Proceed (yes/no)?', '[confirm]', 'Are you sure?', 'Press ENTER to continue', 'Destination filename [startup-config]?']) {
    await t.test(prompt, async (st) => {
      const { connection, stream } = await connectedSerial(st, (text, target) => target.feed(prompt));
      const first = rejectsCode(connection.run('save'), 'INTERACTION_REQUIRED');
      const second = rejectsCode(connection.run('next'), 'INTERACTION_REQUIRED');
      await Promise.all([first, second]);
      assert.deepEqual(stream.writes, ['\r', 'save\r']);
    });
  }
});

test('unexpected login while running or idle prevents further writes', async (t) => {
  const running = await connectedSerial(t, (text, target) => target.feed('Password:'));
  await rejectsCode(running.connection.run('ssh other-device'), 'UNEXPECTED_LOGIN');
  const idle = await connectedSerial(t);
  idle.stream.feed('\r\nlogin:');
  await rejectsCode(idle.connection.run('never'), 'SESSION_CHANGED');
  assert.deepEqual(idle.stream.writes, ['\r']);
});

test('output limits count raw ANSI bytes and bound expanded terminal output', async (t) => {
  for (const data of [Buffer.alloc(MAX_OUTPUT_BYTES + 1, 65), '\x1b[0m'.repeat(Math.ceil(MAX_OUTPUT_BYTES / 4) + 1), '\x1b[8192Gx\n'.repeat(130)]) {
    const { connection } = await connectedSerial(t, (text, target) => target.feed(data));
    await rejectsCode(connection.run('huge'), 'OUTPUT_LIMIT');
    assert.equal(connection.isConnected, false);
  }
});

test('an output of exactly 1 MiB is allowed when it ends in a real prompt', async (t) => {
  const ending = '\nrouter#';
  const output = 'x'.repeat(MAX_OUTPUT_BYTES - ending.length) + ending;
  const { connection } = await connectedSerial(t, (text, stream) => stream.feed(output));
  assert.equal(Buffer.byteLength(await connection.run('show large')), MAX_OUTPUT_BYTES);
});

test('synchronous and callback write failures poison the session before a queued write', async (t) => {
  for (const mode of ['throw', 'callback']) {
    const { connection, stream } = await connectedSerial(t);
    stream.write = (text, callback) => {
      stream.writes.push(text);
      if (mode === 'throw') throw new Error('private driver details');
      callback(new Error('private driver details'));
    };
    const first = rejectsCode(connection.run('first'), 'WRITE_FAILED');
    const second = rejectsCode(connection.run('never'), 'WRITE_FAILED');
    await Promise.all([first, second]);
    assert.deepEqual(stream.writes, ['\r', 'first\r']);
  }
});

test('multiline, empty and control-character commands are rejected before writing', async (t) => {
  const { connection, stream } = await connectedSerial(t, (text, target) => target.feed('\r\nrouter#'));
  for (const command of ['', '   ', 'show\nreload', 'show\rreload', 'x\t', 'x\x00', 'x\x1b', 'x\x7f', 'x\u0085', 'x\u2028', 'x\u2029', 42]) {
    await rejectsCode(connection.run(command), 'INVALID_INPUT');
  }
  for (const timeoutMs of [0, -1, Infinity, 2.5, 2 ** 31]) await rejectsCode(connection.run('show', { timeoutMs }), 'INVALID_TIMEOUT');
  assert.deepEqual(stream.writes, ['\r']);
  await connection.run('display version');
  assert.equal(connection.isConnected, true);
});

test('close is idempotent, rejects pending/queued work, clears listeners and emits once', async (t) => {
  const { connection, stream } = await connectedSerial(t);
  let closes = 0;
  connection.on('close', () => closes++);
  const first = rejectsCode(connection.run('first'), 'CONNECTION_CLOSED');
  const second = rejectsCode(connection.run('never'), 'CONNECTION_CLOSED');
  await nextTurn();
  await Promise.all([connection.close(), connection.close(), first, second]);
  assert.equal(closes, 1);
  assert.equal(stream.closeCount, 1);
  assert.deepEqual(stream.eventNames(), []);
  assert.equal(connection._pending, null);
  assert.deepEqual(stream.writes, ['\r', 'first\r']);
});

test('closing during dependency loading cancels connect without ever opening a port', async () => {
  const { connection, ports } = serialFixture(() => assert.fail('unexpected write'));
  const pending = rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY' }), 'CONNECTION_CLOSED');
  await connection.close();
  await pending;
  assert.equal(ports.length, 0);
  assert.equal(connection._pending, null);
});

test('serial open completing after timeout is closed without newline or credentials', async () => {
  const { connection, ports } = serialFixture(() => assert.fail('late-open write'), { manualOpen: true, loginTimeoutMs: 15 });
  await rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY', password: 'secret' }), 'LOGIN_TIMEOUT');
  ports[0].finishOpen();
  await connection.close();
  assert.deepEqual(ports[0].writes, []);
  assert.equal(ports[0].closeCount, 1);
  assert.deepEqual(ports[0].eventNames(), []);
});

test('late serial open failure also releases cleanup listeners', async () => {
  const { connection, ports } = serialFixture(() => {}, { manualOpen: true, loginTimeoutMs: 15 });
  await rejectsCode(connection.connect({ kind: 'serial', path: 'FAKE-ONLY' }), 'LOGIN_TIMEOUT');
  ports[0].finishOpen(new Error('open failed'));
  await connection.close();
  assert.deepEqual(ports[0].eventNames(), []);
});

test('fingerprints are exact OpenSSH SHA256 base64 values, never MD5 or auto-accepted', () => {
  assert.match(FINGERPRINT, /^SHA256:[A-Za-z0-9+/]{43}$/);
  assert.equal(matchesFingerprint(HOST_KEY, FINGERPRINT), true);
  for (const value of [undefined, '', FINGERPRINT.toLowerCase(), `${FINGERPRINT}=`, ` ${FINGERPRINT}`, 'MD5:00:11', fingerprintForKey(Buffer.from('other key'))]) {
    assert.equal(matchesFingerprint(HOST_KEY, value), false);
  }
});

test('SSH password mode verifies the exact host key before authentication and shell use', async (t) => {
  const { connection, clients } = sshFixture();
  t.after(() => connection.close());
  const info = await connection.connect(SSH_OPTIONS);
  assert.deepEqual(info, { kind: 'ssh', host: 'fake.invalid', port: 22, prompt: '<VRP>' });
  assert.equal(clients[0].authAttempts, 1);
  assert.equal(clients[0].config.hostHash, undefined, 'verifier receives the original key blob');
  assert.deepEqual(clients[0].config.authHandler, ['password', 'keyboard-interactive']);
  assert.equal(clients[0].config.password, SSH_OPTIONS.password);
  assert.match(await connection.run('display version'), /OK/);
  assert.doesNotMatch(JSON.stringify(connection.info), /secret-not-for-events/);
});

test('SSH rejects missing/mismatched host keys and cannot bypass verification', async () => {
  const missing = sshFixture();
  await rejectsCode(missing.connection.connect({ ...SSH_OPTIONS, fingerprint: undefined }), 'FINGERPRINT_REQUIRED');
  assert.equal(missing.clients.length, 0);
  const mismatch = sshFixture({ key: Buffer.from('attacker key') });
  await rejectsCode(mismatch.connection.connect(SSH_OPTIONS), 'FINGERPRINT_MISMATCH');
  assert.equal(mismatch.clients[0].authAttempts, 0);
  assert.deepEqual(mismatch.clients[0].stream.writes, []);
  assert.equal(mismatch.clients[0].destroyed, true);
  const bypass = sshFixture({ verify: false });
  await rejectsCode(bypass.connection.connect(SSH_OPTIONS), 'FINGERPRINT_MISMATCH');
  assert.deepEqual(bypass.clients[0].stream.writes, []);
});

test('SSH keyboard-interactive answers only a known password challenge and never broadcasts credentials', async (t) => {
  let answers;
  const { connection } = sshFixture({
    auth(client) {
      client.emit('keyboard-interactive', 'login', '', '', [{ prompt: 'Password:', echo: false }], (response) => {
        answers = response;
        client.emit('ready');
      });
    },
  });
  const events = [];
  connection.on('status', (event) => events.push(event));
  t.after(() => connection.close());
  await connection.connect(SSH_OPTIONS);
  assert.deepEqual(answers, [SSH_OPTIONS.password]);
  assert.doesNotMatch(JSON.stringify(events), /secret-not-for-events|Password:/);
});

test('SSH rejects OTP/password-change/repeated keyboard challenges rather than spraying passwords', async (t) => {
  for (const prompt of ['Verification code:', 'New password:', 'Password:']) {
    await t.test(prompt, async () => {
      const answers = [];
      const { connection } = sshFixture({
        auth(client) {
          const ask = (question) => client.emit('keyboard-interactive', '', '', '', [{ prompt: question, echo: false }], (response) => answers.push(response));
          if (prompt === 'Password:') ask(prompt);
          ask(prompt);
        },
      });
      await rejectsCode(connection.connect(SSH_OPTIONS), 'SSH_INTERACTION');
      assert.deepEqual(answers, prompt === 'Password:' ? [[SSH_OPTIONS.password], []] : [[]]);
      await connection.close();
    });
  }
});

test('SSH login errors redact driver messages and SSH handshake cannot wait forever', async () => {
  const failed = sshFixture({ auth: (client) => client.emit('error', new Error(`bad password: ${SSH_OPTIONS.password}`)) });
  const events = [];
  failed.connection.on('status', (event) => events.push(event));
  await rejectsCode(failed.connection.connect(SSH_OPTIONS), 'TRANSPORT_ERROR');
  assert.doesNotMatch(JSON.stringify(events), /secret-not-for-events/);
  const silent = sshFixture({ silent: true });
  await rejectsCode(silent.connection.connect(SSH_OPTIONS), 'LOGIN_TIMEOUT');
  await silent.connection.close();
  assert.equal(silent.clients[0].destroyed, true);
  assert.deepEqual(silent.clients[0].eventNames(), []);
});

test('probe returns fingerprint, always rejects host verification and sends no userauth', async () => {
  const { Client, clients } = sshFixture();
  const result = await probeSSHWithClient({ host: 'fake.invalid' }, Client);
  assert.deepEqual(result, { host: 'fake.invalid', port: 22, fingerprint: FINGERPRINT });
  assert.equal(clients[0].authAttempts, 0);
  assert.equal(clients[0].config.username, '', 'only the local ssh2-required placeholder exists');
  assert.equal(clients[0].config.password, undefined);
  assert.equal(clients[0].config.authHandler(), false);
  assert.deepEqual(clients[0].stream.writes, []);
  assert.equal(clients[0].destroyed, true);
  assert.deepEqual(clients[0].eventNames(), []);
});

test('probe has bounded timeout and handles early error, EOF and synchronous verification rejection', async (t) => {
  const silent = sshFixture({ silent: true });
  await rejectsCode(probeSSHWithClient({ host: 'fake.invalid', timeoutMs: 15 }, silent.Client), 'SSH_PROBE_TIMEOUT');
  assert.equal(silent.clients[0].destroyed, true);
  for (const event of ['error', 'end', 'close']) {
    await t.test(event, async () => {
      const fixture = sshFixture({ silent: true });
      const pending = probeSSHWithClient({ host: 'fake.invalid', port: 2222 }, fixture.Client);
      const rejection = rejectsCode(pending, event === 'error' ? 'SSH_PROBE_FAILED' : 'SSH_PROBE_CLOSED');
      fixture.clients[0].emit(event, new Error('private detail'));
      await rejection;
      assert.deepEqual(fixture.clients[0].eventNames(), []);
    });
  }
  const fixture = sshFixture({ silent: true });
  const pending = probeSSHWithClient({ host: 'fake.invalid' }, fixture.Client);
  const client = fixture.clients[0];
  assert.equal(client.config.hostVerifier(HOST_KEY), false);
  client.emit('error', new Error('Host denied (verification failed)'));
  assert.equal((await pending).fingerprint, FINGERPRINT);
  assert.equal(client.destroyed, true);
});
