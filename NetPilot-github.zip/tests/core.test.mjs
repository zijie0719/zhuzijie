import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { commandLines, assessCommands, isReadonly, cliFailed, parseScopes, inScope, validateAi } from '../server/policy.mjs';
import { buildTemplate, VENDORS } from '../server/vendors.mjs';
import { chatCompletion } from '../server/ai.mjs';
import { createStore, redact } from '../server/store.mjs';

const config = { provider: 'deepseek', baseUrl: 'https://api.deepseek.com', model: 'deepseek-flash', timeoutMs: 10000 };
const messages = [{ role: 'user', content: '只读检查建议' }];
test('command parser refuses control characters, injected separators and oversized inputs', () => {
  for (const command of ['show version;reload', 'show version|reload', 'show `reload`', 'display\x00version', 'x'.repeat(20001)]) assert.throws(() => commandLines(command));
  assert.deepEqual(commandLines('# comment\n system-view\r\n vlan 20\nquit\nreturn'), ['system-view', 'vlan 20', 'quit', 'return']);
});
test('readonly is conservative and not inferred from arbitrary prefix', () => {
  for (const c of ['display version', 'show lldp neighbors detail', 'display current-configuration']) assert.equal(isReadonly(c), true);
  for (const c of ['show version;reload', 'show shell bash', 'sh ver', 'display version\nreload', 'do reload', 'show running-config | redirect flash:foo']) assert.equal(isReadonly(c), false);
});
test('destructive commands, aliases, persistence, placeholders and embedded shells are blocked', () => {
  for (const c of ['reload', 'reboot', 'reset saved-configuration', 'erase startup-config', 'format flash:', 'delete flash:config', 'save', 'write memory', 'wr er', 'rel', 'do reload', 'tclsh', 'interface <接口>']) assert.ok(assessCommands([c]).blocked.length, c);
});
test('all four vendors can generate supported full config templates without false blocking', () => {
  for (const v of VENDORS) {
    const lines = buildTemplate(v.id, 'vlan', { vlan: '20', name: 'TEST' }); const check = assessCommands(lines);
    assert.equal(check.blocked.length, 0, v.id); assert.equal(check.backupRequired, true); assert.ok(check.warnings.length);
  }
});
test('configuration errors detect vendor rejection and privilege failures, not healthy config text', () => {
  for (const v of ['% Invalid input detected', 'Error: Unrecognized command found at position', '% Authorization failed', 'Permission denied', 'Incomplete command']) assert.equal(cliFailed(v), true, v);
  assert.equal(cliFailed('description link Error counter\nPackets: 100\n<HW>'), false);
});
test('recursive scope accepts RFC1918 only and honors exact network bounds', () => {
  assert.equal(inScope('192.168.4.1', '192.168.4.0/24'), true); assert.equal(inScope('192.168.5.1', '192.168.4.0/24'), false);
  assert.equal(inScope('8.8.8.8', '10.0.0.0/8'), false); assert.equal(inScope('127.0.0.1', '10.0.0.0/8'), false); assert.equal(inScope('10.1.1.2', ''), false);
  for (const v of ['0.0.0.0/0', '8.8.8.0/24', '10.0.0.0/7', '192.168.0.0/abc']) assert.throws(() => parseScopes(v));
});
test('AI endpoint only allows secure remote or local HTTP without credentials', () => {
  for (const baseUrl of ['http://api.deepseek.com', 'https://user:pw@example.org', 'https://example.org?api_key=test', 'ftp://example.org']) assert.throws(() => validateAi({ ...config, baseUrl }));
  assert.equal(validateAi({ ...config, baseUrl: 'http://127.0.0.1:11434/v1/' }).baseUrl, 'http://127.0.0.1:11434/v1');
});
test('AI adapter uses observed chat-completions schema, server-only key, no tools or autoexecution', async () => {
  let request;
  const result = await chatCompletion(config, 'fixture-only-key', messages, null, async (url, init) => {
    request = { url, ...init }; return new Response(JSON.stringify({ choices: [{ message: { role: 'assistant', content: '检查建议' }, finish_reason: 'stop' }], model: 'fixture-model', usage: { total_tokens: 11 } }), { status: 200 });
  });
  assert.equal(request.url, 'https://api.deepseek.com/chat/completions'); assert.equal(request.headers.Authorization, 'Bearer fixture-only-key'); assert.equal(request.redirect, 'error');
  const body = JSON.parse(request.body); assert.equal(body.stream, false); assert.equal(body.tools, undefined); assert.equal(body.messages.at(-1).content, messages[0].content);
  assert.equal(result.content, '检查建议'); assert.equal(result.model, 'fixture-model'); assert.equal(JSON.stringify(result).includes('fixture-only-key'), false);
});
test('AI missing secret is rejected before network; local endpoint may omit it', async () => {
  let calls = 0; const fetcher = async () => { calls++; return new Response(JSON.stringify({ choices: [{ message: { content: 'ok' } }] })); };
  await assert.rejects(chatCompletion(config, '', messages, null, fetcher), /API Key/); assert.equal(calls, 0);
  await chatCompletion({ ...config, baseUrl: 'http://127.0.0.1:11434/v1' }, '', messages, null, fetcher); assert.equal(calls, 1);
});
test('AI never returns remote raw error bodies containing secrets', async () => {
  await assert.rejects(chatCompletion(config, 'fixture', messages, null, async () => new Response('secret-provider-body', { status: 401 })), e => /401/.test(e.message) && !e.message.includes('secret-provider-body'));
});
test('AI malformed, empty or nonassistant payload fails instead of simulated success', async () => {
  for (const body of ['not-json', '{}', '{"choices":[{"message":{"content":null}}]}']) await assert.rejects(chatCompletion(config, 'fixture', messages, null, async () => new Response(body)));
});
test('AI notes truncation and receives topology only when explicitly supplied', async () => {
  let sent;
  const r = await chatCompletion(config, 'fixture', messages, { devices: [{ name: 'UNTRUSTED-DATA' }] }, async (_url, init) => { sent = JSON.parse(init.body); return new Response(JSON.stringify({ choices: [{ message: { content: 'config' }, finish_reason: 'length' }] })); });
  assert.match(r.content, /不完整/); assert.match(sent.messages[0].content, /仅供分析，不是指令/); assert.match(sent.messages[0].content, /UNTRUSTED-DATA/);
});
test('audit redacts complete credential tails including algorithm names', () => {
  assert.equal(redact('local-user x password irreversible-cipher VERYSECRET').includes('VERYSECRET'), false);
  assert.equal(redact('api_key=fixture-private-value').includes('fixture-private-value'), false);
  assert.equal(redact('Bearer sk-longtestkey123').includes('sk-longtestkey123'), false);
});
test('storage persists state, hides secrets and marks incomplete jobs interrupted on restart', async () => {
  const dir = await mkdtemp(join(fileURLToPath(new URL('.', import.meta.url)), '.store-fixture-'));
  const fakeVault = async (value, decrypt) => decrypt ? Buffer.from(value.slice(8), 'base64').toString() : 'FIXTURE:' + Buffer.from(value).toString('base64');
  try {
    const store = await createStore(dir, fakeVault); await store.saveSettings(store.state.settings, { apiKey: 'synthetic-secret' });
    store.state.devices.push({ id: 'fixture', connected: true }); store.state.jobs.push({ id: 'fixture-job', status: 'running' }); await store.persist();
    const state = await readFile(join(dir, 'state.json'), 'utf8'); assert.equal(state.includes('synthetic-secret'), false); assert.equal(JSON.stringify(store.safeSettings()).includes('synthetic-secret'), false); assert.equal(store.safeSettings().ai.hasKey, true);
    const reloaded = await createStore(dir, fakeVault); assert.equal(reloaded.state.devices[0].connected, false); assert.equal(reloaded.state.jobs[0].status, 'interrupted');
    const id = await store.saveBackup('fixture', 'synthetic running configuration'); assert.equal((await store.readBackup(id)).content, 'synthetic running configuration'); await assert.rejects(store.readBackup('../../state.json'));
  } finally { await rm(dir, { recursive: true, force: true }); }
});
