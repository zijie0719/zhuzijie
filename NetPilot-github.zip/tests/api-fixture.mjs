import { test, before, beforeEach, afterEach, after, mock } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter, once } from 'node:events';
import { createServer, request as httpRequest } from 'node:http';
import { readFile, readdir } from 'node:fs/promises';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';

// This file is intentionally not *.test.mjs: api.test.mjs supplies the mock flag,
// owns the random data directory, and supervises this single disposable process.
const project = dirname(dirname(fileURLToPath(import.meta.url)));
const directory = process.env.NETPILOT_DATA_DIR;
assert.ok(directory, 'run through api.test.mjs, never against production data');
assert.equal(dirname(resolve(directory)), join(project, '.test-data'));
assert.match(basename(directory), /^api-regression-/);
const port = Number(process.env.NETPILOT_PORT);
assert.ok(Number.isInteger(port) && port > 0 && port <= 65535 && ![47831, 5173].includes(port));
const baseUrl = `http://127.0.0.1:${port}`;
const ROOT_IP = '192.168.249.10';
const NEIGHBOR_IP = '192.168.249.11';
const ROOT_NAME = 'NP-API-ROOT';
const NEIGHBOR_NAME = 'NP-API-EDGE';
const FINGERPRINT = `SHA256:${'A'.repeat(43)}`;
const BACKUP_COMMAND = 'display current-configuration';
const VERSION = `<${ROOT_NAME}>display version\nHuawei Versatile Routing Platform Software\nVRP (R) software, Version 5.170 (S5720 V200R019C10SPC500)\nHUAWEI S5720-28X-SI-AC Routing Switch uptime is 3 weeks, 2 days\n<${ROOT_NAME}>`;
const LLDP = `<${ROOT_NAME}>display lldp neighbor\nGigabitEthernet0/0/1 has 1 neighbor(s):\nNeighbor index : 1\nChassis type : MAC address\nChassis ID : 0200-0000-0099\nPort ID type : Interface name\nPort ID : GigabitEthernet0/0/24\nSystem name : ${NEIGHBOR_NAME}\nSystem description : Huawei Versatile Routing Platform Software, VRP Version 5.170\nManagement address type : IPv4\nManagement address : ${NEIGHBOR_IP}\n<${ROOT_NAME}>`;
const BACKUP = `<${ROOT_NAME}>display current-configuration\n!Software Version V200R019C10SPC500\n#\nsysname ${ROOT_NAME}\n#\nvlan batch 1 10\n#\ninterface GigabitEthernet0/0/1\n port link-type trunk\n port trunk allow-pass vlan 10\n#\ninterface Vlanif10\n ip address ${ROOT_IP} 255.255.255.0\n#\nreturn\n<${ROOT_NAME}>`;
const VLAN_COMMANDS = ['system-view', 'vlan 123', 'name API_Regression', 'quit', 'return'];
const transcript = [], connectCalls = [], probeCalls = [], connections = [], canaryRequests = [];
const behavior = { failCommand: null, backupOutput: null, gates: new Map() };
let application, transportMock, canary, canaryUrl, csrfToken;
let listCalls = 0;

function holdCommand(command) {
  assert.equal(behavior.gates.has(command), false);
  const started = Promise.withResolvers();
  const released = Promise.withResolvers();
  // A bounded hold permits real concurrent HTTP calls without timing-dependent sleeps.
  const timer = setTimeout(() => released.reject(new Error(`fixture hold timed out: ${command}`)), 15_000);
  const gate = {
    started: started.promise,
    wait: released.promise,
    entered: started.resolve,
    release() { clearTimeout(timer); released.resolve(); behavior.gates.delete(command); },
  };
  // If an earlier assertion fails before run() reaches the gate, cleanup still owns it.
  gate.wait.catch(() => {});
  behavior.gates.set(command, gate);
  return gate;
}

function releaseGates() {
  for (const gate of [...behavior.gates.values()]) gate.release();
}

class FakeDeviceConnection extends EventEmitter {
  constructor() {
    super();
    this.id = randomUUID();
    this.isConnected = false;
    this.info = { prompt: `<${ROOT_NAME}>` };
    connections.push(this);
  }

  async connect(options) {
    connectCalls.push({ connectionId: this.id, ...structuredClone(options) });
    // Match the real transport's default-username contract instead of silently accepting ''.
    assert.notEqual(options.username, '', 'API must normalize the frontend empty username to undefined');
    assert.notEqual(options.password, '', 'API must omit an empty optional password');
    if (options.kind === 'serial') assert.equal(options.path, 'COM99');
    else {
      assert.equal(options.kind, 'ssh');
      assert.ok([ROOT_IP, NEIGHBOR_IP].includes(options.host), 'fixture accepts only synthetic device identities');
      assert.equal(options.fingerprint, FINGERPRINT);
    }
    this.isConnected = true;
    return this.info;
  }

  async run(command, options = {}) {
    assert.equal(this.isConnected, true, 'commands cannot reach a closed fake connection');
    const record = { connectionId: this.id, command, options: structuredClone(options), finished: false };
    transcript.push(record);
    const gate = behavior.gates.get(command);
    if (gate) { gate.entered(record); await gate.wait; }
    let output;
    if (command === behavior.failCommand) output = `Error: fixture rejected command\n${this.info.prompt}`;
    else if (command === BACKUP_COMMAND) output = behavior.backupOutput ?? BACKUP;
    else if (command === 'display version') output = VERSION;
    else if (command === 'screen-length 0 temporary') output = `<${ROOT_NAME}>`;
    else if (command === 'display lldp neighbor') output = LLDP;
    else if (command === 'system-view') { this.info.prompt = `[${ROOT_NAME}]`; output = `Enter system view, return user view with Ctrl+Z.\n${this.info.prompt}`; }
    else if (/^vlan \d+$/.test(command)) { this.info.prompt = `[${ROOT_NAME}-vlan${command.split(' ')[1]}]`; output = this.info.prompt; }
    else if (/^name [A-Za-z0-9_-]+$/.test(command)) output = this.info.prompt;
    else if (command === 'quit') { this.info.prompt = `[${ROOT_NAME}]`; output = this.info.prompt; }
    else if (command === 'return') { this.info.prompt = `<${ROOT_NAME}>`; output = this.info.prompt; }
    else throw new Error(`Unscripted fixture command: ${command}`);
    record.output = output;
    record.finished = true;
    return output;
  }

  async close() {
    if (!this.isConnected) return;
    this.isConnected = false;
    this.emit('close');
  }
}

async function api(method, path, body, { headers = {}, csrf = true } = {}) {
  assert.ok(path.startsWith('/api/'), 'HTTP test client must stay on this fixture API');
  const payload = body === undefined ? undefined : JSON.stringify(body);
  return new Promise((resolveResponse, reject) => {
    const req = httpRequest(`${baseUrl}${path}`, {
      method, agent: false, timeout: 30_000,
      headers: {
        Connection: 'close',
        ...(payload === undefined ? {} : { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }),
        ...(!['GET', 'HEAD'].includes(method) && csrf ? { 'X-NetPilot-CSRF': csrfToken } : {}),
        ...headers,
      },
    }, res => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', chunk => { text += chunk; });
      res.on('error', reject);
      res.on('end', () => {
        try {
          const body = res.headers['content-type']?.includes('application/json') ? JSON.parse(text) : text;
          resolveResponse({ status: res.statusCode, body, text, headers: res.headers });
        } catch (error) { reject(error); }
      });
    });
    req.on('timeout', () => req.destroy(new Error(`fixture HTTP timeout: ${method} ${path}`)));
    req.on('error', reject);
    req.end(payload);
  });
}

function expectStatus(response, status) {
  assert.equal(response.status, status, JSON.stringify(response.body));
  if (status >= 400) assert.equal(typeof response.body.error, 'string');
  return response.body;
}
const getState = async () => expectStatus(await api('GET', '/api/bootstrap'), 200);
const commandsSince = start => transcript.slice(start).map(item => item.command);
const getJob = (state, id) => state.jobs.find(job => job.id === id);

async function waitForJob(id) {
  const deadline = Date.now() + 30_000;
  let state, job;
  do {
    state = await getState();
    job = getJob(state, id);
    assert.ok(job, `job ${id} must be exposed through bootstrap`);
    if (['completed', 'failed', 'cancelled', 'interrupted'].includes(job.status) && state.activeTask === null) return job;
    await delay(25);
  } while (Date.now() < deadline);
  assert.fail(`job did not finish: ${JSON.stringify(job)}`);
}

async function waitForIdle() {
  const deadline = Date.now() + 30_000;
  do {
    const state = await getState();
    if (state.activeTask === null) return state;
    await delay(25);
  } while (Date.now() < deadline);
  assert.fail('fixture API still has an active task');
}

async function saveSettings(body) {
  return expectStatus(await api('PUT', '/api/settings', body), 200);
}

async function connect(overrides = {}) {
  return expectStatus(await api('POST', '/api/connect', {
    kind: 'serial', path: 'COM99', baudRate: '9600', vendor: 'auto',
    username: '', password: '', discover: false, ...overrides,
  }), 200);
}

async function planFor(deviceId, overrides = {}) {
  return expectStatus(await api('POST', '/api/plans', {
    deviceIds: [deviceId], template: 'vlan', params: { vlan: 123, name: 'API_Regression' }, ...overrides,
  }), 200);
}

async function execute(planId) {
  return api('POST', '/api/execute', { planId, confirmation: '确认执行', acceptRisk: true });
}

before(async () => {
  // A local HTTP canary is not an AI mock. The real ai.mjs stays loaded, but consent
  // regressions can only hit this owned loopback endpoint, never an external model.
  canary = createServer((req, res) => {
    canaryRequests.push({ method: req.method, url: req.url });
    req.resume();
    res.writeHead(503, { 'Content-Type': 'application/json' });
    res.end('{"error":"unauthorized AI call reached the fixture canary"}');
  });
  canary.listen(0, '127.0.0.1');
  await once(canary, 'listening');
  canaryUrl = `http://127.0.0.1:${canary.address().port}/v1`;
  // Resolve relative to THIS file, before importing the actual production entrypoint.
  transportMock = mock.module(new URL('../server/transport.mjs', import.meta.url).href, {
    namedExports: {
      DeviceConnection: FakeDeviceConnection,
      listSerialPorts: async () => { listCalls++; return [{ path: 'COM99', manufacturer: 'NetPilot API fixture' }]; },
      probeSSH: async options => {
        probeCalls.push(structuredClone(options));
        assert.ok([ROOT_IP, NEIGHBOR_IP].includes(options.host));
        return { host: options.host, port: options.port, fingerprint: FINGERPRINT, algorithm: 'ssh-ed25519' };
      },
    },
  });
  application = await import('../server/index.mjs');
  try {
    if (!application.server.listening) await once(application.server, 'listening', { signal: AbortSignal.timeout(5000) });
  } catch (error) {
    if (error.code === 'EADDRINUSE') console.error('NETPILOT_API_PORT_IN_USE');
    throw error;
  }
  assert.equal(application.server.address().address, '127.0.0.1');
  assert.equal(application.server.address().port, port);
  const initial = await getState();
  assert.deepEqual(initial.devices, [], 'new temp storage must not load production/demo devices');
  assert.deepEqual(initial.links, []);
  assert.deepEqual(initial.jobs, []);
  csrfToken = initial.csrfToken;
  assert.equal(typeof csrfToken, 'string');
  assert.ok(csrfToken.length >= 32);
}, { timeout: 30_000 });

beforeEach(async () => {
  releaseGates();
  const state = await waitForIdle();
  for (const device of state.devices.filter(device => device.connected)) {
    expectStatus(await api('POST', '/api/disconnect', { deviceId: device.id }), 200);
  }
  if (state.devices.length || state.links.length) {
    expectStatus(await api('POST', '/api/topology/clear', { confirmation: '清空拓扑' }), 200);
  }
  const { ai, discovery, serial } = state.settings;
  if (ai.baseUrl !== canaryUrl || ai.hasKey || discovery.scope || discovery.username || discovery.hasPassword || discovery.hosts.length || serial.autoConnect) {
    await saveSettings({
      ai: { provider: 'custom', baseUrl: canaryUrl, model: 'fixture-no-network', timeoutMs: 5000, clearKey: true },
      discovery: { scope: '', username: '', hosts: [], clearPassword: true },
      serial: { path: '', baudRate: 9600, autoConnect: false, vendor: 'auto' },
    });
  }
  behavior.failCommand = null;
  behavior.backupOutput = null;
  transcript.length = 0;
  connectCalls.length = 0;
  probeCalls.length = 0;
  listCalls = 0;
}, { timeout: 30_000 });

afterEach(async () => {
  releaseGates();
  if (application?.server.listening) await waitForIdle();
}, { timeout: 35_000 });

after(async () => {
  releaseGates();
  try {
    if (application) {
      try { if (application.server.listening) await waitForIdle(); }
      finally {
        await application.shutdown();
        await application.store.persist(); // Drain close-event persistence before the parent removes its directory.
      }
      assert.ok(connections.every(connection => !connection.isConnected));
      assert.equal(application.server.listening, false);
    }
  } finally {
    if (canary) {
      canary.closeAllConnections();
      await new Promise(resolveClose => canary.close(resolveClose));
    }
    transportMock?.restore();
  }
  assert.deepEqual(canaryRequests, [], 'no unauthorized request may reach even the local AI canary');
}, { timeout: 40_000 });

const apiTest = (name, work) => test(name, { timeout: 45_000 }, work);

apiTest('bootstrap, catalog and serial ports expose real API data, not demo topology', async () => {
  const bootstrap = await api('GET', '/api/bootstrap');
  const state = expectStatus(bootstrap, 200);
  assert.equal(state.csrfToken, csrfToken);
  assert.deepEqual(state.devices, []);
  assert.deepEqual(state.links, []);
  assert.equal(state.activeTask, null);
  assert.equal(state.settings.security.loopbackOnly, true);
  assert.equal(bootstrap.headers['cache-control'], 'no-store');
  assert.equal(bootstrap.headers['x-content-type-options'], 'nosniff');
  assert.equal(bootstrap.headers['referrer-policy'], 'no-referrer');
  assert.equal(bootstrap.headers['x-powered-by'], undefined);
  const catalog = expectStatus(await api('GET', '/api/catalog'), 200);
  assert.deepEqual(catalog.vendors.map(vendor => vendor.id).sort(), ['cisco', 'h3c', 'huawei', 'ruijie']);
  assert.ok(catalog.commands.some(command => command.vendor === 'huawei' && command.command === 'display version'));
  assert.ok(catalog.sources.some(source => source.vendor === 'huawei' && source.url.startsWith('https://')));
  assert.deepEqual(expectStatus(await api('GET', '/api/ports'), 200).ports, [{ path: 'COM99', manufacturer: 'NetPilot API fixture' }]);
  assert.equal(listCalls, 1);
  assert.deepEqual(connectCalls, []);
  assert.deepEqual(probeCalls, []);
});

apiTest('malicious Host, Origin and cross-site requests are denied before reads or device actions', async () => {
  const cases = [
    { Host: `attacker.invalid:${port}` },
    { Host: `127.0.0.1:${port}.attacker.invalid` },
    { Origin: 'https://attacker.invalid' },
    { Origin: `http://localhost:${port}.attacker.invalid` },
    { Origin: 'null' },
    { Origin: `file://localhost:${port}` },
    { 'Sec-Fetch-Site': 'cross-site' },
  ];
  for (const headers of cases) {
    expectStatus(await api('GET', '/api/bootstrap', undefined, { headers }), 403);
    expectStatus(await api('POST', '/api/connect', { kind: 'serial', path: 'COM99' }, { headers }), 403);
  }
  expectStatus(await api('GET', '/api/bootstrap', undefined, { headers: { Origin: baseUrl } }), 200);
  // Only the header is tested; no request is made to the running Vite port.
  expectStatus(await api('GET', '/api/catalog', undefined, { headers: { Origin: 'http://localhost:5173' } }), 200);
  assert.deepEqual(connectCalls, []);
  assert.deepEqual(transcript, []);
});

apiTest('every mutating API requires a valid CSRF token even with same-origin headers', async () => {
  const before = await getState();
  const routes = [
    ['POST', '/api/connect'], ['POST', '/api/disconnect'], ['POST', '/api/ssh/probe'],
    ['POST', '/api/discover'], ['POST', '/api/terminal'], ['POST', '/api/plans'],
    ['POST', '/api/execute'], ['POST', '/api/jobs/missing/cancel'], ['PUT', '/api/settings'],
    ['POST', '/api/ai/test'], ['POST', '/api/ai/chat'], ['POST', '/api/topology/clear'],
  ];
  for (const [method, path] of routes) {
    for (const headers of [{ Origin: baseUrl }, { Origin: baseUrl, 'X-NetPilot-CSRF': 'forged' }]) {
      expectStatus(await api(method, path, {}, { csrf: false, headers }), 403);
    }
  }
  assert.deepEqual(await getState(), before);
  assert.deepEqual(connectCalls, []);
  assert.deepEqual(probeCalls, []);
  assert.deepEqual(transcript, []);
});

apiTest('unknown API paths return JSON 404 rather than the frontend shell', async () => {
  for (const method of ['GET', 'POST', 'PUT']) {
    const response = await api(method, '/api/does-not-exist', method === 'GET' ? undefined : {});
    assert.equal(expectStatus(response, 404).error, '接口不存在');
    assert.match(response.headers['content-type'], /application\/json/);
  }
});

apiTest('SSH probing returns the transport fixture fingerprint without opening a session', async () => {
  const result = expectStatus(await api('POST', '/api/ssh/probe', { host: ROOT_IP, port: '22' }), 200);
  assert.equal(result.fingerprint, FINGERPRINT);
  assert.equal(result.host, ROOT_IP);
  assert.equal(result.port, 22);
  assert.deepEqual(probeCalls, [{ host: ROOT_IP, port: 22, timeoutMs: 8000 }]);
  assert.deepEqual(connectCalls, []);
  const count = probeCalls.length;
  expectStatus(await api('POST', '/api/ssh/probe', { host: '203.0.113.9', port: 22 }), 400);
  assert.equal(probeCalls.length, count, 'invalid public targets must not reach the transport');
});

apiTest('connection normalizes empty frontend credentials and performs only identity/paging queries', async () => {
  const { device, jobId } = await connect();
  assert.equal(jobId, undefined);
  assert.equal(device.name, ROOT_NAME);
  assert.equal(device.vendor, 'huawei');
  assert.equal(device.model, 'S5720-28X-SI-AC');
  assert.match(device.version, /5\.170/);
  assert.equal(device.connected, true);
  assert.equal(connectCalls.length, 1);
  assert.equal(connectCalls[0].username, undefined);
  assert.equal(Object.hasOwn(connectCalls[0], 'username'), false);
  assert.equal(connectCalls[0].password, undefined);
  assert.equal(connectCalls[0].baudRate, 9600);
  assert.deepEqual(commandsSince(0), ['display version', 'screen-length 0 temporary']);
  assert.equal((await getState()).devices[0].id, device.id);
});

apiTest('invalid connection input is rejected before constructing any device transport', async () => {
  const serial = { kind: 'serial', path: 'COM99', baudRate: 9600, vendor: 'auto' };
  const invalid = [
    { ...serial, path: 'COM98' }, { ...serial, baudRate: 12345 },
    { ...serial, vendor: 'unsupported' }, { ...serial, username: 'fixture\nadmin' },
    { kind: 'ssh', host: ROOT_IP, vendor: 'auto' },
    { kind: 'ssh', host: '203.0.113.9', fingerprint: FINGERPRINT, vendor: 'auto' },
  ];
  const created = connections.length;
  for (const body of invalid) expectStatus(await api('POST', '/api/connect', body), 400);
  assert.equal(connections.length, created);
  assert.deepEqual(connectCalls, []);
  assert.deepEqual(transcript, []);
  assert.deepEqual((await getState()).devices, []);
});

apiTest('read-only terminal accepts a complete whitelist query and rejects writes/batching/injection', async () => {
  const { device } = await connect();
  const query = expectStatus(await api('POST', '/api/terminal', { deviceId: device.id, command: 'display version' }), 200);
  assert.equal(query.ok, true);
  assert.equal(query.output, VERSION);
  const start = transcript.length;
  for (const command of ['sysname SHOULD_NOT_RUN', 'display version\ndisplay clock', 'display version; sysname X', 'display version | include VRP', 'display arbitrary-not-whitelisted']) {
    expectStatus(await api('POST', '/api/terminal', { deviceId: device.id, command }), 400);
  }
  assert.deepEqual(commandsSince(start), []);
  behavior.failCommand = 'display version';
  const failed = expectStatus(await api('POST', '/api/terminal', { deviceId: device.id, command: 'display version' }), 200);
  assert.equal(failed.ok, false);
  assert.match(failed.output, /Error:/);
  assert.equal((await getState()).audit.find(entry => entry.action === '只读查询').status, 'failed');
});

apiTest('connect-and-discover builds exactly the CLI-advertised topology with a distinct management IP', async () => {
  const fingerprint = expectStatus(await api('POST', '/api/ssh/probe', { host: ROOT_IP }), 200).fingerprint;
  const { device, jobId } = await connect({ kind: 'ssh', host: ROOT_IP, port: '22', fingerprint, discover: true });
  assert.ok(jobId);
  assert.equal((await waitForJob(jobId)).status, 'completed');
  const state = await getState();
  assert.equal(state.devices.length, 2);
  const neighbor = state.devices.find(item => item.id !== device.id);
  assert.equal(state.devices.find(item => item.id === device.id).managementIp, ROOT_IP);
  assert.equal(neighbor.name, NEIGHBOR_NAME);
  assert.equal(neighbor.managementIp, NEIGHBOR_IP);
  assert.equal(neighbor.vendor, 'huawei');
  assert.equal(neighbor.source, 'LLDP');
  assert.equal(neighbor.depth, 1);
  assert.notEqual(neighbor.connected, true);
  assert.equal(state.links.length, 1);
  const { source, target, localPort, remotePort, protocol } = state.links[0];
  assert.deepEqual({ source, target, localPort, remotePort, protocol }, {
    source: device.id, target: neighbor.id, localPort: 'GigabitEthernet0/0/1', remotePort: 'GigabitEthernet0/0/24', protocol: 'LLDP',
  });
  assert.deepEqual(commandsSince(0), ['display version', 'screen-length 0 temporary', 'display lldp neighbor']);
  assert.equal(connectCalls.length, 1, 'nonrecursive discovery must not log in to neighbors');
});

apiTest('recursive discovery requires scope, username and password before creating a job', async () => {
  const { device } = await connect();
  const jobCount = (await getState()).jobs.length;
  const start = transcript.length;
  const cases = [
    { scope: '', username: '', clearPassword: true },
    { scope: '192.168.249.0/24', username: '', password: 'synthetic-recursion-password' },
    { scope: '192.168.249.0/24', username: 'fixture', clearPassword: true },
    { scope: '', username: 'fixture', password: 'synthetic-recursion-password' },
  ];
  for (const discovery of cases) {
    await saveSettings({ discovery });
    const result = expectStatus(await api('POST', '/api/discover', { deviceId: device.id, recursive: true }), 400);
    assert.match(result.error, /管理范围、SSH 用户名和密码/);
    assert.equal((await getState()).jobs.length, jobCount);
    assert.deepEqual(commandsSince(start), []);
    assert.equal(connectCalls.length, 1);
  }
});

apiTest('recursive discovery never connects to an out-of-scope or untrusted advertised neighbor', async () => {
  const { device } = await connect();
  for (const discovery of [
    { scope: `${ROOT_IP}/32`, hosts: [{ host: NEIGHBOR_IP, fingerprint: FINGERPRINT, vendor: 'huawei', port: 22 }] },
    { scope: '192.168.249.0/24', hosts: [] },
  ]) {
    await saveSettings({ discovery: { ...discovery, username: 'fixture', password: 'synthetic-recursion-password' } });
    const start = transcript.length;
    const { jobId } = expectStatus(await api('POST', '/api/discover', { deviceId: device.id, recursive: true }), 200);
    const job = await waitForJob(jobId);
    assert.equal(job.status, 'completed');
    assert.ok(job.logs.some(log => /仅显示邻居/.test(log.message)));
    assert.deepEqual(commandsSince(start), ['display lldp neighbor']);
    assert.equal(connectCalls.length, 1);
  }
});

apiTest('VLAN preflight needs only vlan/name parameters and sends no device command', async () => {
  const { device } = await connect();
  const start = transcript.length;
  const plan = await planFor(device.id);
  assert.deepEqual(plan.commands, VLAN_COMMANDS);
  assert.deepEqual(plan.blocked, []);
  assert.equal(plan.backupRequired, true);
  assert.ok(plan.warnings.length);
  assert.ok(Date.parse(plan.expiresAt) > Date.now());
  assert.deepEqual(plan.devices.map(item => item.id), [device.id]);
  assert.deepEqual(commandsSince(start), []);
  assert.equal((await getState()).activeTask, null);
});

apiTest('preflight blocks forbidden commands and rejects disconnected or duplicate targets', async () => {
  const { device } = await connect();
  const start = transcript.length;
  expectStatus(await api('POST', '/api/plans', { deviceIds: [device.id, device.id], commands: 'display version' }), 400);
  expectStatus(await api('POST', '/api/plans', { deviceIds: ['missing-device'], commands: 'display version' }), 409);
  const blocked = expectStatus(await api('POST', '/api/plans', { deviceIds: [device.id], commands: 'reboot' }), 200);
  assert.ok(blocked.blocked.length);
  expectStatus(await execute(blocked.id), 400);
  expectStatus(await api('POST', '/api/disconnect', { deviceId: device.id }), 200);
  expectStatus(await api('POST', '/api/plans', { deviceIds: [device.id], commands: 'display version' }), 409);
  assert.deepEqual(commandsSince(start), []);
});

apiTest('execution requires exact confirmation and boolean risk acceptance without consuming a denied token', async () => {
  const { device } = await connect();
  const plan = await planFor(device.id);
  const start = transcript.length;
  const jobCount = (await getState()).jobs.length;
  for (const fields of [
    {}, { confirmation: '确认执行' }, { acceptRisk: true },
    { confirmation: '确认执行', acceptRisk: 'true' }, { confirmation: '确认', acceptRisk: true },
  ]) {
    expectStatus(await api('POST', '/api/execute', { planId: plan.id, ...fields }), 400);
    assert.deepEqual(commandsSince(start), []);
    assert.equal((await getState()).jobs.length, jobCount);
  }
  const { jobId } = expectStatus(await execute(plan.id), 200);
  assert.equal((await waitForJob(jobId)).status, 'completed', 'denied confirmations must not burn a valid plan');
});

apiTest('successful execution persists an encrypted backup before the first write and consumes the token once', async t => {
  const { device } = await connect();
  const plan = await planFor(device.id);
  const start = transcript.length;
  const gate = holdCommand('system-view');
  t.after(() => gate.release());
  const { jobId } = expectStatus(await execute(plan.id), 200);
  await gate.started;
  const running = getJob(await getState(), jobId);
  assert.equal(running.status, 'running');
  assert.equal(running.backupIds.length, 1, 'backup must already be saved when the first write is sent');
  const id = running.backupIds[0];
  const ciphertext = await readFile(join(directory, 'backups', `${id}.dpapi`), 'utf8');
  assert.ok(ciphertext.length > 40);
  assert.equal(ciphertext.includes(ROOT_NAME), false);
  assert.equal(ciphertext.includes(BACKUP), false);
  assert.deepEqual(commandsSince(start), [BACKUP_COMMAND, 'system-view']);
  assert.deepEqual(transcript[start].options, { timeoutMs: 45000 });
  gate.release();
  const job = await waitForJob(jobId);
  assert.equal(job.status, 'completed');
  assert.equal(job.progress, VLAN_COMMANDS.length);
  assert.equal(job.total, VLAN_COMMANDS.length);
  assert.deepEqual(commandsSince(start), [BACKUP_COMMAND, ...VLAN_COMMANDS]);
  const download = await api('GET', `/api/backups/${id}`);
  assert.equal(expectStatus(download, 200), BACKUP);
  assert.match(download.headers['content-type'], /text\/plain/);
  assert.equal(download.headers['cache-control'], 'no-store');
  const count = transcript.length;
  expectStatus(await execute(plan.id), 409);
  expectStatus(await execute(randomUUID()), 409);
  assert.equal(transcript.length, count);
  assert.equal((await getState()).audit.find(entry => entry.action === '配置执行').status, 'completed');
});

apiTest('simultaneous execution cannot duplicate a plan and busy tasks reject other device operations', async t => {
  const { device } = await connect();
  const plan = await planFor(device.id);
  const otherPlan = await planFor(device.id);
  const start = transcript.length;
  const initialJobs = (await getState()).jobs.length;
  const gate = holdCommand(BACKUP_COMMAND);
  t.after(() => gate.release());
  const responses = await Promise.all([execute(plan.id), execute(plan.id)]);
  assert.deepEqual(responses.map(response => response.status).sort(), [200, 409]);
  const { jobId } = responses.find(response => response.status === 200).body;
  await gate.started;
  const attempts = [
    ['/api/execute', { planId: otherPlan.id, confirmation: '确认执行', acceptRisk: true }],
    ['/api/terminal', { deviceId: device.id, command: 'display version' }],
    ['/api/ssh/probe', { host: ROOT_IP }],
    ['/api/connect', { kind: 'serial', path: 'COM99' }],
    ['/api/disconnect', { deviceId: device.id }],
    ['/api/plans', { deviceIds: [device.id], commands: 'display version' }],
    ['/api/discover', { deviceId: device.id }],
  ];
  for (const [path, body] of attempts) expectStatus(await api('POST', path, body), 409);
  assert.equal((await getState()).jobs.length, initialJobs + 1);
  assert.deepEqual(commandsSince(start), [BACKUP_COMMAND]);
  assert.equal(connectCalls.length, 1);
  assert.equal(probeCalls.length, 0);
  gate.release();
  assert.equal((await waitForJob(jobId)).status, 'completed');
  assert.deepEqual(commandsSince(start), [BACKUP_COMMAND, ...VLAN_COMMANDS]);
});

apiTest('CLI-error or malformed backups fail closed before any configuration command', async () => {
  const { device } = await connect();
  for (const output of ['Error: fixture cannot read configuration', 'not a configuration file; '.repeat(8)]) {
    behavior.backupOutput = output;
    const plan = await planFor(device.id);
    const start = transcript.length;
    const { jobId } = expectStatus(await execute(plan.id), 200);
    const job = await waitForJob(jobId);
    assert.equal(job.status, 'failed');
    assert.match(job.message, /备份失败或内容异常/);
    assert.equal(job.progress, 0);
    assert.deepEqual(job.backupIds, []);
    assert.deepEqual(commandsSince(start), [BACKUP_COMMAND]);
    expectStatus(await execute(plan.id), 409);
    assert.deepEqual(commandsSince(start), [BACKUP_COMMAND]);
  }
});

apiTest('a command Error stops the remaining sequence without retry, rollback or automatic save', async () => {
  const { device } = await connect();
  const plan = await planFor(device.id);
  behavior.failCommand = 'vlan 123';
  const start = transcript.length;
  const { jobId } = expectStatus(await execute(plan.id), 200);
  const job = await waitForJob(jobId);
  assert.equal(job.status, 'failed');
  assert.equal(job.progress, 1);
  assert.equal(job.backupIds.length, 1);
  assert.match(job.message, /部分命令可能已经生效/);
  assert.deepEqual(commandsSince(start), [BACKUP_COMMAND, 'system-view', 'vlan 123']);
  expectStatus(await execute(plan.id), 409);
  assert.deepEqual(commandsSince(start), [BACKUP_COMMAND, 'system-view', 'vlan 123']);
});

apiTest('cancel waits for an in-flight command and never sends the following command', async t => {
  const { device } = await connect();
  const plan = await planFor(device.id);
  const start = transcript.length;
  const gate = holdCommand('vlan 123');
  t.after(() => gate.release());
  const { jobId } = expectStatus(await execute(plan.id), 200);
  await gate.started;
  expectStatus(await api('POST', `/api/jobs/${jobId}/cancel`, {}), 200);
  const current = getJob(await getState(), jobId);
  assert.equal(current.cancelRequested, true);
  assert.equal(current.status, 'running');
  assert.equal(transcript.at(-1).finished, false);
  gate.release();
  const job = await waitForJob(jobId);
  assert.equal(job.status, 'cancelled');
  assert.deepEqual(commandsSince(start), [BACKUP_COMMAND, 'system-view', 'vlan 123']);
  expectStatus(await api('POST', `/api/jobs/${jobId}/cancel`, {}), 400);
  expectStatus(await execute(plan.id), 409);
});

apiTest('reconnecting the same device invalidates an old plan but a fresh plan can run', async () => {
  const { device } = await connect();
  const stale = await planFor(device.id);
  const originalConnection = connectCalls.at(-1).connectionId;
  expectStatus(await api('POST', '/api/disconnect', { deviceId: device.id }), 200);
  const reconnected = (await connect()).device;
  assert.equal(reconnected.id, device.id);
  assert.notEqual(connectCalls.at(-1).connectionId, originalConnection);
  const start = transcript.length;
  assert.match(expectStatus(await execute(stale.id), 409).error, /连接已变化/);
  assert.deepEqual(commandsSince(start), []);
  const fresh = expectStatus(await api('POST', '/api/plans', { deviceIds: [device.id], commands: 'display version' }), 200);
  assert.equal(fresh.backupRequired, false);
  const { jobId } = expectStatus(await execute(fresh.id), 200);
  const job = await waitForJob(jobId);
  assert.equal(job.status, 'completed');
  assert.deepEqual(job.backupIds, []);
  assert.deepEqual(commandsSince(start), ['display version']);
});

apiTest('saving synthetic credentials exposes only presence flags in settings, bootstrap, disk state and audit', async () => {
  const key = `NP_SYNTHETIC_KEY_${randomUUID()}`;
  const password = `NP_SYNTHETIC_PASSWORD_${randomUUID()}`;
  const response = await api('PUT', '/api/settings', {
    ai: { apiKey: key }, discovery: { username: 'fixture', scope: '192.168.249.0/24', password },
  });
  const settings = expectStatus(response, 200);
  assert.equal(settings.ai.hasKey, true);
  assert.equal(settings.discovery.hasPassword, true);
  assert.equal(settings.ai.apiKey, undefined);
  assert.equal(settings.discovery.password, undefined);
  const bootstrap = await api('GET', '/api/bootstrap');
  const state = expectStatus(bootstrap, 200);
  assert.equal(state.settings.ai.hasKey, true);
  assert.equal(state.settings.discovery.hasPassword, true);
  const stateFile = await readFile(join(directory, 'state.json'), 'utf8');
  const encrypted = await readFile(join(directory, 'secrets.dpapi'), 'utf8');
  assert.ok(encrypted.length > 40);
  assert.throws(() => JSON.parse(encrypted));
  for (const text of [response.text, bootstrap.text, stateFile, encrypted, JSON.stringify(application.store.state), JSON.stringify(state.audit)]) {
    assert.equal(text.includes(key), false, 'API key must not leak outside the encrypted vault');
    assert.equal(text.includes(password), false, 'device password must not leak outside the encrypted vault');
  }
  assert.equal(state.audit[0].action, '设置保存');
  assert.equal((await readdir(directory)).some(name => name.endsWith('.tmp')), false);
  const cleared = await saveSettings({ ai: { clearKey: true }, discovery: { clearPassword: true } });
  assert.equal(cleared.ai.hasKey, false);
  assert.equal(cleared.discovery.hasPassword, false);
  assert.equal(canaryRequests.length, 0);
});

apiTest('AI test/chat without explicit boolean consent never reaches the local canary or external AI', async () => {
  await saveSettings({ ai: { apiKey: `NP_SYNTHETIC_AI_${randomUUID()}` } });
  const before = await getState();
  assert.equal(before.settings.ai.baseUrl, canaryUrl);
  assert.equal(before.settings.ai.hasKey, true, 'missing credentials must not mask a consent regression');
  for (const path of ['/api/ai/test', '/api/ai/chat']) {
    for (const fields of [{}, { consent: false }, { consent: 'true' }, { consent: 1 }]) {
      const response = await api('POST', path, { ...fields, includeContext: true, messages: [{ role: 'user', content: 'synthetic API regression' }] });
      assert.match(expectStatus(response, 400).error, /明确同意/);
    }
  }
  assert.deepEqual(canaryRequests, []);
  assert.deepEqual((await getState()).audit, before.audit, 'denied consent must not even start an AI request');
  assert.deepEqual(transcript, []);
});
