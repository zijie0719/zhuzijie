import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readdir, rm, writeFile, utimes } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createStore, localVault } from '../server/store.mjs';

// 用恒等 vault 替代 Windows DPAPI，让测试可在任意平台跑存储层逻辑。
const passthrough = async value => value;

test('配置备份超过 120 份时按时间保留最新，旧文件被清理', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'netpilot-store-'));
  t.after(() => rm(directory, { recursive: true, force: true }).catch(() => {}));

  await createStore(directory, passthrough);
  const backupDir = join(directory, 'backups');
  const base = Date.now() - 200_000;
  for (let index = 0; index < 130; index += 1) {
    const name = `${String(index).padStart(8, '0')}-0000-0000-0000-000000000000.dpapi`;
    const file = join(backupDir, name);
    await writeFile(file, 'ciphertext');
    const stamp = new Date(base + index * 1000);
    await utimes(file, stamp, stamp);
  }

  // 重新打开存储即触发启动裁剪
  await createStore(directory, passthrough);
  const remaining = (await readdir(backupDir)).filter(name => name.endsWith('.dpapi'));
  assert.equal(remaining.length, 120);
  assert.equal(remaining.includes('00000000-0000-0000-0000-000000000000.dpapi'), false, '最旧的应被删除');
  assert.equal(remaining.includes('00000129-0000-0000-0000-000000000000.dpapi'), true, '最新的应保留');
});

test('保存新备份后立即裁剪，不会等到下次启动', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'netpilot-store-'));
  t.after(() => rm(directory, { recursive: true, force: true }).catch(() => {}));
  const store = await createStore(directory, passthrough);
  const backupDir = join(directory, 'backups');
  const base = Date.now() - 100_000;
  for (let index = 0; index < 120; index += 1) {
    const file = join(backupDir, `${String(index).padStart(8, '0')}-0000-0000-0000-000000000000.dpapi`);
    await writeFile(file, 'old');
    const stamp = new Date(base + index * 500);
    await utimes(file, stamp, stamp);
  }
  await store.saveBackup({ deviceId: 'device-demo', deviceName: 'DEMO-SW', vendor: 'huawei' }, 'hostname DEMO');
  assert.equal(store.state.backups.length, 1);
  assert.equal(store.state.backups[0].deviceName, 'DEMO-SW');
  assert.ok(store.state.backups[0].bytes > 0);
  const remaining = (await readdir(backupDir)).filter(name => name.endsWith('.dpapi'));
  assert.equal(remaining.length, 120);
});

test('非 Windows 加密：AES-256-GCM 往返、防篡改、跨密钥隔离', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'netpilot-vault-'));
  const other = await mkdtemp(join(tmpdir(), 'netpilot-vault-'));
  t.after(() => Promise.all([rm(directory, { recursive: true, force: true }), rm(other, { recursive: true, force: true })]).catch(() => {}));

  const vault = await localVault(directory);
  const cipher = await vault('sk-secret-123456');
  assert.match(cipher, /^v1:[A-Za-z0-9+/=]+:[A-Za-z0-9+/=]+:[A-Za-z0-9+/=]+$/);
  assert.notEqual(cipher, 'sk-secret-123456');
  assert.equal(await vault(cipher, true), 'sk-secret-123456');

  const tampered = `${cipher.slice(0, -4)}AAAA`;
  await assert.rejects(() => vault(tampered, true), /authenticate|unable|bad decrypt|密文/i);

  const foreign = await localVault(other);
  await assert.rejects(() => foreign(cipher, true));
});

test('密钥与配置在重启后可解密（注入本机密钥的存储）', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'netpilot-vault-'));
  t.after(() => rm(directory, { recursive: true, force: true }).catch(() => {}));
  const vault = await localVault(directory);
  const store = await createStore(directory, vault);
  await store.saveSettings({ ...store.state.settings, ai: { ...store.state.settings.ai, model: 'deepseek-chat' } }, { apiKey: 'sk-persist-test' });

  const reopened = await createStore(directory, await localVault(directory));
  assert.equal(reopened.secrets.apiKey, 'sk-persist-test');
  assert.equal(reopened.safeSettings().ai.hasKey, true);
  assert.match(reopened.safeSettings().security.encryption, /AES-256-GCM|DPAPI|注入式/);
});

test('旧数据结构会补齐新字段，不会把 undefined 带进设置', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'netpilot-store-'));
  t.after(() => rm(directory, { recursive: true, force: true }).catch(() => {}));
  const legacy = {
    settings: { ai: { provider: 'deepseek', baseUrl: 'https://api.deepseek.com', model: 'deepseek-chat', timeoutMs: 90000 }, discovery: { username: '', scope: '', hosts: [] }, serial: { path: '', baudRate: 9600, autoConnect: false, vendor: 'auto' } },
    devices: [{ id: 'legacy-1', name: 'OLD-SW', vendor: 'huawei', status: 'stale' }], links: [], jobs: [], audit: [],
  };
  await writeFile(join(directory, 'state.json'), JSON.stringify(legacy));
  const store = await createStore(directory, passthrough);
  assert.equal(store.state.settings.discovery.autoRefresh, 0);
  assert.deepEqual(store.state.backups, []);
  assert.equal(store.state.devices[0].connected, false);
  assert.equal(store.state.devices[0].status, 'stale');
});
