import test from 'node:test';
import assert from 'node:assert/strict';
import {
  VENDORS, COMMANDS, SOURCES, vendorProfile, detectVendor,
  parseNeighbors, parseDevice, buildTemplate,
} from '../server/vendors.mjs';

// 以下全部为合成 fixture，不是实机采集。沿用常见英文 CLI 详细输出形态，
// 名称、文档专用 IP、MAC、型号及版本组合只用于测试，不证明具体版本兼容。
const fixtures = {
  huawei: `<EDGE-HW>display lldp neighbor
GigabitEthernet0/0/1 has 1 neighbor(s):
Neighbor index : 1
Chassis type : MAC address
Chassis ID : 0011-2233-4455
Port ID type : Interface name
Port ID : GigabitEthernet0/0/24
Port description : Uplink to access
System name : CORE-HW
System description : Huawei Versatile Routing Platform Software
VRP (R) software, Version 5.170 (S5720 V200R019C10SPC500)
System capabilities supported : bridge router
System capabilities enabled : bridge router
Management address type : IPv4
Management address : 192.0.2.10
Expired time : 102s
<EDGE-HW>`,
  h3c: `<EDGE-H3C>display lldp neighbor-information verbose
LLDP neighbor-information of port 1[GigabitEthernet1/0/1]:
 LLDP agent nearest-bridge:
  LLDP neighbor index : 1
  Update time : 0 days, 0 hours, 1 minutes, 20 seconds
  Chassis type : MAC address
  Chassis ID : 00aa-bbcc-ddee
  Port ID type : Interface name
  Port ID : Ten-GigabitEthernet1/0/49
  Time to live : 120
  Port description : Campus uplink
  System name : CORE-H3C
  System description :
    H3C Comware Software, Version 7.1.070, Release 3507P02
    H3C S5130S-28P-EI
  System capabilities supported : Bridge, Router
  System capabilities enabled : Bridge, Router
  Management address type : IPv4
  Management address : 198.51.100.20
  Interface numbering subtype : ifIndex
  Interface number : 49
<EDGE-H3C>`,
  ruijie: `EDGE-RG#show lldp neighbors detail
Local port: GigabitEthernet 0/1
Chassis ID type: MAC address
Chassis ID: 00d0.f800.1234
Port ID type: Interface name
Port ID: GigabitEthernet 0/24
Port description: Uplink
System name: CORE-RG
System description: Ruijie RG-S2910-24GT4SFP-UP-H
RGOS 11.4(1)B70P1 Release Software
System capabilities: Bridge, Router
Enabled capabilities: Bridge, Router
Management address: 203.0.113.30
Time to live: 120
EDGE-RG#`,
  cisco: `EDGE-CS#show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/0/1
Chassis id: aabb.ccdd.eeff
Port id: Gi1/0/48
Port Description: GigabitEthernet1/0/48
System Name: CORE-CS.example.test
System Description:
Cisco IOS XE Software, Version 17.09.04a
Technical Support: http://example.test/support
Copyright (c) 1986-2023 by Cisco Systems, Inc.
Time remaining: 103 seconds
System Capabilities: B,R
Enabled Capabilities: B,R
Management Addresses:
    IP: 192.0.2.40
    IPV6: 2001:db8::40
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Total entries displayed: 1
EDGE-CS#`,
  cdp: `EDGE-CS#show cdp neighbors detail
-------------------------
Device ID: CORE-CDP.example.test
Entry address(es):
  IP address: 192.0.2.50
  IPv6 address: 2001:db8::50 (global unicast)
Platform: cisco C9300-24T, Capabilities: Switch IGMP
Interface: GigabitEthernet1/0/2, Port ID (outgoing port): GigabitEthernet1/0/47
Holdtime : 153 sec
Version :
Cisco IOS XE Software, Version 17.09.04a
Technical Support: http://example.test/support
advertisement version: 2
VTP Management Domain: lab
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 198.51.100.50

-------------------------
Device ID: PHONE-NO-IP
Entry address(es):
Platform: Cisco IP Phone, Capabilities: Host Phone
Interface: GigabitEthernet1/0/3, Port ID (outgoing port): Port 1
Holdtime : 140 sec
Version :
SIP synthetic test build
advertisement version: 2
Total cdp entries displayed : 2
EDGE-CS#`,
};

const expected = {
  huawei: { name: 'CORE-HW', chassisId: '0011-2233-4455', managementIp: '192.0.2.10', localPort: 'GigabitEthernet0/0/1', remotePort: 'GigabitEthernet0/0/24', description: 'Huawei Versatile Routing Platform Software\nVRP (R) software, Version 5.170 (S5720 V200R019C10SPC500)', protocol: 'LLDP' },
  h3c: { name: 'CORE-H3C', chassisId: '00aa-bbcc-ddee', managementIp: '198.51.100.20', localPort: 'GigabitEthernet1/0/1', remotePort: 'Ten-GigabitEthernet1/0/49', description: 'H3C Comware Software, Version 7.1.070, Release 3507P02\nH3C S5130S-28P-EI', protocol: 'LLDP' },
  ruijie: { name: 'CORE-RG', chassisId: '00d0.f800.1234', managementIp: '203.0.113.30', localPort: 'GigabitEthernet 0/1', remotePort: 'GigabitEthernet 0/24', description: 'Ruijie RG-S2910-24GT4SFP-UP-H\nRGOS 11.4(1)B70P1 Release Software', protocol: 'LLDP' },
  cisco: { name: 'CORE-CS.example.test', chassisId: 'aabb.ccdd.eeff', managementIp: '192.0.2.40', localPort: 'Gi1/0/1', remotePort: 'Gi1/0/48', description: 'Cisco IOS XE Software, Version 17.09.04a\nTechnical Support: http://example.test/support\nCopyright (c) 1986-2023 by Cisco Systems, Inc.', protocol: 'LLDP' },
};

const vendorIds = ['huawei', 'h3c', 'ruijie', 'cisco'];

test('profiles have the exact contract and discovery/backup are read-only', () => {
  assert.deepEqual(VENDORS.map((profile) => profile.id), vendorIds);
  for (const profile of VENDORS) {
    assert.deepEqual(Object.keys(profile).sort(), ['id', 'label', 'os', 'color', 'versionCommand', 'neighborsCommands', 'pagingCommand', 'backupCommand'].sort());
    assert.equal(vendorProfile(profile.id), profile);
    for (const command of [profile.versionCommand, profile.backupCommand, ...profile.neighborsCommands]) {
      assert.match(command, /^(display|show) /);
      assert.doesNotMatch(command, /[\r\n;]/);
    }
    assert.ok(profile.label && profile.os && profile.color && profile.pagingCommand);
    assert.ok(Object.isFrozen(profile.neighborsCommands));
  }
  for (const invalid of ['unknown', 'HUAWEI', '__proto__', '', null, undefined, {}, 0]) {
    assert.throws(() => vendorProfile(invalid), RangeError);
  }
});

test('catalog has at least 20 practical commands per vendor, complete fields and official sources', () => {
  const ids = new Set();
  const officialHosts = { huawei: 'support.huawei.com', h3c: 'www.h3c.com', ruijie: 'www.ruijie.com', cisco: 'www.cisco.com' };
  for (const vendor of vendorIds) {
    const commands = COMMANDS.filter((command) => command.vendor === vendor);
    assert.ok(commands.length >= 20);
    for (const category of ['系统', '接口', 'VLAN', '路由', '邻居', '安全', '诊断']) {
      assert.ok(commands.some((command) => command.category === category));
    }
    assert.ok(commands.some((command) => command.command.includes('<接口>')));
    assert.ok(commands.some((command) => command.command.includes('<VLAN>')));
    assert.ok(commands.some((command) => command.risk === 'danger'));
    assert.ok(SOURCES.some((source) => source.vendor === vendor));
  }
  for (const command of COMMANDS) {
    assert.deepEqual(Object.keys(command).sort(), ['id', 'vendor', 'category', 'title', 'command', 'description', 'mode', 'risk', 'notes'].sort());
    assert.ok(!ids.has(command.id));
    ids.add(command.id);
    assert.ok(Object.values(command).every((value) => typeof value === 'string' && value.length));
    assert.ok(['read', 'write', 'danger'].includes(command.risk));
    if (/^(?:shutdown|sysname |hostname |port |switchport |vlan |name )/.test(command.command)) assert.notEqual(command.risk, 'read');
  }
  for (const source of SOURCES) {
    assert.deepEqual(Object.keys(source).sort(), ['vendor', 'label', 'url'].sort());
    const url = new URL(source.url);
    assert.equal(url.protocol, 'https:');
    assert.equal(url.hostname, officialHosts[source.vendor]);
  }
  // 目录是一张四厂商对齐的命令矩阵：行数一致，Cisco 额外有一条 CDP 专项。
  const counts = Object.fromEntries(vendorIds.map((vendor) => [vendor, COMMANDS.filter((command) => command.vendor === vendor).length]));
  assert.equal(counts.h3c, counts.huawei);
  assert.equal(counts.ruijie, counts.huawei);
  assert.equal(counts.cisco, counts.huawei + 1);
  assert.ok(counts.huawei >= 40, '每个厂商至少 40 条常用命令');
  assert.equal(COMMANDS.length, Object.values(counts).reduce((sum, value) => sum + value, 0));
});

for (const vendor of vendorIds) {
  test(`${vendor}: parse synthetic LLDP detailed fixture`, () => {
    assert.deepEqual(parseNeighbors(fixtures[vendor], vendor), [expected[vendor]]);
  });

  test(`${vendor}: same chassis/name/IP on different local ports is not merged`, () => {
    const original = expected[vendor];
    const otherPort = original.localPort.replace(/1$/, '2');
    const other = fixtures[vendor].replaceAll(original.localPort, otherPort);
    assert.deepEqual(parseNeighbors(`${fixtures[vendor]}\n${other}`, vendor), [original, { ...original, localPort: otherPort }]);
  });

  test(`${vendor}: retain neighbor with missing management IP, never mine IP from description`, () => {
    const source = fixtures[vendor]
      .replace(/^.*(?:Management address|IP:|IPV6:).*$/gim, '')
      .replace(/(System description\s*:)/i, '$1 Reference 192.0.2.250;');
    const neighbors = parseNeighbors(source, vendor);
    assert.equal(neighbors.length, 1);
    assert.equal(neighbors[0].name, expected[vendor].name);
    assert.equal(neighbors[0].managementIp, '');
  });
}

test('Cisco CDP: management address preferred, no invented chassis ID, no-IP neighbor retained', () => {
  assert.deepEqual(parseNeighbors(fixtures.cdp, 'cisco'), [
    { name: 'CORE-CDP.example.test', chassisId: '', managementIp: '198.51.100.50', localPort: 'GigabitEthernet1/0/2', remotePort: 'GigabitEthernet1/0/47', description: 'Cisco IOS XE Software, Version 17.09.04a\nTechnical Support: http://example.test/support', protocol: 'CDP' },
    { name: 'PHONE-NO-IP', chassisId: '', managementIp: '', localPort: 'GigabitEthernet1/0/3', remotePort: 'Port 1', description: 'SIP synthetic test build', protocol: 'CDP' },
  ]);
});

test('Cisco CDP: fallback to advertised entry IP and preserve repeated device on separate links', () => {
  const source = `Device ID: 0011.2233.4455
Entry address(es):
  IP address: 192.0.2.6
Platform: cisco C9200L, Capabilities: Switch IGMP
Interface: Gi1/0/1, Port ID (outgoing port): Gi1/0/48
Holdtime: 100 sec
--------------------
Device ID: 0011.2233.4455
Entry address(es):
  IP address: 192.0.2.6
Platform: cisco C9200L, Capabilities: Switch IGMP
Interface: Gi1/0/2, Port ID (outgoing port): Gi1/0/47
Holdtime: 100 sec`;
  const neighbors = parseNeighbors(source, 'cisco');
  assert.equal(neighbors.length, 2);
  assert.deepEqual(neighbors.map((neighbor) => neighbor.localPort), ['Gi1/0/1', 'Gi1/0/2']);
  for (const neighbor of neighbors) {
    assert.equal(neighbor.chassisId, '0011.2233.4455');
    assert.equal(neighbor.managementIp, '192.0.2.6');
    assert.equal(neighbor.description, 'cisco C9200L');
    assert.equal(neighbor.protocol, 'CDP');
  }
});

test('H3C: neighbor index boundaries retain multiple neighbors under one parent port', () => {
  const source = `LLDP neighbor-information of port 1[GigabitEthernet1/0/1]:
 LLDP agent nearest-bridge:
 LLDP neighbor index : 1
 Chassis ID : 0011-2233-4455
 Port ID : GigabitEthernet1/0/20
 System name : CORE
 Management address : 192.0.2.7
 LLDP neighbor index : 2
 Chassis ID : 0011-2233-4455
 Port ID : GigabitEthernet1/0/21
 System name : CORE
 Management address type : MAC address
 Management address : 0011-2233-4455`;
  const neighbors = parseNeighbors(source, 'h3c');
  assert.equal(neighbors.length, 2);
  assert.deepEqual(neighbors.map((neighbor) => neighbor.localPort), ['GigabitEthernet1/0/1', 'GigabitEthernet1/0/1']);
  assert.deepEqual(neighbors.map((neighbor) => neighbor.remotePort), ['GigabitEthernet1/0/20', 'GigabitEthernet1/0/21']);
  assert.deepEqual(neighbors.map((neighbor) => neighbor.managementIp), ['192.0.2.7', '']);
});

test('Huawei: zero-neighbor ports and unnamed neighbors do not pollute following records', () => {
  const source = `GigabitEthernet0/0/1 has 0 neighbor(s):
GigabitEthernet0/0/2 has 1 neighbor(s):
Neighbor index : 1
Chassis ID : 0000-1111-2222
Port ID : Ethernet1
Port description : Not the remote port ID
System name : not advertised
System description : N/A
Management address : 0.0.0.0`;
  assert.deepEqual(parseNeighbors(source, 'huawei'), [{ name: '', chassisId: '0000-1111-2222', managementIp: '', localPort: 'GigabitEthernet0/0/2', remotePort: 'Ethernet1', description: '', protocol: 'LLDP' }]);
});

test('RGOS: parent port header, compact key aliases and IPv6-only management', () => {
  const source = `LLDP neighbor-information of port [GigabitEthernet 0/8]:
Neighbor index: 1
ChassisID: 00d0.f800.4567
PortID: Gi0/24
SysName: IPV6-ONLY
SysDescr: RGOS synthetic test
Management Address: 2001:db8::8`;
  assert.deepEqual(parseNeighbors(source, 'ruijie'), [{ name: 'IPV6-ONLY', chassisId: '00d0.f800.4567', managementIp: '2001:db8::8', localPort: 'GigabitEthernet 0/8', remotePort: 'Gi0/24', description: 'RGOS synthetic test', protocol: 'LLDP' }]);
});

test('RGOS: neighbor indexes after a local interface header retain that interface', () => {
  const source = `Interface: GigabitEthernet 0/3
LLDP Neighbor Information:
Neighbor index: 1
Chassis ID: 00d0.f800.4567
Port ID: Gi0/24
System Name: CORE-A
Neighbor index: 2
Chassis ID: 00d0.f800.4568
Port ID: Gi0/23
System Name: CORE-B`;
  const neighbors = parseNeighbors(source, 'ruijie');
  assert.equal(neighbors.length, 2);
  assert.deepEqual(neighbors.map((neighbor) => neighbor.localPort), ['GigabitEthernet 0/3', 'GigabitEthernet 0/3']);
  assert.deepEqual(neighbors.map((neighbor) => neighbor.name), ['CORE-A', 'CORE-B']);
});

test('management IP must be valid and explicitly in an address field or section', () => {
  const prefix = 'Local Intf: Gi1/0/1\nChassis id: 192.0.2.12\nPort id: Gi1/0/48\nSystem Name: core\n';
  for (const address of ['999.1.1.1', '192.0.2.2garbage', '0.0.0.0', '::', 'not advertised', 'N/A']) {
    assert.equal(parseNeighbors(`${prefix}Management Address: ${address}`, 'cisco')[0].managementIp, '');
  }
  assert.equal(parseNeighbors(`${prefix}IP address: 192.0.2.33`, 'cisco')[0].managementIp, '');
  assert.equal(parseNeighbors(`${prefix}Management Addresses:\n  2001:db8::22\n  192.0.2.22`, 'cisco')[0].managementIp, '192.0.2.22');
  assert.equal(parseNeighbors(`${prefix}Management Addresses:\n IPv6: 2001:db8::22`, 'cisco')[0].managementIp, '2001:db8::22');
});

test('combined LLDP/CDP output keeps protocol records and does not inherit neighbor fields', () => {
  const source = `${fixtures.cisco}\n${fixtures.cdp}`;
  const neighbors = parseNeighbors(source, 'cisco');
  assert.equal(neighbors.length, 3);
  assert.deepEqual(neighbors.map((neighbor) => neighbor.protocol), ['LLDP', 'CDP', 'CDP']);
  assert.equal(neighbors[2].managementIp, '');
  assert.equal(neighbors[2].chassisId, '');
});

test('empty, unknown, errors, bare command echoes and brief tables produce no neighbors', () => {
  const invalidOutputs = [null, undefined, 4, {}, '', '   ', '% CDP is not enabled',
    'Error: Unrecognized command found at \'^\' position.', '% Invalid input detected at \'^\' marker.',
    'Info: LLDP is not enabled.', 'No LLDP neighbors found.',
    '<SW>display lldp neighbor\n<SW>', '[SW]display lldp neighbor\n[SW]',
    'SW#show cdp neighbors detail\nSW#', 'show lldp neighbors detail',
    'SW#show lldp neighbors detail System Name: fake\nSW#',
    'Device ID        Local Intrfce     Holdtme Capability Platform Port ID\ncore             Gi1/0/1          120     S          C9300    Gi1/0/48',
  ];
  for (const vendor of vendorIds) {
    for (const source of invalidOutputs) assert.deepEqual(parseNeighbors(source, vendor), [], `${vendor}: ${String(source)}`);
  }
  assert.deepEqual(parseNeighbors(fixtures.cisco, 'unknown'), []);
});

test('failed later command does not erase successful LLDP, error help is not data', () => {
  const source = `${fixtures.cisco}\nEDGE-CS#show cdp neighbors detail\n% Invalid input detected at '^' marker.\nSystem Name: fake\nChassis id: 0011.2233.4455\nPort id: Gi9/9\nEDGE-CS#`;
  assert.deepEqual(parseNeighbors(source, 'cisco'), [expected.cisco]);
});

test('CRLF, ANSI, paging markers and terminal backspaces are transport noise', () => {
  const source = `\x1b[32m${fixtures.cisco.replace('System Name:', '--More--\nSystem Name:').replace('aabb.ccdd.eeff', 'aabb.ccdd.eefx\bf')}\x1b[0m`.replaceAll('\n', '\r\n');
  assert.deepEqual(parseNeighbors(source, 'cisco'), [expected.cisco]);
});

const deviceFixtures = [
  ['huawei', `<ACCESS-HW>display version
Huawei Versatile Routing Platform Software
VRP (R) software, Version 5.170 (S5720 V200R019C10SPC500)
HUAWEI S5720-28X-SI-AC Routing Switch uptime is 12 weeks, 1 day
<ACCESS-HW>`, { name: 'ACCESS-HW', model: 'S5720-28X-SI-AC', version: '5.170 (S5720 V200R019C10SPC500)' }],
  ['h3c', `<ACCESS-H3C>display version
H3C Comware Software, Version 7.1.070, Release 3507P02
Copyright (c) 2004-2024 New H3C Technologies Co., Ltd.
H3C S5130S-28P-EI uptime is 2 weeks, 3 days
[ACCESS-H3C]`, { name: 'ACCESS-H3C', model: 'S5130S-28P-EI', version: '7.1.070, Release 3507P02' }],
  ['ruijie', `ACCESS-RG#show version
System description : Ruijie Gigabit Switch (RG-S2910-24GT4SFP-UP-H) By Ruijie Networks
System start time : 2024-01-01 00:00:00
System software version : RGOS 11.4(1)B70P1
System hardware version : 1.00
ACCESS-RG#`, { name: 'ACCESS-RG', model: 'RG-S2910-24GT4SFP-UP-H', version: 'RGOS 11.4(1)B70P1' }],
  ['cisco', `ACCESS-CS#show version
Cisco IOS XE Software, Version 17.09.04a
Cisco IOS Software [Cupertino], Catalyst L3 Switch Software (CAT9K_IOSXE), Version 17.9.4a, RELEASE SOFTWARE (fc3)
ACCESS-CS uptime is 3 weeks, 1 day
cisco C9300-24T (X86) processor with 1331379K/6147K bytes of memory.
Model Number : C9300-24T
ACCESS-CS(config-if)#`, { name: 'ACCESS-CS', model: 'C9300-24T', version: '17.09.04a' }],
  ['cisco', `SW-IOS#show version
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(7)E9, RELEASE SOFTWARE (fc1)
cisco WS-C2960X-48FPS-L (APM86XXX) processor with 524288K bytes of memory.
SW-IOS>`, { name: 'SW-IOS', model: 'WS-C2960X-48FPS-L', version: '15.2(7)E9' }],
];

for (const [vendor, source, result] of deviceFixtures) {
  test(`${vendor}: synthetic version fixture identifies local model/version and trailing hostname ${result.name}`, () => {
    assert.equal(detectVendor(source), vendor);
    assert.deepEqual(parseDevice(source, vendor), result);
  });
}

test('detectVendor: OS signatures beat generic branding, H3C is distinguished from Huawei', () => {
  const cases = [
    ['Huawei-3Com S5500 Software, Version 5.20', 'h3c'],
    ['Copyright Huawei Technologies\nH3C Comware Software, Version 7.1.070', 'h3c'],
    ['HPE Comware Software, Version 7.1.070', 'h3c'],
    ['H3C compatibility notice\nVRP (R) software, Version 5.170', 'huawei'],
    ['Cisco compatibility notice\nRuijie RGOS Software, Version 11.4', 'ruijie'],
    ['Cisco IOS-XE Software, Version 17.9.4', 'cisco'],
    ['Cisco Internetwork Operating System Software', 'cisco'],
    ['Quidway S5700', 'huawei'],
    ['H3C S5130S', 'h3c'],
    ['Ruijie Networks', 'ruijie'],
    ['Cisco Systems, Inc.', 'cisco'],
    ['Huawei Technologies Co., Ltd.', 'huawei'],
  ];
  for (const [source, vendor] of cases) assert.equal(detectVendor(source), vendor, source);
  for (const source of ['', null, undefined, {}, '<Huawei>display version\n<Huawei>', 'Cisco#show version\nCisco#', 'display version', 'not identifiable']) {
    assert.equal(detectVendor(source), 'unknown');
  }
});

test('local device identity cannot be replaced by a remote Comware/Cisco neighbor description', () => {
  const [vendor, source, result] = deviceFixtures[0];
  const combined = `${source}\n${fixtures.h3c}\n<ACCESS-HW>`;
  assert.equal(detectVendor(combined), vendor);
  assert.deepEqual(parseDevice(combined, vendor), result);
  assert.equal(detectVendor(fixtures.cisco), 'unknown');
});

test('parseDevice: unknown fields empty, final prompt wins and known view suffix is removed', () => {
  for (const source of ['', undefined, null, 'No version information', 'SW#show version']) {
    assert.deepEqual(parseDevice(source, 'cisco'), { name: '', model: '', version: '' });
  }
  assert.deepEqual(parseDevice('older uptime is 2 days\nnew-edge(config-vlan)#', 'cisco'), { name: 'new-edge', model: '', version: '' });
  assert.deepEqual(parseDevice('[~core-west-01-GigabitEthernet0/0/1]', 'huawei'), { name: 'core-west-01', model: '', version: '' });
  assert.deepEqual(parseDevice('[*core-west-01]', 'huawei'), { name: 'core-west-01', model: '', version: '' });
  assert.deepEqual(parseDevice('<mystery>', 'unknown'), { name: 'mystery', model: '', version: '' });
});

const templateProfiles = {
  huawei: { enter: 'system-view', exit: 'quit', finish: 'return', port: 'GigabitEthernet0/0/1', name: 'sysname', accessMode: 'port link-type access', access: 'port default vlan', trunkMode: 'port link-type trunk', trunk: 'port trunk allow-pass vlan', ranges: '1 10 to 12 20 4094' },
  h3c: { enter: 'system-view', exit: 'quit', finish: 'return', port: 'GigabitEthernet1/0/1', name: 'sysname', accessMode: 'port link-type access', access: 'port access vlan', trunkMode: 'port link-type trunk', trunk: 'port trunk permit vlan', ranges: '1 10 to 12 20 4094' },
  ruijie: { enter: 'configure terminal', exit: 'exit', finish: 'end', port: 'GigabitEthernet 0/1', name: 'hostname', accessMode: 'switchport mode access', access: 'switchport access vlan', trunkMode: 'switchport mode trunk', trunk: 'switchport trunk allowed vlan add', ranges: '1,10-12,20,4094' },
  cisco: { enter: 'configure terminal', exit: 'exit', finish: 'end', port: 'Gi1/0/1', name: 'hostname', accessMode: 'switchport mode access', access: 'switchport access vlan', trunkMode: 'switchport mode trunk', trunk: 'switchport trunk allowed vlan add', ranges: '1,10-12,20,4094' },
};

for (const [vendor, profile] of Object.entries(templateProfiles)) {
  test(`${vendor}: VLAN, access, trunk, hostname templates have complete view transitions`, () => {
    const vlan = buildTemplate(vendor, 'vlan', { vlan: '10', name: 'OFFICE_10' });
    const access = buildTemplate(vendor, 'access', { vlan: 10, interface: profile.port });
    const trunk = buildTemplate(vendor, 'trunk', { vlans: '20, 10-12,11,1,4094', interface: profile.port });
    const hostname = buildTemplate(vendor, 'hostname', { name: 'edge-west-01' });
    assert.deepEqual(vlan, [profile.enter, 'vlan 10', 'name OFFICE_10', profile.exit, profile.finish]);
    assert.deepEqual(access, [profile.enter, `interface ${profile.port}`, profile.accessMode, `${profile.access} 10`, profile.exit, profile.finish]);
    assert.deepEqual(trunk, [profile.enter, `interface ${profile.port}`, profile.trunkMode, `${profile.trunk} ${profile.ranges}`, profile.exit, profile.finish]);
    assert.deepEqual(hostname, [profile.enter, `${profile.name} edge-west-01`, profile.finish]);
    for (const command of [...vlan, ...access, ...trunk, ...hostname]) {
      assert.equal(typeof command, 'string');
      assert.doesNotMatch(command, /[\r\n;]/);
      assert.doesNotMatch(command, /\b(?:save|write|lldp|cdp|commit|reload|shutdown)\b/i);
    }
  });

  test(`${vendor}: VLAN boundaries 1 and 4094 and bounded full range are accepted`, () => {
    for (const value of [1, '1', 4094, '4094']) {
      assert.deepEqual(buildTemplate(vendor, 'vlan', { vlan: value }), [profile.enter, `vlan ${value}`, profile.exit, profile.finish]);
      assert.ok(buildTemplate(vendor, 'access', { vlan: value, interface: profile.port }).includes(`${profile.access} ${value}`));
    }
    const fullRange = vendor === 'huawei' || vendor === 'h3c' ? '1 to 4094' : '1-4094';
    assert.ok(buildTemplate(vendor, 'trunk', { vlans: '1-4094', interface: profile.port }).includes(`${profile.trunk} ${fullRange}`));
  });

  test(`${vendor}: VLAN names and hostnames enforce documented length boundaries`, () => {
    assert.ok(buildTemplate(vendor, 'vlan', { vlan: 1, name: 'V'.repeat(32) }).includes(`name ${'V'.repeat(32)}`));
    assert.ok(buildTemplate(vendor, 'hostname', { name: 'h'.repeat(63) }).includes(`${profile.name} ${'h'.repeat(63)}`));
    assert.throws(() => buildTemplate(vendor, 'vlan', { vlan: 1, name: 'V'.repeat(33) }));
    assert.throws(() => buildTemplate(vendor, 'hostname', { name: 'h'.repeat(64) }));
  });

  test(`${vendor}: reject non-integral VLANs, trailing garbage, coercion and injected controls`, () => {
    for (const value of [0, 4095, -1, 1.5, NaN, Infinity, '', ' ', ' 10', '10 ', '10junk', '10.0', '1e2', '0x10', '+10', '1,2', '1\n', '1\r', '1\t', '1\u2028', '1;shutdown', null, undefined, true, [], {}, { toString: () => '10' }, 10n]) {
      assert.throws(() => buildTemplate(vendor, 'vlan', { vlan: value }), `${vendor}: ${String(value)}`);
      assert.throws(() => buildTemplate(vendor, 'access', { vlan: value, interface: profile.port }), `${vendor}: ${String(value)}`);
    }
  });

  test(`${vendor}: reject malformed lists, descending/out-of-range ranges and injected commands`, () => {
    for (const value of ['', ' ', '0', '4095', '1-4095', '0-2', '20-10', '-1', '1-', '1--2', '1,', ',1', '1,,2', '1;reload', '1\n2', '1\r\n2', '1\t,2', '1,2foo', '1.5', '1e2', 'all', 'none', '1 to 3', '1 2', '1-2-3', '1\u20282', '1,'.repeat(129), [1, 2], 1, null, {}]) {
      assert.throws(() => buildTemplate(vendor, 'trunk', { vlans: value, interface: profile.port }), `${vendor}: ${String(value)}`);
    }
  });

  test(`${vendor}: names and interface whitelist prevent CLI injection, ranges and subinterfaces`, () => {
    for (const name of ['', 'bad\nshutdown', 'bad\rreload', 'bad;save', 'bad\0name', 'bad\u001bname', 'bad name', ' bad', 'bad ', 'bad\tname', 'bad\u2028name', 'bad#', 'bad|show', 'bad?', 'bad"', "bad'", '$(reload)', '中文', null, 10, {}]) {
      assert.throws(() => buildTemplate(vendor, 'hostname', { name }));
      assert.throws(() => buildTemplate(vendor, 'vlan', { vlan: 10, name }));
    }
    for (const name of ['-bad', 'bad-', '9host', 'host_name', 'host.name']) {
      assert.throws(() => buildTemplate(vendor, 'hostname', { name }));
    }
    for (const port of ['', 'all', 'range Gi1/0/1-2', 'Gi1/0/1;shutdown', 'Gi1/0/1\nshutdown', 'Gi1/0/1\r', 'Gi1/0/1\t', 'Gi1/0/1\u2028', 'Gi1/0/1.10', 'Gi1/0/1,Gi1/0/2', 'GigabitEthernet1/0/1-2', 'GigabitEthernet1/0/1 extra', 'GigabitEthernet  1/0/1', 'GigabitEthernet65536/1', 'GigabitEthernet1/0/1/1/1', 'Loopback0', 'Vlan10', 'GigabitEthernet' + '1'.repeat(65), null, 1, {}]) {
      assert.throws(() => buildTemplate(vendor, 'access', { vlan: 10, interface: port }), `${vendor}: ${String(port)}`);
      assert.throws(() => buildTemplate(vendor, 'trunk', { vlans: '10', interface: port }), `${vendor}: ${String(port)}`);
    }
  });
}

test('allowlisted physical/aggregate interface spellings are vendor-specific', () => {
  const ports = { huawei: ['10GE1/0/1', 'Eth-Trunk1'], h3c: ['Ten-GigabitEthernet1/0/49', 'Bridge-Aggregation10'], ruijie: ['GigabitEthernet 0/1', 'AggregatePort1'], cisco: ['GigabitEthernet1/0/1', 'Port-channel1', 'TwentyFiveGigE1/0/1'] };
  for (const [vendor, values] of Object.entries(ports)) {
    for (const port of values) assert.ok(buildTemplate(vendor, 'access', { vlan: 1, interface: port }).includes(`interface ${port}`));
  }
  for (const [vendor, port] of [['huawei', 'Eth-Trunk1/2'], ['h3c', 'Bridge-Aggregation0'], ['cisco', 'Port-channel0'], ['ruijie', 'AggregatePort1/2'], ['cisco', 'Eth-Trunk1']]) {
    assert.throws(() => buildTemplate(vendor, 'access', { vlan: 1, interface: port }));
  }
});

test('invalid vendor/template/params fail closed without reading accessors or mutating input', () => {
  assert.throws(() => buildTemplate('unknown', 'vlan', { vlan: 1 }));
  for (const template of ['reboot', '__proto__', 'constructor', '', null, undefined, {}, ['vlan']]) {
    assert.throws(() => buildTemplate('cisco', template, { vlan: 1 }));
  }
  for (const template of [['trunk'], new String('trunk'), { toString: () => 'trunk' }]) {
    assert.throws(() => buildTemplate('cisco', template, { vlans: '10', interface: 'Gi1/0/1' }));
  }
  for (const params of [null, undefined, '', [], 1, true, new Date(), Object.create({ vlan: 10 }), { vlan: 10, extra: 'shutdown' }]) {
    assert.throws(() => buildTemplate('cisco', 'vlan', params));
  }
  for (const template of ['vlan', 'access', 'trunk', 'hostname']) assert.throws(() => buildTemplate('huawei', template, {}));
  assert.throws(() => buildTemplate('cisco', 'vlan', { vlan: 1, name: undefined }));
  let accessed = false;
  const accessor = { get vlan() { accessed = true; return 1; } };
  assert.throws(() => buildTemplate('cisco', 'vlan', accessor));
  assert.equal(accessed, false);
  const params = Object.freeze({ vlans: '20,10-12,11', interface: 'Gi1/0/1' });
  buildTemplate('cisco', 'trunk', params);
  assert.deepEqual(params, { vlans: '20,10-12,11', interface: 'Gi1/0/1' });
});
