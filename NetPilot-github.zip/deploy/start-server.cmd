@echo off
chcp 65001 >nul
title NetPilot 服务器模式
cd /d "%~dp0.."

rem ===== 部署前必须修改 =====
rem 访问口令：至少 12 位，建议 24 位以上随机串。不设置则拒绝对外监听。
set "NETPILOT_ACCESS_TOKEN=请替换成你自己的长口令-至少12位"
rem 监听地址：0.0.0.0 表示所有网卡；只给内网用可写具体网卡 IP。
set "NETPILOT_BIND=0.0.0.0"
set "NETPILOT_PORT=47831"
rem 允许的域名（逗号分隔）。用 nginx 反代时填你的域名；留空表示不限制 Host。
set "NETPILOT_ALLOWED_HOSTS=netpilot.example.com"

if not exist "dist\index.html" (
  echo 缺少 dist，请先执行 npm ci 和 npm run build。
  pause
  exit /b 1
)

echo 正在以服务器模式启动：http://%NETPILOT_BIND%:%NETPILOT_PORT%
echo 访问口令已设置，浏览器首次进入需要输入。
node server\index.mjs
if errorlevel 1 pause
