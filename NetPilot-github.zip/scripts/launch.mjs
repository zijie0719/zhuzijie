import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(dirname(fileURLToPath(import.meta.url)));
const url = `http://127.0.0.1:${process.env.NETPILOT_PORT || 47831}`;
if (!existsSync(join(root, 'node_modules')) || !existsSync(join(root, 'dist/index.html'))) {
  console.error('缺少依赖或网页构建。请在此目录运行 npm ci 和 npm run build 后重试。'); process.exit(1);
}
async function open() { if (process.platform === 'win32') { const p = spawn('explorer.exe', [url], { detached: true, stdio: 'ignore', windowsHide: true }); p.on('error', () => console.log(`请在浏览器打开 ${url}`)); p.unref(); } else console.log(`请在浏览器打开 ${url}`); }
try {
  const res = await fetch(`${url}/api/bootstrap`, { signal: AbortSignal.timeout(1500) });
  const data = await res.json();
  if (!res.ok || data.version !== '1.0.0-local') throw new Error('port occupied');
  console.log(`已有 NetPilot 实例运行中：${url}`); await open();
} catch {
  const child = spawn(process.execPath, ['server/index.mjs'], { cwd: root, stdio: ['inherit', 'pipe', 'inherit'], windowsHide: false });
  let opened = false;
  child.stdout.on('data', data => { process.stdout.write(data); if (!opened && data.toString().includes('NetPilot local server:')) { opened = true; void open(); } });
  child.on('error', error => { console.error(error.message); process.exitCode = 1; });
  child.on('exit', code => { process.exitCode = code || 0; });
  process.on('SIGINT', () => { child.kill('SIGINT'); });
  process.on('SIGTERM', () => { child.kill('SIGTERM'); });
}
