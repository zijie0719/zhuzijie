' ============================================================================
'  NetPilot · SecureCRT 桥接脚本 (VBScript)
'  用法：SecureCRT 目标标签 -> Script -> Run -> 选择本文件 -> 粘贴网页配对码
'  作用：把当前已登录的 SecureCRT 会话借给 NetPilot 网页做只读采集 / 配置下发
'  说明：不读取、不保存任何口令；只转发网页已审核的完整 CLI 行。
' ============================================================================
# $language = "VBScript"
# $interface = "1.0"

Const NETPILOT_PORT = 47831          ' 由后端在生成时替换为实际端口
Const POLL_INTERVAL_MS = 250
Const MAX_CAPTURE_BYTES = 1000000

Dim gToken
Dim gBase
Dim gLogPath
Dim gEndMessage

Sub Main()
    gBase = "http://127.0.0.1:" & NETPILOT_PORT

    If Not crt.Session.Connected Then
        MsgBox "当前标签未连接到设备。请先登录设备并停留在 CLI 提示符。", 16, "NetPilot"
        Exit Sub
    End If

    Dim prompt
    prompt = CurrentPrompt()
    If prompt = "" Then
        MsgBox "未能识别当前提示符。" & vbCrLf & vbCrLf & _
               "请确认已经登录设备，命令行最后一行是 <设备名> 或 设备名# 形式，然后重试。", 16, "NetPilot"
        Exit Sub
    End If

    Dim code
    code = InputBox("请粘贴网页上生成的一次性配对码（10 分钟内有效）：", "NetPilot · 绑定 SecureCRT 会话", "")
    If Trim(code) = "" Then Exit Sub

    Dim sessionName
    sessionName = SessionName()

    Dim body
    body = Trim(code) & vbLf & sessionName & vbLf & prompt

    Dim resp
    resp = HttpPost("/bridge/attach", body, "")
    If resp = "" Then
        MsgBox "无法连接 NetPilot 本机后台。" & vbCrLf & _
               "请确认网页已运行（启动 NetPilot.cmd），端口 " & NETPILOT_PORT & " 正常。", 16, "NetPilot"
        Exit Sub
    End If
    If Len(resp) <> 64 Then
        MsgBox "配对失败：" & vbCrLf & vbCrLf & resp, 16, "NetPilot"
        Exit Sub
    End If
    gToken = resp

    crt.Screen.Synchronous = True
    On Error Resume Next
    crt.Session.Log False
    On Error GoTo 0

    Dim alive
    alive = True
    gEndMessage = ""
    Do While alive
        Dim task
        task = HttpPost("/bridge/poll", "", gToken)
        If task = "" Then
            gEndMessage = "与本机后台的连接已中断，桥接结束。SecureCRT 会话保持打开。"
            Exit Do
        End If

        If task = "WAIT" Then
            crt.Sleep POLL_INTERVAL_MS
        ElseIf Left(task, 1) = "{" Then
            ' 后端返回 JSON 错误（配对失效 / 会话被解绑 / 后台重启）
            gEndMessage = "桥接已结束：" & vbCrLf & vbCrLf & task
            Exit Do
        Else
            alive = HandleTask(task)
        End If
    Loop

    On Error Resume Next
    crt.Session.Log False
    crt.Screen.Synchronous = False
    Err.Clear
    On Error GoTo 0

    If gEndMessage <> "" Then MsgBox gEndMessage, 64, "NetPilot"
End Sub

' ---------------------------------------------------------------------------
' 处理一条任务：taskId / timeout秒 / requireEcho / startPrompt / command
' ---------------------------------------------------------------------------
Function HandleTask(task)
    HandleTask = True

    Dim parts, i, idx
    parts = Split(Replace(task, vbCr, ""), vbLf)
    If UBound(parts) < 4 Then Exit Function

    Dim taskId, timeoutSec, requireEcho, startPrompt, command
    taskId = parts(0)
    timeoutSec = CLng(parts(1))
    requireEcho = (parts(2) = "1")
    startPrompt = parts(3)
    command = parts(4)

    Dim output, status, newPrompt
    status = "ok"

    Dim captured
    captured = SendAndCapture(command, timeoutSec * 1000, requireEcho)

    If captured = "" Then
        status = "timeout"
        output = ""
    Else
        output = captured
        newPrompt = CurrentPrompt()
        If newPrompt = "" Then
            status = "timeout"
        End If
    End If

    If status <> "ok" Then
        HttpPost "/bridge/result", "", gToken, taskId, status, startPrompt
        gEndMessage = "NetPilot：命令未在预期时间内回到提示符，已停止本次任务。" & vbCrLf & vbCrLf & _
                      "执行结果不确定，请在本终端人工核对；网页不会重发该命令。"
        HandleTask = False
        Exit Function
    End If

    HttpPost "/bridge/result", output, gToken, taskId, "ok", newPrompt
    HandleTask = True
End Function

' ---------------------------------------------------------------------------
' 发送单行命令并捕获完整输出（优先用 SecureCRT 会话日志，回退到屏幕缓冲）
' ---------------------------------------------------------------------------
Function SendAndCapture(command, timeoutMs, requireEcho)
    Dim logStart, usedLog
    usedLog = False
    gLogPath = LogFilePath()

    On Error Resume Next
    crt.Session.LogFileName = gLogPath
    crt.Session.Log True
    If Err.Number = 0 Then usedLog = True
    Err.Clear
    On Error GoTo 0

    If Not usedLog Then
        logStart = crt.Screen.CurrentRow
    End If

    ' 清空输入行，避免残留字符被拼接到命令前
    crt.Screen.Send vbCr
    crt.Sleep 60

    Dim started
    started = Timer
    crt.Screen.Send command & vbCr

    ' 先等命令回显出现，再等提示符，避免把上一行旧提示符当成执行完成。
    Dim echoWait
    echoWait = timeoutMs
    If echoWait > 3000 Then echoWait = 3000
    On Error Resume Next
    crt.Screen.WaitForString command, echoWait
    Err.Clear
    On Error GoTo 0

    Dim ok
    ok = WaitForPrompt(timeoutMs, started)

    On Error Resume Next
    If usedLog Then crt.Session.Log False
    Err.Clear
    On Error GoTo 0

    Dim text, fso
    If usedLog Then
        crt.Sleep 150
        text = ReadLogFile(gLogPath)
        On Error Resume Next
        Set fso = CreateObject("Scripting.FileSystemObject")
        If fso.FileExists(gLogPath) Then fso.DeleteFile gLogPath, True
        Err.Clear
        On Error GoTo 0
    End If
    If Trim(text) = "" Then
        text = ScreenSlice(logStart)
    End If

    text = CleanOutput(text)
    If Not ok Then
        SendAndCapture = ""
    Else
        SendAndCapture = text
    End If
End Function

' ---------------------------------------------------------------------------
' 等待提示符重新出现（容忍 system-view 等视图切换导致的提示符变化）
' ---------------------------------------------------------------------------
Function WaitForPrompt(timeoutMs, started)
    Dim deadline, stable, line, guard
    deadline = started + (timeoutMs / 1000)
    stable = 0
    guard = 0
    WaitForPrompt = False

    Do
        crt.Sleep 120
        guard = guard + 1
        If guard > 4000 Then Exit Do

        ' 分页提示：自动翻页，避免输出被 "--More--" 截断
        line = LastNonEmptyLine()
        If InStr(1, line, "More", vbTextCompare) > 0 And InStr(1, line, "--", vbTextCompare) > 0 Then
            crt.Screen.Send " "
            stable = 0
        ElseIf IsPromptLine(line) Then
            stable = stable + 1
            If stable >= 2 Then
                WaitForPrompt = True
                Exit Do
            End If
        Else
            stable = 0
        End If

        If Timer < started Then ' 跨零点
            deadline = deadline - 86400
        End If
    Loop While Timer < deadline

    If Not WaitForPrompt Then
        ' 再给一次机会：直接等 1.5 秒后看最后一行
        crt.Sleep 1500
        WaitForPrompt = IsPromptLine(LastNonEmptyLine())
    End If
End Function

' ---------------------------------------------------------------------------
' 屏幕缓冲回退方案
' ---------------------------------------------------------------------------
Function ScreenSlice(startRow)
    Dim current, endRow
    current = crt.Screen.CurrentRow
    If startRow < 1 Then startRow = 1
    If current - startRow > 200 Then startRow = current - 200
    endRow = current
    On Error Resume Next
    ScreenSlice = crt.Screen.Get(startRow, 1, endRow, crt.Screen.Columns)
    Err.Clear
    On Error GoTo 0
End Function

' ---------------------------------------------------------------------------
' 读取日志文件（兼容 UTF-8 / 本地编码）
' ---------------------------------------------------------------------------
Function ReadLogFile(path)
    Dim stream, text
    text = ""
    On Error Resume Next
    Set stream = CreateObject("ADODB.Stream")
    If Err.Number = 0 Then
        stream.Type = 2
        stream.Charset = "utf-8"
        stream.Open
        stream.LoadFromFile path
        text = stream.ReadText(-1)
        stream.Close
    End If
    If Err.Number <> 0 Then
        Err.Clear
        Dim fso, f
        Set fso = CreateObject("Scripting.FileSystemObject")
        If fso.FileExists(path) Then
            Set f = fso.OpenTextFile(path, 1, False)
            text = f.ReadAll
            f.Close
        End If
    End If
    Err.Clear
    On Error GoTo 0
    ReadLogFile = text
End Function

Function LogFilePath()
    Dim tmp
    tmp = CreateObject("WScript.Shell").ExpandEnvironmentStrings("%TEMP%")
    LogFilePath = tmp & "\netpilot-bridge-" & Replace(CStr(Timer), ".", "") & ".log"
End Function

' ---------------------------------------------------------------------------
' 输出清理：去 ANSI / 退格 / 分页残留
' ---------------------------------------------------------------------------
Function CleanOutput(text)
    Dim re, s
    s = Replace(text, vbCr, "")
    On Error Resume Next
    Set re = New RegExp
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = Chr(27) & "\[[0-9;?]*[A-Za-z]"
    s = re.Replace(s, "")
    re.Pattern = Chr(27) & "\][^" & Chr(7) & Chr(27) & "]*(" & Chr(7) & "|" & Chr(27) & "\\)"
    s = re.Replace(s, "")
    Err.Clear
    On Error GoTo 0

    Dim lines, i, out
    lines = Split(s, vbLf)
    out = ""
    For i = 0 To UBound(lines)
        Dim ln
        ln = RTrim(lines(i))
        If InStr(1, ln, "--More--", vbTextCompare) > 0 Then ln = ""
        If InStr(1, ln, "---- More ----", vbTextCompare) > 0 Then ln = ""
        out = out & ln & vbLf
    Next

    ' 去掉尾部空行（保留最后一行提示符）
    Do While Right(out, 2) = vbLf & vbLf
        out = Left(out, Len(out) - 1)
    Loop
    CleanOutput = Trim(out)
End Function

' ---------------------------------------------------------------------------
' 提示符识别
' ---------------------------------------------------------------------------
Function IsPromptLine(line)
    Dim re
    If line = "" Then IsPromptLine = False : Exit Function
    On Error Resume Next
    Set re = New RegExp
    re.Global = False
    re.Pattern = "^(<[A-Za-z0-9_][A-Za-z0-9_.:/\-]{0,127}>|\[[~*]?[A-Za-z0-9_][A-Za-z0-9_.:/\-]{0,127}\]|[A-Za-z0-9_][A-Za-z0-9_.:/\-]{0,127}(\([A-Za-z0-9_./:\-]{1,128}\))?[#>])$"
    IsPromptLine = re.Test(line)
    Err.Clear
    On Error GoTo 0
End Function

Function LastNonEmptyLine()
    Dim row, line, i
    LastNonEmptyLine = ""
    row = crt.Screen.CurrentRow
    For i = 0 To 60
        On Error Resume Next
        line = crt.Screen.Get(row - i, 1, row - i, crt.Screen.Columns)
        Err.Clear
        On Error GoTo 0
        line = Trim(line)
        If line <> "" Then
            LastNonEmptyLine = line
            Exit Function
        End If
        If row - i <= 1 Then Exit For
    Next
End Function

Function CurrentPrompt()
    Dim line
    line = LastNonEmptyLine()
    If IsPromptLine(line) Then
        CurrentPrompt = line
    Else
        CurrentPrompt = ""
    End If
End Function

Function SessionName()
    Dim p, n
    p = ""
    On Error Resume Next
    p = crt.Session.Path
    If Err.Number <> 0 Then p = ""
    Err.Clear
    On Error GoTo 0

    If p <> "" Then
        n = p
        Dim pos
        pos = InStrRev(n, "\")
        If pos > 0 Then n = Mid(n, pos + 1)
        pos = InStrRev(n, ".")
        If pos > 1 Then n = Left(n, pos - 1)
        SessionName = n
    Else
        SessionName = Trim(crt.Window.Caption)
    End If
    If SessionName = "" Then SessionName = "SecureCRT"
    If Len(SessionName) > 120 Then SessionName = Left(SessionName, 120)
End Function

' ---------------------------------------------------------------------------
' HTTP（同步）
' ---------------------------------------------------------------------------
Function HttpPost(path, body, token, taskId, status, prompt)
    Dim http, url
    url = gBase & path
    HttpPost = ""

    On Error Resume Next
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    If Err.Number <> 0 Then
        Err.Clear
        Set http = CreateObject("MSXML2.XMLHTTP")
    End If
    If Err.Number <> 0 Then
        Err.Clear
        Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    End If
    If Err.Number <> 0 Then Exit Function

    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "text/plain; charset=utf-8"
    If token <> "" Then http.setRequestHeader "x-netpilot-bridge", token
    If taskId <> "" Then
        http.setRequestHeader "x-netpilot-task", taskId
        http.setRequestHeader "x-netpilot-status", status
        http.setRequestHeader "x-netpilot-prompt", prompt
    End If

    http.Send body
    If Err.Number <> 0 Then
        Err.Clear
        Exit Function
    End If

    If http.Status >= 200 And http.Status < 300 Then
        HttpPost = http.responseText
    Else
        HttpPost = http.responseText
        If HttpPost = "" Then HttpPost = "{""status"":" & http.Status & "}"
    End If
    Err.Clear
    On Error GoTo 0
End Function
