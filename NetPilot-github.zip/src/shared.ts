import { toast } from 'sonner';

export type Device = { id: string; name: string; vendor: string; model?: string; version?: string; managementIp?: string; chassisId?: string; kind?: string; path?: string; status: string; discoveredAt?: string; lastSeen?: string; lastDiscoveryAt?: string; autoRefreshError?: string; depth?: number; source?: string; connected?: boolean };
export type Link = { id: string; source: string; target: string; localPort: string; remotePort: string; protocol: string; lastSeen?: string };
export type Job = { id: string; type: string; status: string; message: string; createdAt: string; endedAt?: string; progress: number; total: number; logs: { time: string; message: string; level?: string }[]; backupIds?: string[] };
export type Audit = { id: string; time: string; action: string; detail: string; status: string };
export type Command = { id: string; vendor: string; category: string; title: string; command: string; description: string; mode: string; risk: string; notes: string };
export type Vendor = { id: string; label: string; os: string; color: string };
export type Settings = { ai: { provider: string; baseUrl: string; model: string; hasKey: boolean; timeoutMs: number }; discovery: { username: string; hasPassword: boolean; scope: string; autoRefresh: number; hosts: { host: string; fingerprint: string; vendor: string; port: number }[] }; serial: { path: string; baudRate: number; autoConnect: boolean; vendor: string }; security: { encryption: string; loopbackOnly: boolean } };
export type Snapshot = { devices: Device[]; links: Link[]; jobs: Job[]; audit: Audit[]; settings: Settings; csrfToken: string; version: string; activeTask: string | null; deployment?: { bind: string; loopback: boolean; authRequired: boolean; allowedHosts: string[] } };
export type Plan = { id: string; commands: string[]; perDevice?: { id: string; name: string; vendor: string; commands: string[] }[]; devices: Device[]; expiresAt: string; warnings: string[]; blocked: string[]; backupRequired: boolean };
export const vendorNames: Record<string, string> = { huawei: '华为', h3c: '华三', ruijie: '锐捷', cisco: 'Cisco', unknown: '待识别' };
export const vendorColors: Record<string, string> = { huawei: '#df6263', h3c: '#667cdb', ruijie: '#dc9b36', cisco: '#279eac', unknown: '#8c97a2' };
export const time = (value?: string) => value ? new Date(value).toLocaleTimeString('zh-CN', { hour12: false }) : '—';
let token = '';
export function setToken(value: string) { token = value; }
export async function api<T = any>(path: string, body?: unknown, method?: string): Promise<T> {
  const res = await fetch(`/api${path}`, { method: method || (body === undefined ? 'GET' : 'POST'), headers: { 'Content-Type': 'application/json', 'X-Netpilot-CSRF': token }, body: body === undefined ? undefined : JSON.stringify(body) });
  const data = await res.json().catch(() => ({ error: `后台返回了无法读取的响应（${res.status}）` }));
  if (!res.ok) {
    const error = new Error(data.error || `请求失败（${res.status}）`) as Error & { status?: number; authRequired?: boolean };
    error.status = res.status;
    error.authRequired = Boolean(data.authRequired);
    throw error;
  }
  return data;
}
/** SSE 流式请求：逐段回调文本增量，返回服务商报告的模型名。 */
export async function apiStream(path: string, body: unknown, onChunk: (text: string) => void, signal?: AbortSignal): Promise<{ model: string }> {
  const res = await fetch(`/api${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Netpilot-CSRF': token }, body: JSON.stringify(body), signal });
  if (!res.ok) {
    const data = await res.json().catch(() => ({ error: `请求失败（${res.status}）` }));
    throw new Error(data.error || `请求失败（${res.status}）`);
  }
  const reader = res.body?.getReader();
  if (!reader) throw new Error('当前浏览器不支持流式响应');
  const decoder = new TextDecoder();
  let buffer = '', model = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const frames = buffer.split('\n\n');
    buffer = frames.pop() ?? '';
    for (const frame of frames) {
      const line = frame.split('\n').find(item => item.startsWith('data:'));
      if (!line) continue;
      const payload = line.slice(5).trim();
      if (!payload) continue;
      let event: { t?: string; error?: string; done?: boolean; model?: string };
      try { event = JSON.parse(payload); } catch { continue; }
      if (event.error) throw new Error(event.error);
      if (event.t) onChunk(event.t);
      if (event.done) model = event.model || '';
    }
  }
  return { model };
}
export async function copy(text: string) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      toast.success('已复制到剪贴板');
      return;
    }
  } catch { /* 非安全上下文（如 http://内网IP）走降级方案 */ }
  try {
    const area = document.createElement('textarea');
    area.value = text;
    area.style.position = 'fixed'; area.style.top = '-1000px'; area.style.opacity = '0';
    document.body.appendChild(area);
    area.focus(); area.select();
    const ok = document.execCommand('copy');
    area.remove();
    if (ok) { toast.success('已复制到剪贴板'); return; }
  } catch { /* 继续提示手动复制 */ }
  toast.error('复制失败，请手动选中文本复制');
}
export function download(name: string, data: string, type = 'application/json') {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement('a');
  a.href = url; a.download = name;
  // Safari 需要元素在文档内才会触发下载。
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export const demoDevices: Device[] = [
  { id: 'demo-core', name: 'CORE-SW-01', vendor: 'huawei', model: 'CloudEngine S6730', managementIp: '192.0.2.1', status: 'sample', kind: 'serial', path: '示例 Console', depth: 0, source: '演示数据' },
  { id: 'demo-d1', name: 'DIST-SW-01', vendor: 'h3c', model: 'S5560X', managementIp: '192.0.2.11', status: 'sample', depth: 1, source: '演示数据' },
  { id: 'demo-d2', name: 'DIST-SW-02', vendor: 'cisco', model: 'Catalyst 9300', managementIp: '192.0.2.12', status: 'sample', depth: 1, source: '演示数据' },
  { id: 'demo-a1', name: 'ACCESS-SW-01', vendor: 'ruijie', model: 'RG-S2910', managementIp: '192.0.2.21', status: 'sample', depth: 2, source: '演示数据' },
  { id: 'demo-a2', name: 'ACCESS-SW-02', vendor: 'huawei', model: 'S5735-L', managementIp: '192.0.2.22', status: 'sample', depth: 2, source: '演示数据' },
  { id: 'demo-a3', name: 'ACCESS-SW-03', vendor: 'cisco', model: 'Catalyst 9200', managementIp: '192.0.2.23', status: 'sample', depth: 2, source: '演示数据' },
];
export const demoLinks: Link[] = [
  { id: 'd1', source: 'demo-core', target: 'demo-d1', localPort: '10GE 1/0/1', remotePort: 'Ten-GE 1/0/49', protocol: 'LLDP' },
  { id: 'd2', source: 'demo-core', target: 'demo-d2', localPort: '10GE 1/0/2', remotePort: 'Te 1/1/1', protocol: 'LLDP' },
  { id: 'd3', source: 'demo-d1', target: 'demo-a1', localPort: 'GE 1/0/1', remotePort: 'Gi 0/25', protocol: 'LLDP' },
  { id: 'd4', source: 'demo-d1', target: 'demo-a2', localPort: 'GE 1/0/2', remotePort: 'GE 0/0/24', protocol: 'LLDP' },
  { id: 'd5', source: 'demo-d2', target: 'demo-a3', localPort: 'Gi 1/0/1', remotePort: 'Gi 1/0/24', protocol: 'CDP' },
];
