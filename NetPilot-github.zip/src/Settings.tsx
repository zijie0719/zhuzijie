import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { AlertTriangle, Bot, Copy, Fingerprint, Info, KeyRound, Loader2, Network, Plus, Save, ShieldCheck, Trash2, Usb } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { api, copy, vendorNames } from './shared';
import type { Settings as SettingsData } from './shared';

type Props = { settings: SettingsData; onRefresh: () => Promise<void> };
type Section = 'ai' | 'discovery' | 'serial';
type Provider = 'deepseek' | 'openai' | 'custom';
type TrustedHost = SettingsData['discovery']['hosts'][number];
type AiForm = { provider: Provider; baseUrl: string; model: string; timeoutMs: string; apiKey: string; clearKey: boolean };
type HostForm = { host: string; port: string; vendor: string; fingerprint: string; verified: boolean };

const emptyHost = (): HostForm => ({ host: '', port: '22', vendor: 'auto', fingerprint: '', verified: false });
const AI_PRESETS: { label: string; provider: Provider; baseUrl: string; model: string }[] = [
  { label: 'DeepSeek', provider: 'deepseek', baseUrl: 'https://api.deepseek.com', model: 'deepseek-chat' },
  { label: 'DeepSeek R1', provider: 'deepseek', baseUrl: 'https://api.deepseek.com', model: 'deepseek-reasoner' },
  { label: 'OpenAI', provider: 'openai', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
  { label: 'Kimi', provider: 'custom', baseUrl: 'https://api.moonshot.cn/v1', model: 'kimi-latest' },
  { label: '通义千问', provider: 'custom', baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', model: 'qwen-plus' },
  { label: '智谱 GLM', provider: 'custom', baseUrl: 'https://open.bigmodel.cn/api/paas/v4', model: 'glm-4-plus' },
  { label: 'Ollama 本地', provider: 'custom', baseUrl: 'http://127.0.0.1:11434/v1', model: 'qwen2.5' },
];
const aiFormFrom = (value: SettingsData['ai']): AiForm => ({
  provider: value.provider === 'deepseek' || value.provider === 'openai' ? value.provider : 'custom',
  baseUrl: value.baseUrl, model: value.model, timeoutMs: String(value.timeoutMs || 60000), apiKey: '', clearKey: false,
});
const discoveryFormFrom = (value: SettingsData['discovery']) => ({
  username: value.username, scope: value.scope, autoRefresh: String(value.autoRefresh ?? 0), hosts: value.hosts.map(host => ({ ...host })), password: '', clearPassword: false,
});
const serialFormFrom = (value: SettingsData['serial']) => ({
  path: value.path, baudRate: String(value.baudRate || 9600), vendor: value.vendor || 'auto', autoConnect: value.autoConnect ?? false,
});

function parseBaseUrl(value: string) {
  let url: URL;
  try { url = new URL(value.trim()); } catch { throw new Error('请输入完整的 AI 服务 Base URL。'); }
  const local = url.hostname === 'localhost' || url.hostname === '[::1]' || /^127(?:\.\d{1,3}){3}$/.test(url.hostname);
  if (url.protocol !== 'https:' && !(local && url.protocol === 'http:')) throw new Error('远端 AI 服务必须使用 HTTPS；仅本机环回地址允许 HTTP。');
  if (url.username || url.password || url.search || url.hash) throw new Error('Base URL 不能包含账号、密码、查询参数或片段；密钥请单独填写。');
  const baseUrl = url.href.replace(/\/+$/, '');
  if (/\/chat\/completions$/i.test(baseUrl)) throw new Error('请填写 Base URL，不要包含末尾的 /chat/completions。');
  return { baseUrl, local, endpoint: `${baseUrl}/chat/completions` };
}

function ipVersion(value: string): 0 | 4 | 6 {
  if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(value) && value.split('.').every(part => Number(part) <= 255 && (part === '0' || !part.startsWith('0')))) return 4;
  if (value.includes(':') && /^[0-9a-f:.]+$/i.test(value)) {
    try { if (new URL(`http://[${value}]/`).hostname.startsWith('[')) return 6; } catch { /* Not an IPv6 literal. */ }
  }
  return 0;
}

function normalizeScope(value: string) {
  const scopes = value.split(/[,，\n]+/).map(item => item.trim()).filter(Boolean);
  for (const scope of scopes) {
    const [address, prefix, extra] = scope.split('/');
    const version = ipVersion(address);
    const b = address.split('.').map(Number);
    const privateIp = b[0] === 10 || (b[0] === 172 && b[1] >= 16 && b[1] <= 31) || (b[0] === 192 && b[1] === 168);
    if (version !== 4 || !privateIp || extra !== undefined || !/^\d+$/.test(prefix || '') || Number(prefix) < 8 || Number(prefix) > 32) {
      throw new Error('递归范围只支持私有 IPv4 CIDR，例如 192.168.0.0/16；不递归时留空。');
    }
  }
  return [...new Set(scopes)].join(',');
}

function hostAddress(form: HostForm) {
  const host = form.host.trim().replace(/^\[([^\]]+)\]$/, '$1');
  const port = Number(form.port);
  const b = host.split('.').map(Number);
  if (ipVersion(host) !== 4 || !(b[0] === 10 || (b[0] === 172 && b[1] >= 16 && b[1] <= 31) || (b[0] === 192 && b[1] === 168))) throw new Error('请输入私有 IPv4 管理地址，而不是公网、网段或 URL。');
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('SSH 端口必须是 1–65535 的整数。');
  return { host: ipVersion(host) === 6 ? new URL(`http://[${host}]/`).hostname.slice(1, -1) : host, port };
}

class RequestTimeout extends Error {}

function useRequests() {
  const alive = useRef(true);
  const timers = useRef(new Set<ReturnType<typeof setTimeout>>());
  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; timers.current.forEach(clearTimeout); timers.current.clear(); };
  }, []);
  function waitFor<T,>(request: Promise<T>, timeoutMs: number): Promise<T> {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { timers.current.delete(timer); reject(new RequestTimeout()); }, timeoutMs);
      timers.current.add(timer);
      request.then(resolve, reject).finally(() => { clearTimeout(timer); timers.current.delete(timer); });
    });
  }
  return { alive, waitFor };
}

function VendorOptions() {
  return <><option value="auto">自动识别</option>{Object.entries(vendorNames).filter(([value]) => value !== 'unknown').map(([value, label]) => <option key={value} value={value}>{label}</option>)}</>;
}

export default function Settings({ settings, onRefresh }: Props) {
  const [ai, setAi] = useState(() => aiFormFrom(settings.ai));
  const [discovery, setDiscovery] = useState(() => discoveryFormFrom(settings.discovery));
  const [serial, setSerial] = useState(() => serialFormFrom(settings.serial));
  const [saving, setSaving] = useState<Section | null>(null);
  const savingRef = useRef(false);
  const dirty = useRef({ ai: false, discovery: false, serial: false });
  const { alive, waitFor } = useRequests();
  const [needsRefresh, setNeedsRefresh] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [testOpen, setTestOpen] = useState(false);
  const [testing, setTesting] = useState(false);
  const testingRef = useRef(false);
  const [testResult, setTestResult] = useState<{ model: string; reply: string } | null>(null);
  const [testError, setTestError] = useState('');
  const [hostOpen, setHostOpen] = useState(false);
  const [hostForm, setHostForm] = useState<HostForm>(emptyHost);
  const [probing, setProbing] = useState(false);
  const probeSequence = useRef(0);
  const probingRef = useRef(false);
  const [hostError, setHostError] = useState('');

  // Snapshot refreshes must not erase an operator's unsaved edits or secrets.
  useEffect(() => { if (!needsRefresh && !dirty.current.ai && !savingRef.current) setAi(aiFormFrom(settings.ai)); }, [settings.ai, saving, refreshing, needsRefresh]);
  useEffect(() => { if (!needsRefresh && !dirty.current.discovery && !savingRef.current) setDiscovery(discoveryFormFrom(settings.discovery)); }, [settings.discovery, saving, refreshing, needsRefresh]);
  useEffect(() => { if (!needsRefresh && !dirty.current.serial && !savingRef.current) setSerial(serialFormFrom(settings.serial)); }, [settings.serial, saving, refreshing, needsRefresh]);

  const updateAi = (patch: Partial<AiForm>) => { dirty.current.ai = true; setAi(current => ({ ...current, ...patch })); };
  const updateDiscovery = (patch: Partial<typeof discovery>) => { dirty.current.discovery = true; setDiscovery(current => ({ ...current, ...patch })); };
  const updateSerial = (patch: Partial<typeof serial>) => { dirty.current.serial = true; setSerial(current => ({ ...current, ...patch })); };
  const busy = saving !== null || refreshing;
  let endpoint = '';
  try { endpoint = parseBaseUrl(ai.baseUrl).endpoint; } catch { /* Invalid input is explained on save. */ }
  let savedAiReady = false;
  let savedService = '';
  try {
    const saved = parseBaseUrl(settings.ai.baseUrl);
    savedAiReady = !!settings.ai.model.trim() && (saved.local || settings.ai.hasKey);
    savedService = saved.baseUrl;
  } catch { /* The test action stays unavailable for invalid saved settings. */ }

  async function refreshSaved() {
    if (savingRef.current) return;
    savingRef.current = true;
    setRefreshing(true);
    try {
      await onRefresh();
      if (alive.current) { setNeedsRefresh(false); toast.success('已刷新后台配置'); }
    } catch { if (alive.current) toast.error('无法刷新后台配置，请检查本机后台后重试。'); }
    finally { savingRef.current = false; if (alive.current) setRefreshing(false); }
  }

  async function save(section: Section, data: object) {
    if (savingRef.current || (section === 'ai' && testingRef.current)) return;
    savingRef.current = true;
    setSaving(section);
    if (section === 'ai') { setTestResult(null); setTestError(''); }
    try {
      await waitFor(api('/settings', { [section]: data }, 'PUT'), 30000);
      if (!alive.current) return;
      dirty.current[section] = false;
      if (section === 'ai') setAi(current => ({ ...current, apiKey: '', clearKey: false }));
      if (section === 'discovery') setDiscovery(current => ({ ...current, password: '', clearPassword: false }));
      try {
        await onRefresh();
        if (alive.current) { setNeedsRefresh(false); toast.success('本板块配置已保存'); }
      } catch {
        if (alive.current) { setNeedsRefresh(true); toast.warning('配置已保存，但状态刷新失败。请刷新后台配置，不必重复保存。'); }
      }
    } catch (error) {
      if (alive.current) {
        setNeedsRefresh(true);
        toast.error(error instanceof RequestTimeout ? '保存等待超时，结果未确认。请先刷新后台配置再决定是否重试。' : '保存失败，未确认变更生效。请检查输入与本机后台；凭据不会显示在错误信息中。');
      }
    } finally { savingRef.current = false; if (alive.current) setSaving(null); }
  }

  function saveAi(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      const { baseUrl } = parseBaseUrl(ai.baseUrl);
      const timeoutMs = Number(ai.timeoutMs);
      if (!ai.model.trim()) throw new Error('请填写服务提供方支持的模型名称。');
      if (!Number.isInteger(timeoutMs) || timeoutMs < 5000 || timeoutMs > 180000) throw new Error('超时应为 5000–180000 毫秒的整数。');
      void save('ai', {
        provider: ai.provider, baseUrl, model: ai.model.trim(), timeoutMs,
        ...(ai.clearKey ? { clearKey: true } : ai.apiKey ? { apiKey: ai.apiKey } : {}),
      });
    } catch (error) { toast.error(error instanceof Error ? error.message : '请检查 AI 配置。'); }
  }

  function saveDiscovery(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      const scope = normalizeScope(discovery.scope);
      if (scope && !discovery.username.trim()) throw new Error('启用 SSH 递归发现前请填写登录用户名。');
      void save('discovery', {
        scope, autoRefresh: Number(discovery.autoRefresh), username: discovery.username.trim(), hosts: discovery.hosts.map(({ host, port, fingerprint, vendor }) => ({ host, port, fingerprint, vendor })),
        ...(discovery.clearPassword ? { clearPassword: true } : discovery.password ? { password: discovery.password } : {}),
      });
    } catch (error) { toast.error(error instanceof Error ? error.message : '请检查 SSH 配置。'); }
  }

  function saveSerial(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const baudRate = Number(serial.baudRate);
    if (!Number.isInteger(baudRate) || baudRate < 1) { toast.error('波特率必须是正整数。'); return; }
    if (serial.autoConnect && !serial.path.trim()) { toast.error('请先填写要自动连接的 Console 端口。'); return; }
    void save('serial', { path: serial.path.trim(), baudRate, vendor: serial.vendor, autoConnect: serial.autoConnect });
  }

  async function testAi() {
    if (testingRef.current || savingRef.current || !savedAiReady || needsRefresh) return;
    testingRef.current = true;
    setTestOpen(false);
    setTesting(true);
    setTestResult(null);
    setTestError('');
    try {
      const timeout = Number.isFinite(settings.ai.timeoutMs) && settings.ai.timeoutMs > 0 ? settings.ai.timeoutMs : 60000;
      const result = await waitFor(api<{ model: string; reply: string }>('/ai/test', { consent: true }), Math.min(timeout, 600000) + 10000);
      if (!result || typeof result.model !== 'string' || typeof result.reply !== 'string' || !result.reply.trim()) throw new Error('Invalid response');
      if (alive.current) { setTestResult(result); toast.success('AI 服务已返回测试响应'); }
    } catch (error) {
      if (alive.current) {
        const message = error instanceof RequestTimeout || (error instanceof Error && /timeout|timed out|超时/i.test(error.message))
          ? '测试等待超时，后台请求可能仍在处理并产生费用；不会自动重试。'
          : '测试失败，未获得有效回复。请检查已保存的地址、模型、密钥及服务连通性。';
        setTestError(message);
        toast.error(message);
      }
    } finally { testingRef.current = false; if (alive.current) setTesting(false); }
  }

  function changeHostDialog(open: boolean) {
    probeSequence.current += 1;
    probingRef.current = false;
    setProbing(false);
    setHostError('');
    setHostForm(emptyHost());
    setHostOpen(open);
  }

  async function probeHost() {
    if (probingRef.current) return;
    let address: { host: string; port: number };
    try { address = hostAddress(hostForm); }
    catch (error) { setHostError(error instanceof Error ? error.message : '请检查设备地址。'); return; }
    const sequence = ++probeSequence.current;
    probingRef.current = true;
    setProbing(true);
    setHostError('');
    setHostForm(current => ({ ...current, fingerprint: '', verified: false }));
    try {
      const result = await waitFor(api<{ fingerprint: string }>('/ssh/probe', address), 25000);
      if (!result || typeof result.fingerprint !== 'string' || !result.fingerprint.trim()) throw new Error('Invalid fingerprint');
      if (alive.current && sequence === probeSequence.current) {
        setHostForm(current => ({ ...current, fingerprint: result.fingerprint.trim(), verified: false }));
        toast.info('已读取公钥指纹，尚未信任。请先通过 Console 等带外渠道核对。');
      }
    } catch (error) {
      if (alive.current && sequence === probeSequence.current) setHostError(error instanceof RequestTimeout ? '读取指纹超时，未添加任何信任项；可检查地址或手动填写。' : '无法读取公钥指纹，请检查设备地址、端口及网络，或手动填写。');
    } finally {
      if (alive.current && sequence === probeSequence.current) { probingRef.current = false; setProbing(false); }
    }
  }

  function addHost(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (probingRef.current || savingRef.current) return;
    try {
      const address = hostAddress(hostForm);
      const fingerprint = hostForm.fingerprint.trim();
      if (!/^SHA256:[A-Za-z0-9+/]{43}$/.test(fingerprint)) throw new Error('请填写 SHA256: 开头、无尾部等号的完整主机指纹。');
      if (!hostForm.verified) throw new Error('必须先通过带外渠道核对 IP、端口与指纹，再确认信任。');
      if (discovery.hosts.some(host => host.host.toLowerCase() === address.host.toLowerCase() && host.port === address.port)) throw new Error('该 IP 和端口已在白名单中；更换指纹请先移除旧条目。');
      const entry: TrustedHost = { ...address, fingerprint, vendor: hostForm.vendor };
      updateDiscovery({ hosts: [...discovery.hosts, entry] });
      changeHostDialog(false);
      toast.info('已加入待保存白名单；点击“保存 SSH 设置”后生效。');
    } catch (error) { setHostError(error instanceof Error ? error.message : '无法添加该主机。'); }
  }

  return <>
    {needsRefresh && <div className="notice" role="status"><AlertTriangle size={16} /><div>页面状态可能与后台不一致。刷新后再测试 AI；未保存的表单会保留。<br /><button className="btn btn-sm" type="button" onClick={() => void refreshSaved()} disabled={busy}>{refreshing && <Loader2 size={13} className="spinner" />}刷新后台配置</button></div></div>}
    <div className="settings-grid">
      <div>
        <section className="panel" aria-labelledby="ai-settings-title">
          <div className="panel-heading"><div><span className="overline">AI CONNECTION</span><h2 id="ai-settings-title">AI 服务配置</h2></div><Bot size={21} /></div>
          <form className="panel-body" onSubmit={saveAi}>
            <fieldset disabled={busy || testing} style={{ border: 0, padding: 0, margin: 0, minWidth: 0 }}>
              <div className="preset-row"><span className="tiny-label">快速填充</span>{AI_PRESETS.map(preset => <button type="button" key={preset.label} className="btn btn-sm" onClick={() => updateAi({ provider: preset.provider, baseUrl: preset.baseUrl, model: preset.model })}>{preset.label}</button>)}</div>
              <div className="form-grid">
                <label className="form-field"><span>服务提供方</span><select value={ai.provider} onChange={event => {
                  const provider = event.target.value as Provider;
                  updateAi({ provider, baseUrl: provider === 'deepseek' ? 'https://api.deepseek.com' : provider === 'openai' ? 'https://api.openai.com/v1' : '', model: provider === 'deepseek' ? 'deepseek-flash' : '' });
                }}><option value="deepseek">DeepSeek</option><option value="openai">OpenAI</option><option value="custom">自定义 / 本机兼容服务</option></select></label>
                <label className="form-field"><span>模型名称</span><input required value={ai.model} onChange={event => updateAi({ model: event.target.value })} placeholder={ai.provider === 'deepseek' ? 'deepseek-chat' : '填写服务支持的模型 ID'} spellCheck={false} /><small>模型可编辑；OpenAI 与自定义服务请自行填写。</small></label>
                <label className="form-field wide"><span>Base URL</span><input required type="url" value={ai.baseUrl} onChange={event => updateAi({ baseUrl: event.target.value })} placeholder="https://api.deepseek.com" autoComplete="off" spellCheck={false} /><small>自动在末尾追加 /chat/completions。远端强制 HTTPS；本机可用 http://127.0.0.1:11434/v1（Ollama）。</small>{endpoint && <small style={{ overflowWrap: 'anywhere' }}>请求地址：<code>{endpoint}</code></small>}</label>
                <label className="form-field wide"><span>API 密钥 <span className={`pill ${settings.ai.hasKey ? '' : 'neutral'}`}>{settings.ai.hasKey ? '已保存 · 不回显' : '未保存'}</span></span><input type="password" value={ai.apiKey} disabled={ai.clearKey} onChange={event => updateAi({ apiKey: event.target.value })} placeholder={settings.ai.hasKey ? '留空保留已保存密钥' : '远端服务填写密钥；本机服务可留空'} autoComplete="new-password" spellCheck={false} autoCapitalize="none" /><small>保存成功后清空输入；不写入浏览器持久化存储。更换服务地址时必须填写新密钥或明确删除旧密钥，避免向新服务泄露凭据。</small></label>
                <label className="form-field"><span>请求超时（毫秒）</span><input required type="number" min={5000} max={180000} step={1} value={ai.timeoutMs} onChange={event => updateAi({ timeoutMs: event.target.value })} /><small>5000–180000 毫秒。</small></label>
              </div>
              <label className="check-inline" style={{ marginBottom: 18 }}><input type="checkbox" checked={ai.clearKey} onChange={event => updateAi({ clearKey: event.target.checked, apiKey: '' })} />保存时明确删除已保存的 API 密钥</label>
              <div className="notice info"><KeyRound size={16} /><span>API 密钥由本机 Node 后台使用 Windows DPAPI 按当前 Windows 用户加密。NetPilot 网站仅应通过 127.0.0.1 访问。</span></div>
              <div className="button-row" style={{ flexWrap: 'wrap' }}>
                <button className="btn btn-primary" type="submit">{saving === 'ai' ? <Loader2 className="spinner" size={15} /> : <Save size={15} />}保存 AI 配置</button>
                <button className="btn" type="button" disabled={!savedAiReady || needsRefresh} onClick={() => setTestOpen(true)}>{testing ? <Loader2 className="spinner" size={15} /> : <Bot size={15} />}测试已保存配置</button>
              </div>
            </fieldset>
            <p className="muted" style={{ marginTop: 12 }}>保存不会发起 AI 请求。测试只使用后台已保存参数，不使用当前未保存的输入；远端需已保存密钥，本机服务可无密钥。</p>
            {testing && <p className="muted" role="status" style={{ marginTop: 12 }}>正在等待真实服务响应，请勿重复测试……</p>}
            {testError && <div className="error-box" role="alert">{testError}</div>}
            {testResult && <div className="notice info" role="status" style={{ marginTop: 16, marginBottom: 0 }}><Bot size={16} /><div style={{ minWidth: 0 }}><strong>测试响应 · {testResult.model}</strong><p style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', marginTop: 5 }}>{testResult.reply}</p></div></div>}
          </form>
        </section>

        <section className="panel" aria-labelledby="ssh-settings-title">
          <div className="panel-heading"><div><span className="overline">TRUSTED DISCOVERY</span><h2 id="ssh-settings-title">SSH 递归发现</h2></div><Network size={21} /></div>
          <form className="panel-body" onSubmit={saveDiscovery}>
            <fieldset disabled={busy} style={{ border: 0, padding: 0, margin: 0, minWidth: 0 }}>
              <div className="notice"><ShieldCheck size={16} /><span>只对发现的邻居中<strong>已列入白名单、指纹匹配且 IP 位于 CIDR 范围内</strong>的设备自动登录。不扫描网段；范围留空即不递归。</span></div>
              <label className="form-field"><span>拓扑自动刷新</span><select value={discovery.autoRefresh} onChange={event => updateDiscovery({ autoRefresh: event.target.value })}><option value="0">关闭（仅手动发现）</option><option value="60">每 60 秒</option><option value="120">每 2 分钟</option><option value="300">每 5 分钟</option><option value="900">每 15 分钟</option><option value="1800">每 30 分钟</option><option value="3600">每 60 分钟</option></select><small>只对已连接设备刷新直接邻居，全程只读；只有新增设备或链路时才写审计。</small></label><label className="form-field"><span>允许递归的 CIDR 范围</span><textarea rows={2} value={discovery.scope} onChange={event => updateDiscovery({ scope: event.target.value })} placeholder="192.168.0.0/16,10.20.0.0/16" spellCheck={false} /><small>多个范围用逗号分隔；留空不会发起 SSH 递归发现。</small></label>
              <div className="form-grid">
                <label className="form-field"><span>SSH 用户名</span><input value={discovery.username} onChange={event => updateDiscovery({ username: event.target.value })} placeholder="只读发现账号" autoComplete="off" spellCheck={false} /><small>建议使用最小权限、只读账号。</small></label>
                <label className="form-field"><span>SSH 密码 · {settings.discovery.hasPassword ? '已保存' : '未保存'}</span><input type="password" value={discovery.password} disabled={discovery.clearPassword} onChange={event => updateDiscovery({ password: event.target.value })} placeholder="留空不修改" autoComplete="new-password" spellCheck={false} /><small>成功保存后清空，不回显或写入前端日志。</small></label>
              </div>
              <label className="check-inline" style={{ marginBottom: 20 }}><input type="checkbox" checked={discovery.clearPassword} onChange={event => updateDiscovery({ clearPassword: event.target.checked, password: '' })} />保存时明确删除已保存的 SSH 密码</label>
              <div className="button-row" style={{ justifyContent: 'space-between', flexWrap: 'wrap', marginBottom: 15 }}><h3 style={{ fontSize: 13 }}>主机指纹白名单 <span className="tiny-label">{discovery.hosts.length} 台</span></h3><button className="btn btn-sm" type="button" onClick={() => changeHostDialog(true)}><Plus size={14} />添加可信主机</button></div>
              {!discovery.hosts.length && <div className="notice info"><Fingerprint size={16} /><span>尚无可信主机。先读取或填写指纹，经带外核对后添加；不会默认信任任何设备。</span></div>}
              {discovery.hosts.map((host, index) => <div className="host-entry" key={`${host.host}:${host.port}`}>
                <header style={{ alignItems: 'center', gap: 8 }}><div style={{ minWidth: 0, overflowWrap: 'anywhere' }}><strong>{host.host.includes(':') ? `[${host.host}]` : host.host}:{host.port}</strong><p className="muted">{vendorNames[host.vendor] || host.vendor}</p></div><div className="button-row"><button type="button" className="icon-btn" title="复制指纹" aria-label={`复制 ${host.host} 的指纹`} onClick={() => void copy(host.fingerprint)}><Copy size={14} /></button><button type="button" className="icon-btn" title="从待保存白名单移除" aria-label={`移除 ${host.host}`} onClick={() => updateDiscovery({ hosts: discovery.hosts.filter((_, position) => position !== index) })}><Trash2 size={14} /></button></div></header>
                <code>{host.fingerprint}</code>
              </div>)}
              <p className="muted" style={{ marginBottom: 16 }}>添加和移除仅修改本页草稿，保存后生效。指纹变化时请重新带外核对，切勿直接接受新指纹。</p>
              <button className="btn btn-primary" type="submit">{saving === 'discovery' ? <Loader2 className="spinner" size={15} /> : <Save size={15} />}保存 SSH 设置</button>
            </fieldset>
          </form>
        </section>
      </div>

      <div>
        <section className="panel" aria-labelledby="serial-settings-title">
          <div className="panel-heading"><div><span className="overline">DEVICE CONSOLE</span><h2 id="serial-settings-title">Console 自动重连</h2></div><Usb size={21} /></div>
          <form className="panel-body" onSubmit={saveSerial}>
            <fieldset disabled={busy} style={{ border: 0, padding: 0, margin: 0, minWidth: 0 }}>
              <label className="form-field"><span>串口路径</span><input value={serial.path} onChange={event => updateSerial({ path: event.target.value })} placeholder="COM3 或 /dev/ttyUSB0" spellCheck={false} autoComplete="off" /><small>Windows 填 COM3，Linux 填 /dev/ttyUSB0；只匹配这个端口，不自动连接其他串口。</small></label>
              <div className="form-grid">
                <label className="form-field"><span>波特率</span><input required type="number" min={1} step={1} list="netpilot-baud-rates" value={serial.baudRate} onChange={event => updateSerial({ baudRate: event.target.value })} /><datalist id="netpilot-baud-rates">{[9600, 19200, 38400, 57600, 115200].map(rate => <option key={rate} value={rate} />)}</datalist></label>
                <label className="form-field"><span>设备厂商</span><select value={serial.vendor} onChange={event => updateSerial({ vendor: event.target.value })}><VendorOptions /></select></label>
              </div>
              <label className="check-inline" style={{ alignItems: 'flex-start', lineHeight: 1.8, marginBottom: 18 }}><input type="checkbox" style={{ marginTop: 3 }} checked={serial.autoConnect} onChange={event => updateSerial({ autoConnect: event.target.checked })} />我主动启用：配置的 Console 端口出现时自动尝试连接</label>
              <div className="notice"><Info size={16} /><span>默认关闭。启用后，仅在配置的端口出现时尝试一次，并进行只读发现；不会循环登录、批量探测其他串口或自动执行配置命令。保存本身不等于连接成功。</span></div>
              <button className="btn btn-primary" type="submit">{saving === 'serial' ? <Loader2 className="spinner" size={15} /> : <Save size={15} />}保存 Console 设置</button>
            </fieldset>
          </form>
        </section>

        <section className="panel" aria-labelledby="security-title">
          <div className="panel-heading"><div><span className="overline">LOCAL FIRST</span><h2 id="security-title">安全与隐私</h2></div><span className="pill neutral">只读</span></div>
          <div className="panel-body">
            <div className="security-item"><ShieldCheck size={22} /><div><b>{settings.security.loopbackOnly ? '网站仅监听本机环回地址' : '环回监听保护未确认'}</b><p>NetPilot 网站仅应开放在 127.0.0.1，不应暴露到局域网或公网。</p></div></div>
            <div className="security-item"><KeyRound size={22} /><div><b>Windows DPAPI · 当前用户加密</b><p>API 密钥由后台加密保存，页面只接收是否配置的状态。后台报告：{settings.security.encryption || '未报告'}。</p></div></div>
            <div className="security-item"><Fingerprint size={22} /><div><b>指纹校验先于登录</b><p>读取 SSH 公钥不代表可信，必须通过设备 Console、资产台账等带外渠道核对。</p></div></div>
            <div className="security-item"><Bot size={22} /><div><b>AI 请求需明确授权</b><p>测试与聊天会访问配置的模型服务，可能产生费用。真实拓扑上下文默认不发送；AI 建议只能转成草稿，不能直接执行。</p></div></div>
            {!settings.security.loopbackOnly && <div className="notice danger" role="alert" style={{ marginTop: 16, marginBottom: 0 }}><AlertTriangle size={16} /><span>后台未报告仅环回监听。请检查后台启动配置，不要对外开放网站。</span></div>}
          </div>
        </section>
      </div>
    </div>

    <Dialog open={testOpen} onOpenChange={setTestOpen}>
      <DialogContent className="modal-content">
        <DialogHeader><DialogTitle>允许发送一条 AI 测试请求？</DialogTitle><DialogDescription>将使用后台已保存配置发送 1 条测试请求，模型服务会接收测试内容，可能产生费用。当前表单的未保存修改不会用于本次测试。</DialogDescription></DialogHeader>
        <div className="notice info" style={{ marginBottom: 0 }}><Bot size={17} /><div style={{ overflowWrap: 'anywhere' }}>已保存服务：{savedService || '尚未配置'}<br />已保存模型：{settings.ai.model || '尚未填写'}<br />不会附带真实拓扑上下文。</div></div>
        <DialogFooter><button className="btn" type="button" onClick={() => setTestOpen(false)}>取消</button><button className="btn btn-primary" type="button" disabled={testing || busy || !savedAiReady || needsRefresh} onClick={() => void testAi()}>同意并测试已保存配置</button></DialogFooter>
      </DialogContent>
    </Dialog>

    <Dialog open={hostOpen} onOpenChange={changeHostDialog}>
      <DialogContent className="modal-content">
        <DialogHeader><DialogTitle>添加可信 SSH 主机</DialogTitle><DialogDescription>读取公钥只进行 SSH 握手，不登录、不发送用户名或密码。读取结果不可直接视为可信，必须带外核对。</DialogDescription></DialogHeader>
        <form onSubmit={addHost}>
          <fieldset disabled={probing || busy} style={{ border: 0, margin: 0, padding: 0, minWidth: 0 }}>
            <div className="form-grid">
              <label className="form-field"><span>设备 IP</span><input required value={hostForm.host} onChange={event => setHostForm(current => ({ ...current, host: event.target.value, fingerprint: '', verified: false }))} placeholder="192.168.1.10" autoComplete="off" spellCheck={false} /></label>
              <label className="form-field"><span>SSH 端口</span><input required type="number" min={1} max={65535} step={1} value={hostForm.port} onChange={event => setHostForm(current => ({ ...current, port: event.target.value, fingerprint: '', verified: false }))} /></label>
              <label className="form-field wide"><span>设备厂商</span><select value={hostForm.vendor} onChange={event => setHostForm(current => ({ ...current, vendor: event.target.value, verified: false }))}><VendorOptions /></select></label>
            </div>
            <button className="btn btn-sm" type="button" onClick={() => void probeHost()} style={{ marginBottom: 16 }}><Fingerprint size={15} />只读取公钥指纹（不登录）</button>
            <label className="form-field"><span>主机公钥指纹</span><input required value={hostForm.fingerprint} onChange={event => setHostForm(current => ({ ...current, fingerprint: event.target.value, verified: false }))} placeholder="SHA256:…（可手动填写）" spellCheck={false} autoComplete="off" /><small>请将完整指纹与设备 Console 或可信资产记录逐字核对。更改 IP、端口或指纹后需重新确认。</small></label>
            <label className="check-inline" style={{ alignItems: 'flex-start', lineHeight: 1.8, marginBottom: 18 }}><input type="checkbox" style={{ marginTop: 3 }} disabled={!hostForm.fingerprint.trim()} checked={hostForm.verified} onChange={event => setHostForm(current => ({ ...current, verified: event.target.checked }))} />我已通过带外渠道核对该 IP、端口和完整指纹，确认将其加入信任白名单</label>
          </fieldset>
          {probing && <p className="muted" role="status" style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}><Loader2 className="spinner" size={14} />正在读取公钥，尚未信任……</p>}
          {hostError && <div className="error-box" role="alert">{hostError}</div>}
          <DialogFooter><button className="btn" type="button" onClick={() => changeHostDialog(false)}>取消</button><button className="btn btn-primary" type="submit" disabled={!hostForm.verified || probing || busy}><Plus size={15} />确认添加到待保存白名单</button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  </>;
}
