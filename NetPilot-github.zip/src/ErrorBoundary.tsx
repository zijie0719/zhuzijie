import { Component } from 'react';
import type { ErrorInfo, ReactNode } from 'react';

type Props = { children: ReactNode };
type State = { error: Error | null };

// 兜底：前端渲染异常不应该把整个工作台变成白屏，后台与设备会话仍在运行。
export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };
  static getDerivedStateFromError(error: Error): State { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error('[NetPilot] 界面异常', error, info.componentStack); }
  render() {
    if (!this.state.error) return this.props.children;
    return <div className="login-shell">
      <div className="panel login-card">
        <h1>界面出现异常</h1>
        <p className="muted">本机后台可能仍在运行，已连接设备不会因此断开。先刷新页面；若反复出现，请记录下面的信息与操作步骤。</p>
        <pre className="terminal" style={{ maxHeight: 220, overflow: 'auto', fontSize: 11 }}>{String(this.state.error.stack || this.state.error.message || this.state.error).slice(0, 1500)}</pre>
        <button className="btn btn-primary" type="button" onClick={() => location.reload()}>刷新页面</button>
      </div>
    </div>;
  }
}
