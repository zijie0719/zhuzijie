import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { ArrowUp, Bot, Copy, FileCode2, Play, RefreshCw, Settings2, Sparkles, Square, Trash2, User, Wand2 } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { api, apiStream, copy, vendorNames } from './shared';
import type { Device, Settings } from './shared';

type Props = { settings?: Settings; devices: Device[]; demo: boolean; online?: boolean; compact?: boolean; onSettings: () => void; onDraft: (commands: string, deviceId?: string) => void };
type Message = {
  id: number;
  role: 'user' | 'assistant';
  content: string;
  status: 'pending' | 'sent' | 'failed';
  model?: string;
  includedContext?: boolean;
};
type Block = { kind: 'text'; content: string } | { kind: 'code'; content: string; language: string };

const PROVIDERS: Record<string, string> = { deepseek: 'DeepSeek', openai: 'OpenAI', custom: '自定义接口' };

// 快捷指令直接发起请求，不再只是往输入框里塞一段话。
const genericActions = [
  { title: '排查跨 VLAN 不通', prompt: '终端能 ping 通网关但跨 VLAN 不通。按风险从低到高给我一份只读排查顺序，每条命令说明看什么字段、什么现象对应什么原因。' },
  { title: '解释一段配置', prompt: '我接下来会贴一段交换机配置。请先告诉我需要确认哪些信息（厂商、型号、版本），然后逐条解释每行命令的作用与风险。' },
  { title: '写变更草稿', prompt: '我要给一台接入交换机新增业务 VLAN 并划分接入口。请先列出必须确认的参数，再给出完整可审核的命令草稿。' },
];
const deviceActions = [
  { title: '生成巡检命令', prompt: '按当前目标设备的厂商和型号，给出一组只读巡检命令：版本、接口状态、CPU/内存、日志、LLDP 邻居。用代码块输出，不要包含配置变更。' },
  { title: '端口频繁 up/down', prompt: '目标设备上某个接入口频繁 up/down 并伴随错包。给出只读排查顺序和每条命令的判断标准，不要直接生成 shutdown 之类操作。' },
  { title: '读取并备份配置', prompt: '给出读取当前运行配置的命令，并列出备份文件里需要脱敏的字段。' },
  { title: '生成 VLAN 变更', prompt: '我要在目标设备上新增一个业务 VLAN 并把接入口划进去。请先问清必要参数，再给完整命令（含进入/退出视图），不要自己编造端口号。' },
];

function connectionState(ai: Settings['ai']) {
  try {
    const url = new URL(ai.baseUrl.trim());
    const local = url.hostname === 'localhost' || url.hostname === '[::1]' || /^127(?:\.\d{1,3}){3}$/.test(url.hostname);
    if ((url.protocol !== 'https:' && !(local && url.protocol === 'http:')) || url.username || url.password || url.search || url.hash) {
      return { ready: false, local, reason: 'Base URL 无效：远端必须 HTTPS，本机才允许 HTTP。' };
    }
    if (!ai.model.trim()) return { ready: false, local, reason: '未填写模型名称。' };
    if (!local && !ai.hasKey) return { ready: false, local, reason: '远端服务还没有保存 API Key。' };
    return { ready: true, local, reason: '' };
  } catch { return { ready: false, local: false, reason: '还没有可用的模型配置。' }; }
}

function splitBlocks(content: string): Block[] {
  const text = content.replace(/\r\n/g, '\n');
  const blocks: Block[] = [];
  const fences = /```([^\n`]*)\n([\s\S]*?)(?:```|$)/g;
  let cursor = 0;
  for (const match of text.matchAll(fences)) {
    const index = match.index ?? 0;
    if (index > cursor) blocks.push({ kind: 'text', content: text.slice(cursor, index) });
    blocks.push({ kind: 'code', language: match[1].trim().slice(0, 40) || 'CLI', content: match[2].replace(/\n$/, '') });
    cursor = index + match[0].length;
  }
  if (cursor < text.length) blocks.push({ kind: 'text', content: text.slice(cursor) });
  return blocks;
}

function readonlyBlock(content: string) {
  const lines = content.replace(/\r\n/g, '\n').split('\n').map(line => line.trim()).filter(Boolean);
  return lines.length > 0 && lines.every(line => /^(?:display|show|ping|tracert|traceroute)\s+\S/i.test(line));
}

function MessageContent({ content, onDraft, onRun, running }: { content: string; onDraft: (commands: string) => void; onRun: (commands: string, title: string) => void; running: boolean }) {
  return <>{splitBlocks(content).map((block, index) => block.kind === 'text'
    ? <div className="message-text" key={index}>{block.content}</div>
    : <div className="ai-code" key={index}>
      <pre tabIndex={0} aria-label={`${block.language} 代码块`}><code>{block.content}</code></pre>
      <div className="ai-code-actions">
        <button type="button" className="btn btn-sm" disabled={!block.content.trim()} onClick={() => void copy(block.content)}><Copy size={12} />复制</button>
        {readonlyBlock(block.content) && <button type="button" className="btn btn-sm" disabled={!block.content.trim() || running} onClick={() => onRun(block.content, 'AI 生成的只读命令')}><Play size={12} />{running ? '查询中…' : '只读直查'}</button>}
        <button type="button" className="btn btn-sm" disabled={!block.content.trim()} onClick={() => onDraft(block.content)}><FileCode2 size={12} />送入编排</button>
      </div>
    </div>
  )}</>;
}

export default function Assistant({ settings, devices, demo, online = true, compact = false, onSettings, onDraft }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [consent, setConsent] = useState(false);
  const [includeContext, setIncludeContext] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [targetId, setTargetId] = useState('');
  const [query, setQuery] = useState<{ title: string; output: string; busy: boolean; consent: boolean } | null>(null);
  const alive = useRef(true);
  const pendingRef = useRef(false);
  const requestSequence = useRef(0);
  const nextMessageId = useRef(0);
  const abortRef = useRef<AbortController | null>(null);
  const stoppedRef = useRef(false);
  const lastRequest = useRef('');
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const ai = settings?.ai;
  const connection = online && ai ? connectionState(ai) : { ready: false, local: false, reason: '本机后台未连接。' };
  const providerLabel = PROVIDERS[ai?.provider || 'custom'] || ai?.provider || '未配置';
  const connectedDevices = online ? devices.filter(device => device.connected && !device.id.startsWith('demo-') && device.status !== 'sample') : [];
  const selectedTarget = connectedDevices.find(device => device.id === targetId);
  const contextEnabled = includeContext && !demo && online;
  const actions = selectedTarget ? deviceActions : genericActions;

  useEffect(() => { if (targetId && !selectedTarget) setTargetId(''); }, [targetId, selectedTarget]);
  useEffect(() => { setConsent(false); setIncludeContext(false); }, [ai?.provider, ai?.baseUrl, ai?.model, ai?.hasKey, demo, online]);
  useEffect(() => { const el = scrollRef.current; if (el) el.scrollTop = el.scrollHeight; }, [messages, pending, error]);
  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; requestSequence.current += 1; abortRef.current?.abort(); };
  }, []);

  async function sendMessage(event?: FormEvent<HTMLFormElement>, override?: string, autoConsent = false) {
    event?.preventDefault();
    if (pendingRef.current) return;
    if (!online || !settings) { toast.info('本机后台未连接。'); return; }
    if (!connection.ready) { onSettings(); return; }
    const content = (override ?? input).trim();
    if (!content) return;
    lastRequest.current = content;
    if (!override && !autoConsent && !consent) { toast.info('先勾选发送授权，或直接点上面的快捷指令。'); return; }

    pendingRef.current = true;
    stoppedRef.current = false;
    const sequence = ++requestSequence.current;
    const userId = ++nextMessageId.current;
    const answerId = ++nextMessageId.current;
    const history = messages.filter(message => message.status === 'sent').map(({ role, content: text }) => ({ role, content: text }));
    const isCurrent = () => alive.current && sequence === requestSequence.current;
    setMessages(current => [...current,
      { id: userId, role: 'user', content, status: 'pending', includedContext: contextEnabled },
      { id: answerId, role: 'assistant', content: '', status: 'pending' }]);
    if (!override) setInput('');
    setError('');
    setPending(true);
    setConsent(false);

    const controller = new AbortController();
    abortRef.current = controller;
    const configuredTimeout = Number.isFinite(settings.ai.timeoutMs) && settings.ai.timeoutMs > 0 ? settings.ai.timeoutMs : 60000;
    const watchdog = setTimeout(() => controller.abort(), Math.min(configuredTimeout, 600000) + 20000);

    try {
      const result = await apiStream('/ai/chat/stream', {
        messages: [...history, { role: 'user', content }],
        includeContext: !demo && contextEnabled,
        target: selectedTarget ? { vendor: selectedTarget.vendor, model: selectedTarget.model || '', version: selectedTarget.version || '', kind: selectedTarget.kind || '' } : null,
        consent: true,
      }, text => {
        if (!isCurrent()) return;
        setMessages(current => current.map(item => item.id === answerId ? { ...item, content: item.content + text } : item));
      }, controller.signal);
      if (!isCurrent()) return;
      setMessages(current => current.map(item => item.id === userId ? { ...item, status: 'sent' as const } : item.id === answerId ? { ...item, status: 'sent' as const, model: result.model || '模型未回报名称' } : item));
    } catch (failure) {
      if (!isCurrent()) return;
      const stopped = stoppedRef.current;
      const aborted = controller.signal.aborted;
      setMessages(current => current.map(item => item.id === userId || item.id === answerId ? { ...item, status: 'failed' as const } : item));
      setError(stopped ? '已停止生成。' : aborted ? '等待响应超时，已中止。服务商可能仍在计费。' : (failure as Error).message);
      if (!override) setInput(content);
    } finally {
      clearTimeout(watchdog);
      if (isCurrent()) { pendingRef.current = false; abortRef.current = null; setPending(false); }
    }
  }

  function quickAsk(prompt: string) {
    if (pendingRef.current) return;
    // 用户点了具体指令按钮，本身就是明确的发送动作。
    void sendMessage(undefined, prompt, true);
  }
  function stopGenerating() { stoppedRef.current = true; abortRef.current?.abort(); }
  function retry() {
    if (pendingRef.current) return;
    // 快捷指令失败时输入框是空的，重试必须带上一次真正发送的内容。
    const content = lastRequest.current || input;
    if (content) void sendMessage(undefined, content, true);
  }
  function clearConversation() {
    if (pendingRef.current) return;
    requestSequence.current += 1;
    setMessages([]); setInput(''); setError(''); setConsent(false); setIncludeContext(false);
  }

  async function runReadonly(commands: string, title: string) {
    if (!selectedTarget) { toast.info('先在上方选择目标设备。'); return; }
    const lines = commands.replace(/\r\n/g, '\n').split('\n').map(line => line.trim()).filter(Boolean);
    if (!lines.length) return;
    setQuery({ title, output: '', busy: true, consent: false });
    let text = '';
    for (const line of lines) {
      text += `${text ? '\n' : ''}> ${line}\n`;
      setQuery(current => current ? { ...current, output: text } : current);
      try {
        const result = await api<{ output: string }>('/terminal', { deviceId: selectedTarget.id, command: line });
        text += `${result.output || '(无输出)'}\n`;
      } catch (failure) { text += `[错误] ${(failure as Error).message}\n`; }
      setQuery(current => current ? { ...current, output: text } : current);
    }
    setQuery(current => current ? { ...current, busy: false } : current);
  }

  function interpretOutput() {
    if (!query || query.busy || !query.output.trim() || !query.consent) return;
    if (!connection.ready) { onSettings(); return; }
    const dump = query.output.slice(0, 12000);
    setQuery(null);
    void sendMessage(undefined, `下面是目标设备只读命令的真实回显。逐段解读：异常字段、可能原因、下一步只读排查命令。不要生成配置变更。\n\n\`\`\`\n${dump}\n\`\`\``, true);
  }

  return <div className={`assistant-ui${compact ? ' assistant-compact' : ''}`}>
    <section className="panel chat-panel" aria-labelledby="assistant-chat-title">
      <div className="panel-heading">
        <div className="ai-heading">
          <h2 id="assistant-chat-title">AI 运维助手</h2>
          <span className={`ai-model-chip${connection.ready ? '' : ' off'}`}><i />{connection.ready ? `${providerLabel} · ${ai?.model}` : '未配置模型'}</span>
        </div>
        <div className="button-row">
          <button className="icon-btn" type="button" title="模型与密钥设置" aria-label="模型与密钥设置" onClick={onSettings}><Settings2 size={15} /></button>
          <button className="icon-btn" type="button" title="清空会话" aria-label="清空会话" disabled={pending || !messages.length} onClick={clearConversation}><Trash2 size={15} /></button>
        </div>
      </div>

      <div className="ai-context-bar">
        <select aria-label="目标设备" value={selectedTarget?.id || ''} onChange={event => setTargetId(event.target.value)}>
          <option value="">不指定设备</option>
          {connectedDevices.map(device => <option key={device.id} value={device.id}>{device.name} · {vendorNames[device.vendor] || device.vendor}</option>)}
        </select>
        <label className="ai-context-toggle" title="附带设备名/IP 给模型；默认只发厂商型号">
          <input type="checkbox" checked={contextEnabled} disabled={demo || pending || !online} onChange={event => setIncludeContext(event.target.checked)} />带拓扑
        </label>
      </div>
      {!connection.ready && <button type="button" className="ai-setup-hint" onClick={onSettings}><Wand2 size={13} />{connection.reason} 去配置</button>}

      <div className="chat-scroll" ref={scrollRef} role="log" aria-label="会话消息" aria-live="polite">
        {!messages.length && <div className="ai-quick">
          {actions.map(action => <button key={action.title} type="button" disabled={pending} onClick={() => quickAsk(action.prompt)}>{action.title}</button>)}
          <p className="ai-quick-note">点指令直接提问；也可以自己输入。生成的命令只是草稿，执行前仍可核对。</p>
        </div>}

        {messages.map(message => <article className={`chat-message ${message.role}`} key={message.id}>
          <span aria-hidden="true">{message.role === 'user' ? <User size={14} /> : <Bot size={15} />}</span>
          <div>
            <h4>{message.role === 'user' ? '你' : message.model || 'AI'}{message.status === 'pending' ? ' · 生成中' : message.status === 'failed' ? ' · 未完成' : ''}{message.role === 'user' && message.includedContext ? ' · 带拓扑' : ''}</h4>
            <MessageContent content={message.content} onDraft={commands => onDraft(commands, selectedTarget?.id)} onRun={runReadonly} running={!!query?.busy} />
            {message.role === 'assistant' && message.status === 'pending' && <p className="message-text muted">{message.content ? '▍' : '正在请求模型…'}</p>}
          </div>
        </article>)}
        {error && <div className="error-box" role="alert"><p>{error}</p><button type="button" className="btn btn-sm" disabled={pending} onClick={retry}><RefreshCw size={12} />重试</button></div>}
      </div>

      <form className="chat-input" onSubmit={event => void sendMessage(event)}>
        <div className="chat-input-box">
          <textarea ref={inputRef} aria-label="输入问题" rows={3} value={input} disabled={pending} onChange={event => setInput(event.target.value)}
            placeholder={connection.ready ? '问点什么，例如：display cpu-usage 持续 90% 怎么排查' : '先在设置里配置模型，或先写下问题'}
            onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing && event.nativeEvent.keyCode !== 229) { event.preventDefault(); void sendMessage(); } }} />
          {pending
            ? <button className="btn" type="button" onClick={stopGenerating} aria-label="停止生成" title="停止生成"><Square size={16} /></button>
            : <button className="btn btn-primary" type="submit" disabled={!input.trim()} aria-label="发送" title={consent ? '发送' : '勾选下方授权后发送'}><ArrowUp size={17} /></button>}
        </div>
        <label className="ai-consent"><input type="checkbox" checked={consent} disabled={pending} onChange={event => setConsent(event.target.checked)} />
          <span>同意发送给 {providerLabel}{messages.some(m => m.status === 'sent') ? '（含对话历史）' : ''}{selectedTarget ? '，含目标厂商/型号' : ''}{contextEnabled ? '，含拓扑' : ''}</span>
        </label>
      </form>
    </section>

    <Dialog open={!!query} onOpenChange={open => { if (!open) setQuery(null); }}>
      <DialogContent className="modal-content sm:max-w-3xl">
        <DialogHeader><DialogTitle>只读查询 · {selectedTarget?.name || '未选择设备'}</DialogTitle><DialogDescription>逐行经设备会话执行，服务端只放行只读白名单命令。</DialogDescription></DialogHeader>
        <pre className="terminal">{query?.output || '准备中…'}{query?.busy ? '\n…' : ''}</pre>
        <label className="check-inline"><input type="checkbox" checked={!!query?.consent} disabled={!query || query.busy} onChange={event => setQuery(current => current ? { ...current, consent: event.target.checked } : current)} /><span>允许把这份回显发给 {providerLabel} 解读</span></label>
        <div className="button-row"><button type="button" className="btn" onClick={() => setQuery(null)}>关闭</button>{query && !query.busy && <button type="button" className="btn btn-sm" onClick={() => void copy(query.output)}><Copy size={13} />复制结果</button>}<button type="button" className="btn btn-primary btn-sm" disabled={!query || query.busy || !query.consent || !connection.ready} onClick={interpretOutput}><Sparkles size={13} />让 AI 解读</button></div>
      </DialogContent>
    </Dialog>
  </div>;
}
