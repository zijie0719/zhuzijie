import { useState } from 'react';
import type { FormEvent } from 'react';
import { KeyRound, Loader2, Network, ShieldCheck } from 'lucide-react';
import { api } from './shared';

export default function Login({ info, onSuccess }: { info: { bind?: string } | null; onSuccess: () => void }) {
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || !token.trim()) return;
    setBusy(true); setError('');
    try {
      await api('/login', { token: token.trim() });
      setToken('');
      onSuccess();
    } catch (failure) {
      setError((failure as Error).message);
    } finally { setBusy(false); }
  }

  return <div className="login-shell">
    <form className="panel login-card" onSubmit={submit}>
      <div className="login-brand"><span className="brand-mark"><Network size={24} /></span><div><b>NetPilot</b><small>NETWORK OPERATIONS</small></div></div>
      <h1>需要访问口令</h1>
      <p className="muted">这套工作台对外开放了监听地址，进入前必须验证口令。口令由部署者通过 NETPILOT_ACCESS_TOKEN 设置，不会回显。</p>
      <label className="form-field"><span>访问口令</span><input type="password" autoFocus autoComplete="current-password" value={token} onChange={event => setToken(event.target.value)} placeholder="输入部署时设置的口令" /></label>
      {error && <div className="error-box" role="alert">{error}</div>}
      <button className="btn btn-primary" type="submit" disabled={busy || !token.trim()}>{busy ? <Loader2 className="spinner" size={15} /> : <KeyRound size={15} />}{busy ? '验证中…' : '进入工作台'}</button>
      <div className="login-foot"><ShieldCheck size={13} /><span>登录状态 12 小时有效 · Cookie 仅 HttpOnly + SameSite=Strict{info?.bind ? ` · 监听 ${info.bind}` : ''}</span></div>
    </form>
  </div>;
}
