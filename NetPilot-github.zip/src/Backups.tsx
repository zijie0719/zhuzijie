import { useEffect, useMemo, useState } from 'react';
import { Archive, Download, Loader2, RefreshCw, Search, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { api, download, time, vendorNames } from './shared';

type Entry = { id: string; deviceId: string; deviceName: string; vendor: string; time: string; bytes: number };
type Payload = { backups: Entry[]; encryption: string };

const size = (bytes: number) => bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : bytes >= 1024 ? `${(bytes / 1024).toFixed(1)} KB` : `${bytes} B`;

export default function Backups() {
  const [data, setData] = useState<Payload | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [busyId, setBusyId] = useState('');

  async function refresh() {
    setLoading(true); setError('');
    try { setData(await api<Payload>('/backups')); }
    catch (failure) { setError((failure as Error).message); }
    finally { setLoading(false); }
  }
  useEffect(() => { void refresh(); }, []);

  const rows = useMemo(() => (data?.backups || []).filter(item => `${item.deviceName} ${item.vendor} ${item.id}`.toLowerCase().includes(query.toLowerCase())), [data, query]);

  async function save(entry: Entry) {
    if (busyId) return;
    setBusyId(entry.id);
    try {
      const response = await fetch(`/api/backups/${entry.id}`);
      if (!response.ok) throw new Error('备份读取失败，可能已被保留策略清理');
      const text = await response.text();
      download(`netpilot-backup-${entry.deviceName || 'device'}-${entry.id.slice(0, 8)}.txt`, text, 'text/plain');
      toast.info('已导出明文配置，请妥善保管其中的设备敏感信息');
    } catch (failure) { toast.error((failure as Error).message); }
    finally { setBusyId(''); }
  }

  return <section className="panel">
    <div className="panel-heading">
      <div><span className="overline">CONFIG BACKUPS</span><h2>配置备份</h2></div>
      <button className="btn btn-sm" onClick={() => void refresh()} disabled={loading}>{loading ? <Loader2 className="spinner" size={14} /> : <RefreshCw size={14} />}刷新</button>
    </div>
    <div className="toolbar">
      <label className="search-wrap"><Search size={15} /><input aria-label="搜索备份" value={query} onChange={event => setQuery(event.target.value)} placeholder="按设备名或 ID 搜索" /></label>
      <span className="muted">{rows.length} / {data?.backups.length || 0} 份 · 最多保留 120 份</span>
    </div>
    {error && <div className="error-box" role="alert">{error}</div>}
    <div className="table-wrap">
      <table>
        <thead><tr><th>设备</th><th>厂商</th><th>备份时间</th><th>大小</th><th>操作</th></tr></thead>
        <tbody>
          {rows.map(entry => <tr key={entry.id}>
            <td><b>{entry.deviceName || '未知设备'}</b><small>{entry.id.slice(0, 8)}</small></td>
            <td>{vendorNames[entry.vendor] || entry.vendor || '—'}</td>
            <td className="mono">{new Date(entry.time).toLocaleString('zh-CN', { hour12: false })}</td>
            <td className="mono">{size(entry.bytes)}</td>
            <td><button className="text-link" disabled={busyId === entry.id} onClick={() => void save(entry)}>{busyId === entry.id ? <Loader2 className="spinner" size={13} /> : <Download size={13} />}导出明文</button></td>
          </tr>)}
        </tbody>
      </table>
      {!rows.length && !loading && <div className="empty-small"><Archive size={28} /><p>{data?.backups.length ? '没有匹配的备份。' : '还没有配置备份。执行含写操作的配置任务前，系统会先自动备份。'}</p></div>}
    </div>
    <div className="panel-foot"><span><ShieldCheck size={13} />加密方式：{data?.encryption || '读取中…'}</span><span>最近一份：{data?.backups[0] ? time(data.backups[0].time) : '—'}</span></div>
  </section>;
}
