import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { Archive, ArrowRight, BookOpen, Cable, ChevronRight, CircleHelp, FileClock, Home, Info, Layers, Loader2, Network, Plus, Settings as SettingsIcon, ShieldCheck, Sparkles, Wand2, Workflow } from 'lucide-react';
import { Toaster, toast } from 'sonner';
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import Topology from './Topology';
import { ConnectDialog, TerminalDialog } from './Connections';
import { AuditPage, Automation, Commands, Devices } from './Operations';
import Wizard from './Wizard';
import Backups from './Backups';
import Login from './Login';
import { api, demoDevices, demoLinks, setToken, time, type Device, type Snapshot } from './shared';
const Settings = lazy(() => import('./Settings'));
const Assistant = lazy(() => import('./Assistant'));
type Page = 'topology' | 'devices' | 'automation' | 'wizard' | 'commands' | 'assistant' | 'audit' | 'backups' | 'settings';
const pages: { id: Page; title: string; subtitle: string; icon: typeof Network }[] = [
  { id: 'topology', title: '网络拓扑', subtitle: '先用 SecureCRT 连接 Console / SSH，再在同一标签运行桥接，读取真实网络。', icon: Network },
  { id: 'devices', title: '设备管理', subtitle: '统一查看多厂商设备、管理地址和本机会话。', icon: Layers },
  { id: 'automation', title: '自动化编排', subtitle: '一次编排，按序执行。每一步都有检查和记录。', icon: Workflow },
  { id: 'wizard', title: '配置向导', subtitle: '选场景、填参数，按厂商语法生成配置草稿，再走预检下发。', icon: Wand2 },
  { id: 'commands', title: '命令速查', subtitle: '华为、华三、锐捷、Cisco 常用 CLI，随查随用。', icon: BookOpen },
  { id: 'assistant', title: 'AI 网络助手', subtitle: '用自然语言诊断问题、解释命令和编写配置草稿。', icon: Sparkles },
  { id: 'backups', title: '配置备份', subtitle: '执行写配置前自动留存的设备配置快照，加密存放在本机。', icon: Archive },
  { id: 'audit', title: '操作审计', subtitle: '真实采集、配置任务与模型请求，全程有据可查。', icon: FileClock },
  { id: 'settings', title: '系统设置', subtitle: '在本机管理模型 API、发现范围和自动连接策略。', icon: SettingsIcon },
];
function pageFromHash(): Page { const value = location.hash.replace('#', '') as Page; return pages.some(p => p.id === value) ? value : 'topology'; }
export default function App() {
  const [page, setPage] = useState<Page>(() => { const initial = pageFromHash(); return initial === 'assistant' ? 'topology' : initial; });
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null), [online, setOnline] = useState(false), [connectOpen, setConnectOpen] = useState(false), [prefill, setPrefill] = useState<Device | undefined>(), [terminal, setTerminal] = useState<Device | null>(null), [help, setHelp] = useState(false), [discoverOpen, setDiscoverOpen] = useState(false);
  const [auth, setAuth] = useState<{ required: boolean; bind?: string } | null>(null);
  const [demo, setDemoState] = useState(() => localStorage.getItem('netpilot-mode') !== 'live'), [draft, setDraft] = useState(''), [target, setTarget] = useState(''), [recursive, setRecursive] = useState(false), [root, setRoot] = useState(''), [depth, setDepth] = useState(3), [discoverySubmitting, setDiscoverySubmitting] = useState(false);
  const [assistantOpen, setAssistantOpen] = useState(true), [draftRevision, setDraftRevision] = useState(0);
  const assistantToggleRef = useRef<HTMLButtonElement>(null);
  const refresh = useCallback(async () => { try { const result = await api<Snapshot>('/bootstrap'); setToken(result.csrfToken); setSnapshot(result); setOnline(true); setAuth(null); } catch (error) { setOnline(false); if ((error as { status?: number }).status === 401) { const info = await api<{ bind?: string }>('/session').catch(() => null); setAuth({ required: true, bind: info?.bind }); } } }, []);
  useEffect(() => { void refresh(); if (auth?.required) return; const timer = setInterval(refresh, 30000); const events = new EventSource('/api/events'); let pending: ReturnType<typeof setTimeout> | undefined; events.onmessage = () => { if (!pending) pending = setTimeout(() => { pending = undefined; void refresh(); }, 250); }; events.onerror = () => {}; return () => { clearInterval(timer); if (pending) clearTimeout(pending); events.close(); }; }, [refresh, auth?.required]);
  useEffect(() => {
    const onHash = () => { const next = pageFromHash(); if (next === 'assistant') setAssistantOpen(true); else setPage(next); };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  useEffect(() => {
    if (target && (!online || !snapshot?.devices.some(d => d.id === target && d.connected && !d.id.startsWith('demo-') && d.status !== 'sample'))) setTarget('');
  }, [target, online, snapshot?.devices]);
  function navigate(p: Page) { if (p === 'assistant') setAssistantOpen(true); else setPage(p); location.hash = p; }
  function collapseAssistant() { setAssistantOpen(false); assistantToggleRef.current?.focus(); }
  function setDemo(v: boolean) { setDemoState(v); localStorage.setItem('netpilot-mode', v ? 'demo' : 'live'); }
  function connect(d?: Device) { setPrefill(d); setConnectOpen(true); }
  function createDraft(value: string, deviceId?: string) {
    const chosen = online ? snapshot?.devices.find(d => d.id === deviceId && d.connected && !d.id.startsWith('demo-') && d.status !== 'sample') : undefined;
    setDraft(value);
    setDraftRevision(revision => revision + 1);
    // An unspecified or disconnected target must never inherit an earlier device selection.
    setTarget(chosen?.id || '');
    navigate('automation');
    toast.info(chosen ? `已送入配置草稿，目标：${chosen.name}。尚未执行，请预检并人工确认。` : '已送入配置草稿，未选择设备、未执行。请明确选择真实设备后预检。');
  }
  function automate(d: Device) { if (d.id.startsWith('demo-') || d.status === 'sample') { toast.info('演示设备不能执行配置。请先连接真实设备。'); return; } if (!online || !d.connected) { toast.info('请先在 SecureCRT 连接设备并运行桥接。'); return; } setTarget(d.id); navigate('automation'); }
  function openDiscovery() { const connected = snapshot?.devices.filter(d => d.connected) || []; if (demo) { toast.info('自动发现需要真实设备，请先用 SecureCRT 连接并运行桥接。'); connect(); return; } if (!connected.length) { connect(); return; } setRoot(connected[0].id); setDiscoverOpen(true); }
  const current = pages.find(p => p.id === page)!;
  const devices = demo ? demoDevices : snapshot?.devices || [], links = demo ? demoLinks : snapshot?.links || [];
  const busy = Boolean(snapshot?.activeTask), connectedCount = online ? snapshot?.devices.filter(d => d.connected).length || 0 : 0;
  if (auth?.required) return <Login info={auth.bind ? { bind: auth.bind } : null} onSuccess={() => { setAuth(null); void refresh(); }} />;
  return <SidebarProvider style={{ '--sidebar-width': '218px' } as React.CSSProperties} className="app-layout">
    <Sidebar className="app-sidebar">
      <SidebarHeader style={{ padding: 0 }}><a href="#topology" className="sidebar-brand" onClick={() => navigate('topology')}><span className="brand-mark"><Network size={23} /></span><span className="brand-name">NetPilot<small>NETWORK OPERATIONS</small></span></a></SidebarHeader>
      <SidebarContent><div className="nav-buttons"><p className="nav-section">工作空间</p>{pages.slice(0, 6).map(p => <button key={p.id} className={`nav-button ${(p.id === 'assistant' ? assistantOpen : page === p.id) ? 'active' : ''}`} aria-expanded={p.id === 'assistant' ? assistantOpen : undefined} aria-controls={p.id === 'assistant' ? 'persistent-assistant' : undefined} onClick={() => navigate(p.id)}><p.icon size={17} /><span>{p.title}</span>{p.id === 'assistant' && <span className="nav-new">AI</span>}</button>)}<p className="nav-section" style={{ marginTop: 13 }}>管理中心</p>{pages.slice(6).map(p => <button key={p.id} className={`nav-button ${page === p.id ? 'active' : ''}`} onClick={() => navigate(p.id)}><p.icon size={17} /><span>{p.title}</span></button>)}</div></SidebarContent>
      <SidebarFooter className="sidebar-bottom"><div className="local-card"><b><ShieldCheck size={14} />本机安全工作空间</b><p>连接与配置数据留在本机<br />AI 仅在你明确同意后调用</p></div><div className="sidebar-version"><span>LOCAL EDITION</span><span>v1.0.0</span></div></SidebarFooter>
    </Sidebar>
    <div className="workspace">
      <header className="topbar">
        <div className="breadcrumb"><SidebarTrigger className="md:hidden" /><Home size={14} /><span>工作空间</span><ChevronRight size={12} /><strong>{current.title}</strong></div>
        <div className="topbar-right"><span className="connection-status"><i className={`status-dot ${online ? '' : 'red-dot'}`} />{online ? `本机服务运行中${connectedCount ? ` · ${connectedCount} 台连接` : ''}` : '本机服务未连接'}</span><span className="top-divider" /><button ref={assistantToggleRef} className={`btn btn-sm assistant-toggle ${assistantOpen ? 'is-open' : ''}`} aria-label="切换 AI 助手面板" aria-expanded={assistantOpen} aria-controls="persistent-assistant" onClick={() => setAssistantOpen(open => !open)}><Sparkles size={15} /><span>AI 助手</span></button><button className="icon-btn" aria-label="使用说明" onClick={() => setHelp(true)}><CircleHelp size={17} /></button>{snapshot?.deployment?.authRequired && <button className="text-link" onClick={async () => { try { await api('/logout', {}); } catch { /* 会话可能已失效 */ } location.reload(); }}>退出登录</button>}<span className="top-date">{snapshot?.deployment && !snapshot.deployment.loopback ? '服务器模式' : '本地工作空间'}</span><span className="avatar" title="仅当前 Windows 用户">LOCAL</span></div>
      </header>
      <div className={`workspace-body${assistantOpen ? ' with-assistant' : ''}`}>
        <div className="main-region"><main className="main-content">
          <div className="page-heading"><div><h1>{current.title}</h1><p>{current.subtitle}</p></div><div className="button-row">{['topology', 'devices'].includes(page) && <div className="mode-switch"><button className={!demo ? 'active' : ''} onClick={() => setDemo(false)}>真实网络</button><button className={demo ? 'active' : ''} onClick={() => setDemo(true)}>演示拓扑</button></div>}<button className="btn btn-primary" disabled={!online || busy} onClick={() => connect()}><Plus size={16} />连接设备</button></div></div>
          {!online && <div className="notice danger"><Info size={15} /><span>本机后台未连接。请运行项目中的“启动 NetPilot.cmd”。页面不会将演示数据当作真实连接结果。</span><button className="text-link" onClick={refresh}>重新检查</button></div>}
          {demo && ['topology', 'devices'].includes(page) && <div className="notice"><Info size={14} /><span><strong>正在浏览演示拓扑</strong> · 设备、IP 和链路均为示例，不代表已连接网络。在 SecureCRT 连接 Console / SSH 并运行桥接后，可切换真实发现。</span><button className="text-link" onClick={() => setDemo(false)}>切换真实网络<ArrowRight size={12} /></button></div>}
          {page === 'topology' && <>
            <Topology devices={devices} links={links} demo={demo} busy={busy} autoRefresh={snapshot?.settings.discovery.autoRefresh || 0} onConnect={() => connect()} onDiscover={openDiscovery} onTerminal={setTerminal} onAutomate={automate} />
            <div className="bottom-grid"><section className="panel"><div className="panel-heading"><h2>最近活动</h2><button className="text-link" onClick={() => navigate('audit')}>全部记录<ArrowRight size={12} /></button></div>{snapshot?.audit.length ? snapshot.audit.slice(0, 3).map(a => <div className="activity-row" key={a.id}><span className={`status-dot ${a.status === 'failed' ? 'red-dot' : ''}`} /><div><p>{a.action}</p><small>{a.detail.slice(0, 65)}</small></div><time>{time(a.time)}</time></div>) : <div className="activity-row"><ShieldCheck size={23} style={{ color: '#84a88f' }} /><div><p>安全就绪，等待第一次连接</p><small>真实设备操作会在这里留痕；演示模式不产生执行记录。</small></div></div>}</section><section className="panel"><div className="panel-heading"><h2>常用工具</h2><span className="tiny-label">QUICK ACTIONS</span></div><div className="quick-grid"><button className="quick-action" onClick={() => navigate('automation')}><Workflow size={21} /><span>配置编排</span><small>预检 · 备份 · 执行</small></button><button className="quick-action" onClick={() => navigate('commands')}><BookOpen size={21} /><span>厂商命令库</span><small>四大厂商速查</small></button><button className="quick-action" onClick={() => navigate('assistant')}><Sparkles size={21} /><span>问问 AI</span><small>诊断与配置草稿</small></button></div></section></div>
          </>}
          {page === 'devices' && <Devices devices={devices} demo={demo} busy={busy} onConnect={connect} onTerminal={setTerminal} onAutomate={automate} onRefresh={refresh} />}
          {page === 'wizard' && <Wizard onDraft={createDraft} />}
          {page === 'commands' && <Commands onDraft={createDraft} />}
          {page === 'automation' && <Automation devices={online ? snapshot?.devices || [] : []} jobs={snapshot?.jobs || []} initialDevice={target} draft={draft} draftRevision={draftRevision} busy={busy} onRefresh={refresh} />}
          {page === 'backups' && <Backups />}
          {page === 'audit' && <AuditPage audit={snapshot?.audit || []} jobs={snapshot?.jobs || []} onRefresh={refresh} />}
          <Suspense fallback={<div className="empty-small"><Loader2 className="spinner" />正在加载面板…</div>}>{page === 'settings' && (snapshot ? <Settings settings={snapshot.settings} onRefresh={refresh} /> : <div className="empty-small">连接本机后台后即可配置密钥和自动发现策略。</div>)}</Suspense>
          <footer className="footer"><span>NETPILOT · 本机网络自动化工作台</span><span><ShieldCheck size={10} style={{ display: 'inline', marginRight: 5 }} />仅管理已授权设备 · 所有写操作需确认</span></footer>
        </main></div>
        <aside id="persistent-assistant" className="assistant-dock" hidden={!assistantOpen} aria-labelledby="assistant-dock-title" onKeyDown={event => { if (event.key === 'Escape' && !event.defaultPrevented) { event.preventDefault(); collapseAssistant(); } }}>
          <header className="assistant-dock-heading"><span className="assistant-dock-symbol"><Sparkles size={19} /></span><div><h2 id="assistant-dock-title">AI 网络助手</h2><p>{snapshot?.settings.ai.model ? `${snapshot.settings.ai.provider} · ${snapshot.settings.ai.model}` : '未配置模型'}</p></div><button type="button" className="icon-btn" aria-label="折叠 AI 助手" title="折叠面板，保留聊天历史" onClick={collapseAssistant}><ChevronRight size={19} /></button></header>
          <div className="assistant-dock-body"><Suspense fallback={<div className="empty-small"><Loader2 className="spinner" />正在加载 AI 助手…</div>}><Assistant compact online={online} settings={snapshot?.settings} devices={snapshot?.devices || []} demo={demo} onSettings={() => navigate('settings')} onDraft={createDraft} /></Suspense></div>
        </aside>
      </div>
    </div>
    <ConnectDialog open={connectOpen} onOpenChange={setConnectOpen} settings={snapshot?.settings} prefill={prefill} onConnected={() => { setDemo(false); void refresh(); }} />
    <TerminalDialog device={terminal} onClose={() => setTerminal(null)} />
    <Dialog open={discoverOpen} onOpenChange={setDiscoverOpen}><DialogContent><DialogHeader><DialogTitle>自动发现网络拓扑</DialogTitle><DialogDescription>只读取 LLDP/CDP 信息。递归仅访问允许网段内、已确认 SSH 指纹的邻居。</DialogDescription></DialogHeader><label className="form-field"><span>起始设备</span><select value={root} onChange={e => setRoot(e.target.value)}>{snapshot?.devices.filter(d => d.connected).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label><label className="check-inline"><input type="checkbox" checked={recursive} onChange={e => setRecursive(e.target.checked)} />使用已保存的 SSH 凭据递归发现</label>{recursive && <><label className="form-field"><span>最大递归深度</span><select value={depth} onChange={e => setDepth(Number(e.target.value))}>{[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{n} 跳</option>)}</select></label><div className="notice info">管理范围：{snapshot?.settings.discovery.scope || '尚未设置'}；最多访问 20 台设备。未公布地址、无 SSH 权限或协议未启用的设备无法继续发现。</div></>}<button className="btn btn-primary" disabled={busy || discoverySubmitting} onClick={async () => { setDiscoverySubmitting(true); try { await api('/discover', { deviceId: root, recursive, depth, maxNodes: 20 }); setDiscoverOpen(false); await refresh(); toast.success('已开始只读发现，可在操作审计中查看进度'); } catch (e) { toast.error((e as Error).message); } finally { setDiscoverySubmitting(false); } }}><Network size={15} />{discoverySubmitting ? '提交中…' : '开始只读发现'}</button></DialogContent></Dialog>
    <Dialog open={help} onOpenChange={setHelp}><DialogContent className="modal-content"><DialogHeader><DialogTitle>开始使用 NetPilot</DialogTitle><DialogDescription>面向 Windows 本机的网络运维工作台，不需要把网络暴露到公网。</DialogDescription></DialogHeader><div className="security-item"><Cable size={21} /><div><b>01 · 先用 SecureCRT 连接</b><p>在 SecureCRT 中建立 Console / SSH 会话并登录设备，再在同一标签运行连接弹窗提供的桥接脚本。网页绑定此会话，不另占 Console 串口。</p></div></div><div className="security-item"><Network size={21} /><div><b>02 · 读取真实邻居</b><p>绑定后只读采集直连设备的 LLDP/CDP 信息。多跳发现仍受管理可达性、协议、有效权限及指纹白名单限制，不代表全网完整性。</p></div></div><div className="security-item"><Workflow size={21} /><div><b>03 · 审核后下发</b><p>在常驻 AI 面板选择真实目标，将代码块送入编排。逐条审核并预检、人工确认后才执行；写入前先备份，任一失败即停止。运行任务期间不要手动输入或切换/重连该 SecureCRT 会话；网页断开只解绑，不关闭 SecureCRT 会话。</p></div></div><div className="security-item"><Sparkles size={21} /><div><b>04 · 每次授权后使用 AI</b><p>在系统设置填写 DeepSeek 或 OpenAI 兼容 API。密钥由 Windows 当前用户加密保存；每次发送须同意，默认不附加拓扑，演示数据隔离。切换页面和折叠面板保留历史，刷新或关闭网页后清空。</p></div></div><div className="notice">当前未提供跨厂商事务回滚、自动提权或启动配置保存。SecureCRT 桥接及命令兼容性须按实际环境验证；请按设备型号与软件版本复核，首次配置应在实验设备上验证。</div></DialogContent></Dialog>
    <Toaster richColors position="bottom-right" />
  </SidebarProvider>;
}
