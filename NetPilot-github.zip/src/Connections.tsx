import { useEffect, useRef, useState } from 'react';
import { Cable, Copy, Fingerprint, Loader2, Plug, RefreshCw, ShieldCheck, Terminal as TerminalIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { api, copy, type Device, type Settings, vendorNames } from './shared';

type Props = { open: boolean; onOpenChange: (v: boolean) => void; onConnected: () => void; settings?: Settings; prefill?: Device };
type Pairing = { id: string; code: string; expiresAt: string; scriptPath: string };
export function ConnectDialog({ open, onOpenChange, onConnected, settings, prefill }: Props) {
  const [kind, setKind] = useState('securecrt'), [ports, setPorts] = useState<any[]>([]), [path, setPath] = useState('');
  const [baudRate, setBaudRate] = useState(9600), [vendor, setVendor] = useState('auto'), [host, setHost] = useState(''), [port, setPort] = useState(22);
  const [username, setUsername] = useState(''), [password, setPassword] = useState(''), [fingerprint, setFingerprint] = useState(''), [verified, setVerified] = useState(false);
  const [busy, setBusy] = useState(false), [probing, setProbing] = useState(false), [error, setError] = useState(''), [portError, setPortError] = useState('');
  const [pair, setPair] = useState<Pairing | null>(null), [pairState, setPairState] = useState('');
  const callbacks = useRef({ onConnected, onOpenChange }); callbacks.current = { onConnected, onOpenChange };
  const refreshPorts = async () => { try { const r = await api('/ports'); setPorts(r.ports); setPortError(''); } catch (e) { setPortError((e as Error).message); } };
  useEffect(() => {
    if (!open) return;
    setError(''); setPassword(''); setKind('securecrt'); setPath(settings?.serial.path || ''); setBaudRate(settings?.serial.baudRate || 9600);
    setVendor(prefill?.vendor && prefill.vendor !== 'unknown' ? prefill.vendor : settings?.serial.vendor || 'auto');
    if (prefill?.managementIp) { setHost(prefill.managementIp); const known = settings?.discovery.hosts.find(h => h.host === prefill.managementIp); setFingerprint(known?.fingerprint || ''); setPort(known?.port || 22); setVerified(false); }
  }, [open]);
  useEffect(() => { if (!open || kind !== 'serial') return; void refreshPorts(); const t = setInterval(refreshPorts, 5000); return () => clearInterval(t); }, [open, kind]);
  useEffect(() => {
    if (!pair || !['waiting', 'identifying'].includes(pairState)) return;
    let disposed = false, polling = false;
    const check = async () => {
      if (polling) return; polling = true;
      try {
        const result = await api<{ state: string; error: string }>(`/securecrt/status/${pair.id}`);
        if (disposed) return;
        setPairState(result.state);
        if (result.state === 'connected') { callbacks.current.onConnected(); callbacks.current.onOpenChange(false); toast.success('SecureCRT 会话已绑定，正在自动读取邻居'); }
        if (result.error) setError(result.error);
      } catch (e) { if (!disposed) { setError((e as Error).message); if ((e as { status?: number }).status === 404) setPairState('expired'); } }
      finally { polling = false; }
    };
    void check(); const timer = setInterval(check, 2000);
    return () => { disposed = true; clearInterval(timer); };
  }, [pair?.id, pairState]);
  async function connect() {
    setError(''); setBusy(true);
    try {
      if (kind === 'ssh' && !verified) throw new Error('请先核对并确认 SSH 主机指纹');
      const result = await api<{ warning?: string }>('/connect', { kind, path, baudRate, vendor, host, port, username, password, fingerprint, discover: true });
      setPassword(''); onConnected(); onOpenChange(false);
      if (result?.warning) toast.warning(result.warning); else toast.success('设备已连接，正在只读发现邻居');
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  return <Dialog open={open} onOpenChange={v => { if (!busy) onOpenChange(v); }}><DialogContent className="modal-content"><DialogHeader><DialogTitle>通过 SecureCRT 连接设备</DialogTitle><DialogDescription>SecureCRT 负责 Console / SSH 登录；网页负责拓扑、AI 对话、命令审核和下发。</DialogDescription></DialogHeader>
    <Tabs value={kind} onValueChange={setKind}><TabsList><TabsTrigger value="securecrt"><TerminalIcon size={15} />SecureCRT</TabsTrigger><TabsTrigger value="serial"><Cable size={15} />串口直连</TabsTrigger><TabsTrigger value="ssh">SSH 直连</TabsTrigger></TabsList>
      <TabsContent value="securecrt">
        <div className="notice info"><ShieldCheck size={16} /><span>先在 SecureCRT 连接并登录设备，停在 <code>&lt;设备名&gt;</code> 或 <code>设备名#</code> 提示符。网页不抢占 SecureCRT 使用的 COM 端口，也不读取其中保存的密码。</span></div>
        {prefill && <p className="muted" style={{ marginBottom: 12 }}>待连接设备：{prefill.name} {prefill.managementIp}。请在 SecureCRT 中确认选中了对应设备的标签。</p>}
        <label className="form-field"><span>设备厂商</span><select value={vendor} disabled={pairState === 'waiting' || pairState === 'identifying'} onChange={e => setVendor(e.target.value)}><option value="auto">自动识别（推荐）</option>{Object.entries(vendorNames).filter(([v]) => v !== 'unknown').map(([v, n]) => <option key={v} value={v}>{n}</option>)}</select></label>
        {!pair || !['waiting', 'identifying'].includes(pairState) ? <button className="btn btn-primary" disabled={busy} onClick={async () => { setError(''); setBusy(true); try { const result = await api<Pairing>('/securecrt/prepare', { vendor }); setPair(result); setPairState('waiting'); } catch (e) { setError((e as Error).message); } finally { setBusy(false); } }}><Plug size={16} />{busy ? '准备中…' : '生成 SecureCRT 配对入口'}</button> : null}
        {pair && <section className="panel" style={{ padding: 16, marginTop: 16 }}>
          <h3 style={{ fontSize: 13, marginBottom: 12 }}>在目标 SecureCRT 标签内执行以下两步</h3>
          <label className="form-field"><span>1 · Script → Run（脚本 → 运行），选择此脚本</span><input readOnly value={pair.scriptPath} onFocus={e => e.target.select()} /><button type="button" className="btn btn-sm" onClick={() => copy(pair.scriptPath)}><Copy size={13} />复制脚本路径</button></label>
          <label className="form-field"><span>2 · 将一次性配对码粘贴到脚本弹窗</span><div className="button-row"><input className="mono" readOnly value={pair.code} onFocus={e => e.target.select()} /><button type="button" className="btn btn-sm" onClick={() => copy(pair.code)}><Copy size={13} />复制</button></div><small>10 分钟内有效、仅可使用一次。脚本不包含设备密码或 AI Key。绑定后自动只读识别厂商及邻居。</small></label>
          <p className="muted" role="status">{({ waiting: '等待 SecureCRT 运行脚本…', identifying: '脚本已连接，正在查询设备身份…', connected: '已绑定 SecureCRT 会话', expired: '配对码已过期，请重新生成。', failed: '绑定失败，请检查下方提示。', disconnected: '脚本已停止或心跳断开，请重新配对。' } as Record<string, string>)[pairState]}</p>
        </section>}
        <p className="muted" style={{ marginTop: 14 }}>桥接运行时请不要在该标签手动输入、断开重连或同时运行其他脚本。停止可用 SecureCRT 的 Script → Cancel，或在网页设备列表解绑；不会自动关闭你的 SecureCRT 会话。脚本需 Windows 版 SecureCRT 支持 VBScript。</p>
        {settings?.serial.autoConnect && <div className="notice danger" style={{ marginTop: 12 }}>当前启用了串口直连自动连接。使用 SecureCRT 前请到设置关闭它，避免两个程序竞争同一 COM 端口。</div>}
      </TabsContent>
      <TabsContent value="serial"><div className="notice">备用连接方式：仅在该 COM 端口未被 SecureCRT 占用时使用。</div><div className="form-grid"><label className="form-field wide"><span>串口设备 <button className="text-link" type="button" onClick={refreshPorts}><RefreshCw size={12} />刷新</button></span><select value={path} onChange={e => setPath(e.target.value)}><option value="">{ports.length ? '请选择 Console 串口' : '未检测到串口，请接入 Console 线'}</option>{ports.map(p => <option key={p.path} value={p.path}>{p.path} · {p.manufacturer || p.friendlyName || '串口设备'}</option>)}</select><small>每 5 秒自动检测端口。无端口时请检查 USB 转串口驱动。</small></label><label className="form-field"><span>波特率</span><select value={baudRate} onChange={e => setBaudRate(Number(e.target.value))}>{[9600, 19200, 38400, 57600, 115200].map(b => <option key={b} value={b}>{b}</option>)}</select></label><label className="form-field"><span>串口参数</span><input value="8 数据位 / 无校验 / 1 停止位" disabled /></label></div>{portError && <div className="error-box">{portError}</div>}</TabsContent>
      <TabsContent value="ssh"><div className="form-grid"><label className="form-field"><span>管理 IPv4 地址</span><input placeholder="192.168.1.1" value={host} onChange={e => { setHost(e.target.value); setVerified(false); setFingerprint(''); }} /></label><label className="form-field"><span>SSH 端口</span><input type="number" min={1} max={65535} value={port} onChange={e => { setPort(Number(e.target.value)); setVerified(false); setFingerprint(''); }} /></label><label className="form-field wide"><span>主机公钥指纹</span><input placeholder="SHA256:…" value={fingerprint} onChange={e => { setFingerprint(e.target.value); setVerified(false); }} /><button className="btn btn-sm" disabled={probing || !host} onClick={async () => { setProbing(true); setError(''); try { const r = await api('/ssh/probe', { host, port }); setFingerprint(r.fingerprint); setVerified(false); } catch (e) { setError((e as Error).message); } finally { setProbing(false); } }}><Fingerprint size={14} />{probing ? '读取中…' : '读取公钥（不会登录）'}</button><small>必须通过设备控制台或管理员提供的指纹核对。</small></label></div><label className="check-inline" style={{ marginBottom: 18 }}><input type="checkbox" checked={verified} onChange={e => setVerified(e.target.checked)} />我已通过可信途径核对该主机指纹</label></TabsContent>
    </Tabs>
    {kind !== 'securecrt' && <><label className="form-field"><span>设备厂商</span><select value={vendor} onChange={e => setVendor(e.target.value)}><option value="auto">自动识别（推荐）</option>{Object.entries(vendorNames).filter(([v]) => v !== 'unknown').map(([v, n]) => <option key={v} value={v}>{n}</option>)}</select></label><div className="form-grid"><label className="form-field"><span>登录用户名</span><input autoComplete="off" value={username} onChange={e => setUsername(e.target.value)} placeholder={kind === 'serial' ? '已登录的 Console 可留空' : 'admin'} /></label><label className="form-field"><span>登录密码</span><input type="password" autoComplete="new-password" value={password} onChange={e => setPassword(e.target.value)} placeholder="仅用于本次连接，不保存" /></label></div><div className="notice info"><ShieldCheck size={15} /><span>仅管理已授权设备。需要 enable/super 提权时，请先在 SecureCRT 完成；本工具不会猜测或尝试口令。</span></div><button className="btn btn-primary" disabled={busy || (kind === 'serial' ? !path : !host || !fingerprint || !verified)} onClick={connect}>{busy ? <Loader2 className="spinner" size={16} /> : <Plug size={16} />}{busy ? '正在连接并识别设备…' : '直连并自动发现'}</button></>}
    {error && <div className="error-box" role="alert">{error}</div>}
  </DialogContent></Dialog>;
}

export function TerminalDialog({ device, onClose }: { device: Device | null; onClose: () => void }) {
  const [command, setCommand] = useState(''), [output, setOutput] = useState(''), [busy, setBusy] = useState(false);
  const demo = device?.id.startsWith('demo-');
  useEffect(() => { setCommand(device?.vendor === 'huawei' || device?.vendor === 'h3c' ? 'display version' : 'show version'); setOutput(''); }, [device]);
  return <Dialog open={!!device} onOpenChange={v => { if (!v) onClose(); }}><DialogContent className="modal-content sm:max-w-3xl"><DialogHeader><DialogTitle>只读终端 · {device?.name}</DialogTitle><DialogDescription>仅接受后台只读白名单内的完整命令。写操作请前往自动化编排。{device?.kind === 'securecrt' ? '命令经 SecureCRT 已绑定标签发送。' : ''}</DialogDescription></DialogHeader>{demo && <div className="notice">这是演示设备，不会建立真实会话或返回模拟命令结果。</div>}<pre className="terminal">{output || '等待查询。输出只显示在本地当前会话，不会自动发送给 AI。'}</pre><form className="button-row" onSubmit={async e => { e.preventDefault(); if (!device || busy) return; setBusy(true); try { const r = await api('/terminal', { deviceId: device.id, command }); setOutput(p => `${p}\n> ${command}\n${r.output}\n`); } catch (err) { setOutput(p => `${p}\n[错误] ${(err as Error).message}`); } finally { setBusy(false); } }}><input className="search-input mono" aria-label="只读命令" value={command} onChange={e => setCommand(e.target.value)} /><button className="btn btn-primary" disabled={busy || demo || !device?.connected}>{busy ? '查询中…' : '运行查询'}</button></form></DialogContent></Dialog>;
}
