import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Check, CircleAlert, Copy, FileCode2, Loader2, RefreshCw, ShieldCheck, Wand2 } from 'lucide-react';
import { toast } from 'sonner';
import { api, copy, vendorColors, vendorNames } from './shared';

type Param = { key: string; label: string; placeholder?: string; required?: boolean; options?: string[]; help?: string };
type Step = { id: string; group: string; title: string; desc: string; params: Param[]; vendors?: string[] };
type Group = { id: string; title: string; desc: string };
type Catalog = { groups: Group[]; steps: Step[]; vendors: { id: string; label: string }[] };
type Built = { commands: string[]; lines: number; warnings: string[] };

const STORAGE_KEY = 'netpilot-wizard-draft';
type Draft = { vendor: string; picked: Record<string, Record<string, string>> };
function loadDraft(): Draft {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || '{}') as Partial<Draft>;
    return {
      vendor: typeof parsed.vendor === 'string' ? parsed.vendor : 'huawei',
      picked: parsed.picked && typeof parsed.picked === 'object' ? parsed.picked : {},
    };
  } catch { return { vendor: 'huawei', picked: {} }; }
}

export default function Wizard({ onDraft }: { onDraft: (commands: string) => void }) {
  const initial = loadDraft();
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [vendor, setVendor] = useState(initial.vendor);
  const [picked, setPicked] = useState<Record<string, Record<string, string>>>(initial.picked);
  const [result, setResult] = useState<Built | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState('');

  useEffect(() => {
    api<Catalog>('/wizard').then(setCatalog).catch((e: Error) => setLoadError(e.message));
  }, []);

  // 切页面不丢草稿：按会话保存选择，目录加载后顺手剔除已下线步骤。
  useEffect(() => {
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ vendor, picked })); } catch { /* 隐私模式忽略 */ }
  }, [vendor, picked]);
  useEffect(() => {
    if (!catalog) return;
    if (!catalog.vendors.some(item => item.id === vendor)) setVendor(catalog.vendors[0]?.id || 'huawei');
    setPicked(current => {
      const entries = Object.entries(current).filter(([id]) => catalog.steps.some(step => step.id === id));
      return entries.length === Object.keys(current).length ? current : Object.fromEntries(entries);
    });
  }, [catalog]);

  const steps = catalog?.steps || [];
  const selected = Object.keys(picked);
  const byGroup = useMemo(() => {
    const map = new Map<string, Step[]>();
    for (const step of steps) map.set(step.group, [...(map.get(step.group) || []), step]);
    return map;
  }, [steps]);

  function toggle(id: string) {
    const definition = steps.find(item => item.id === id);
    if (definition?.vendors && !definition.vendors.includes(vendor)) { toast.info('该步骤仅适用于指定厂商。'); return; }
    setResult(null);
    setPicked(current => {
      const next = { ...current };
      if (next[id]) delete next[id];
      else next[id] = Object.fromEntries((definition?.params || []).filter(param => param.options?.length).map(param => [param.key, param.options![0]]));
      return next;
    });
  }
  function setParam(id: string, key: string, value: string) {
    setResult(null);
    setPicked(current => ({ ...current, [id]: { ...(current[id] || {}), [key]: value } }));
  }
  async function build() {
    if (!selected.length || busy) return;
    setBusy(true); setError(''); setResult(null);
    try {
      const data = await api<Built>('/wizard/build', { vendor, steps: selected.map(id => ({ id, params: picked[id] })) });
      setResult(data);
      toast.success(`已生成 ${data.lines} 行命令，尚未下发`);
    } catch (failure) { setError((failure as Error).message); }
    finally { setBusy(false); }
  }

  if (loadError) return <div className="error-box" role="alert">无法加载配置向导：{loadError}</div>;
  if (!catalog) return <div className="empty-small"><Loader2 className="spinner" size={22} />正在加载向导目录…</div>;

  return <div className="wizard-layout">
    <section className="panel">
      <div className="vendor-tabs">{catalog.vendors.map(v => <button key={v.id} className={vendor === v.id ? 'active' : ''} onClick={() => { setVendor(v.id); setResult(null); setPicked(current => Object.fromEntries(Object.entries(current).filter(([id]) => { const definition = steps.find(item => item.id === id); return !definition?.vendors || definition.vendors.includes(v.id); }))); }}><i style={{ background: vendorColors[v.id] }} />{vendorNames[v.id] || v.label}</button>)}</div>
      <div className="toolbar"><span className="muted">已选 {selected.length} 个步骤 · 命令按目标厂商语法实时生成</span><button className="btn btn-sm" style={{ marginLeft: 'auto' }} disabled={!selected.length} onClick={() => { setPicked({}); setResult(null); }}><RefreshCw size={13} />清空选择</button></div>
      <div className="wizard-groups">
        {catalog.groups.map(group => {
          const items = byGroup.get(group.id) || [];
          if (!items.length) return null;
          return <div className="wizard-group" key={group.id}>
            <header><h3>{group.title}</h3><p>{group.desc}</p></header>
            {items.map(step => {
              const active = Object.hasOwn(picked, step.id);
              const blocked = Boolean(step.vendors && !step.vendors.includes(vendor));
              return <article className={`wizard-step${active ? ' active' : ''}${blocked ? ' blocked' : ''}`} key={step.id}>
                <label className="wizard-step-head">
                  <input type="checkbox" checked={active} disabled={blocked} onChange={() => toggle(step.id)} />
                  <div><b>{step.title}{blocked && <span className="wizard-tag">仅{vendorNames[step.vendors![0]] || step.vendors![0]}</span>}</b><small>{step.desc}</small></div>
                </label>
                {active && <div className="wizard-params">{step.params.length ? step.params.map(param => <label className="form-field" key={param.key}><span>{param.label}{param.required === false ? '（可选）' : ''}</span>{param.options ? <select value={picked[step.id]?.[param.key] ?? param.options[0]} onChange={e => setParam(step.id, param.key, e.target.value)}>{param.options.map(option => <option key={option} value={option}>{option}</option>)}</select> : <input value={picked[step.id]?.[param.key] ?? ''} placeholder={param.placeholder} onChange={e => setParam(step.id, param.key, e.target.value)} spellCheck={false} />}</label>) : <p className="muted">该步骤无需参数。</p>}</div>}
              </article>;
            })}
          </div>;
        })}
      </div>
    </section>

    <aside className="panel wizard-preview">
      <div className="panel-heading"><div><span className="overline">CONFIG WIZARD</span><h2>生成结果</h2></div><Wand2 size={20} /></div>
      <div className="panel-body">
        <button className="btn btn-primary" disabled={!selected.length || busy} onClick={build}>{busy ? <Loader2 className="spinner" size={15} /> : <Wand2 size={15} />}{busy ? '正在生成…' : '按当前厂商生成命令'}</button>
        {error && <div className="error-box" role="alert">{error}</div>}
        {!result && !error && <p className="muted" style={{ marginTop: 14 }}>勾选左侧步骤、填好参数后生成。命令只进草稿，必须经过预检与人工确认才会下发。</p>}
        {result && <>
          <div className="plan-summary">目标厂商：{vendorNames[vendor]} · {result.lines} 行命令<br />生成结果不含保存启动配置；请在终端人工 save / write。</div>
          {result.warnings.slice(0, 6).map((w, i) => <p className="muted" key={i} style={{ marginBottom: 7 }}><CircleAlert size={12} style={{ display: 'inline', marginRight: 6 }} />{w}</p>)}
          <pre className="terminal wizard-output" tabIndex={0}>{result.commands.map((line, i) => <div key={i} className={line.startsWith('#') ? 'code-comment' : 'code-line'}><span className="line-num">{i + 1}</span><span>{line}</span></div>)}</pre>
          <div className="button-row" style={{ flexWrap: 'wrap', marginTop: 12 }}>
            <button className="btn btn-sm" onClick={() => void copy(result.commands.join('\n'))}><Copy size={13} />复制</button>
            <button className="btn btn-primary btn-sm" onClick={() => onDraft(result.commands.join('\n'))}><FileCode2 size={13} />送入编排预检<ArrowRight size={12} /></button>
          </div>
          <p className="muted" style={{ marginTop: 10 }}><ShieldCheck size={11} style={{ display: 'inline', marginRight: 5 }} />只读与配置命令会一起送入预检；破坏性命令会被拦截。</p>
        </>}
        <div className="section-separator" />
        <h3 style={{ display: 'flex', alignItems: 'center', gap: 7 }}><Check size={15} />生成规则</h3>
        <p className="muted">接口、VLAN、IP、掩码全部做白名单校验；未替换参数、跨视图错位会在预检阶段再次拦截。华为/华三自动用 system-view，锐捷/Cisco 用 configure terminal。</p>
      </div>
    </aside>
  </div>;
}
