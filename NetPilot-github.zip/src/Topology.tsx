import { useMemo, useRef, useState } from 'react';
import { Cable, Crosshair, Download, Expand, Layers, Minus, Network, Plus, Router, ScanLine, ShieldCheck, Terminal, Unplug } from 'lucide-react';
import { type Device, type Link, vendorNames, vendorColors, download, time } from './shared';

type Props = { devices: Device[]; links: Link[]; demo: boolean; busy: boolean; autoRefresh?: number; onConnect: () => void; onDiscover: () => void; onTerminal: (d: Device) => void; onAutomate: (d: Device) => void };
export default function Topology({ devices, links, demo, busy, autoRefresh = 0, onConnect, onDiscover, onTerminal, onAutomate }: Props) {
  const [selectedId, setSelectedId] = useState('');
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [ports, setPorts] = useState(true);
  const [query, setQuery] = useState('');
  const svgRef = useRef<SVGSVGElement>(null);
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null);
  const selected = devices.find(d => d.id === selectedId) || devices[0];
  const positions = useMemo(() => {
    const result: Record<string, { x: number; y: number }> = {};
    const levels = new Map<number, Device[]>();
    devices.forEach(d => { const depth = d.depth || 0; levels.set(depth, [...(levels.get(depth) || []), d]); });
    // 每层最多 5 个节点一行，超出换行，避免几十台设备时横向拉成一条长线。
    let rowOffset = 0;
    [...levels.keys()].sort((a, b) => a - b).forEach(depth => {
      const group = levels.get(depth)!;
      const perRow = Math.min(5, group.length);
      const rows = Math.ceil(group.length / perRow);
      group.forEach((d, i) => {
        const row = Math.floor(i / perRow);
        const column = i % perRow;
        const count = Math.min(perRow, group.length - row * perRow);
        result[d.id] = { x: 450 + (column - (count - 1) / 2) * 190, y: 105 + (rowOffset + row) * 160 };
      });
      rowOffset += rows;
    });
    return result;
  }, [devices]);
  const maxY = Math.max(560, ...Object.values(positions).map(p => p.y + 100));
  const related = links.filter(l => l.source === selected?.id || l.target === selected?.id);
  return <>
    <div className="stats-grid">
      <div className="stat-card"><span className="stat-icon teal"><Router /></span><div><span>已发现设备</span><strong>{devices.length.toString().padStart(2, '0')}<small>台</small></strong></div><span className="stat-tag">{demo ? '示例' : '设备发现'}</span></div>
      <div className="stat-card"><span className="stat-icon blue"><Cable /></span><div><span>邻接链路</span><strong>{links.length.toString().padStart(2, '0')}<small>条</small></strong></div><span className="stat-tag">LLDP / CDP</span></div>
      <div className="stat-card"><span className="stat-icon purple"><Layers /></span><div><span>设备厂商</span><strong>{new Set(devices.map(d => d.vendor).filter(v => v !== 'unknown')).size.toString().padStart(2, '0')}<small>类</small></strong></div><span className="stat-tag">多厂商协同</span></div>
      <div className="stat-card"><span className="stat-icon amber"><ShieldCheck /></span><div><span>配置执行策略</span><strong className="text-stat">人工确认</strong></div><span className="stat-tag">安全保护开启</span></div>
    </div>
    <div className="topology-layout">
      <section className="panel topology-panel">
        <div className="panel-heading"><div><span className="overline">NETWORK MAP</span><h2>网络拓扑 <span className="tiny-label">{demo ? '演示视图' : '本机发现'}</span></h2></div><div className="button-row"><button className="icon-btn" title="导出拓扑 JSON" aria-label="导出拓扑" onClick={() => download(`netpilot-${demo ? 'demo' : 'topology'}.json`, JSON.stringify({ sample: demo, exportedAt: new Date().toISOString(), devices, links }, null, 2))}><Download size={17} /></button><button className="icon-btn" title="展开拓扑" aria-label="展开拓扑" onClick={() => svgRef.current?.parentElement?.requestFullscreen?.().catch(() => {})}><Expand size={17} /></button><button className="btn btn-primary btn-sm" disabled={busy} onClick={onDiscover}><ScanLine size={15} />{busy ? '正在采集…' : '自动发现'}</button></div></div>
        <div className="map-toolbar"><label className="map-search"><Network size={15} /><input aria-label="查找拓扑设备" placeholder="查找设备名称或 IP…" value={query} onChange={e => setQuery(e.target.value)} /></label><label className="check-inline"><input type="checkbox" checked={ports} onChange={e => setPorts(e.target.checked)} />端口标签</label></div>
        <div className="network-canvas">
          <div className="map-badge"><span className={`status-dot ${demo ? 'amber-dot' : ''}`} />{demo ? '示例拓扑 · 非实时设备' : `${devices.length} 台设备${autoRefresh > 0 ? ` · 每 ${autoRefresh}s 自动刷新` : ''} · 不代表全网完整性`}</div>
          {devices.length ? <svg ref={svgRef} viewBox={`0 0 900 ${maxY}`} role="img" aria-label="可交互网络拓扑，点击设备查看详情" onWheel={e => setZoom(z => Math.min(2, Math.max(.4, z - e.deltaY * .001)))} onPointerDown={e => { if ((e.target as Element).closest('[data-node]')) return; drag.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y }; e.currentTarget.setPointerCapture(e.pointerId); }} onPointerMove={e => { if (drag.current) { const r = e.currentTarget.getBoundingClientRect(); setPan({ x: drag.current.px + (e.clientX - drag.current.x) * 900 / r.width, y: drag.current.py + (e.clientY - drag.current.y) * maxY / r.height }); } }} onPointerUp={() => { drag.current = null; }} onPointerCancel={() => { drag.current = null; }}>
            <defs><filter id="node-shadow" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="0" dy="4" stdDeviation="5" floodColor="#223b38" floodOpacity=".08" /></filter></defs>
            <g transform={`translate(${pan.x + 450 * (1 - zoom)} ${pan.y + 270 * (1 - zoom)}) scale(${zoom})`}>
              {links.map(l => { const a = positions[l.source], b = positions[l.target]; if (!a || !b) return null; const y = (a.y + b.y) / 2; const active = l.source === selected?.id || l.target === selected?.id; return <g key={l.id}><path className={active ? 'map-link active' : 'map-link'} d={`M ${a.x} ${a.y + 27} V ${y} Q ${a.x} ${y + 12} ${a.x + Math.sign(b.x - a.x) * 12} ${y + 12} H ${b.x - Math.sign(b.x - a.x) * 12} Q ${b.x} ${y + 12} ${b.x} ${y + 24} V ${b.y - 25}`} /><circle cx={a.x} cy={a.y + 27} r="3" fill={active ? '#19998b' : '#becdcb'} />{ports && <g><rect x={(a.x + b.x) / 2 - 55} y={y + 2} width="110" height="21" rx="5" fill="#f7faf9" stroke="#e1e9e6" /><text x={(a.x + b.x) / 2} y={y + 16} className="port-text">{l.localPort}</text></g>}</g>; })}
              {devices.map(d => { const p = positions[d.id]; const sel = d.id === selected?.id; const faded = query && !`${d.name} ${d.managementIp}`.toLowerCase().includes(query.toLowerCase()); return <g key={d.id} data-node="true" className={`map-node ${sel ? 'selected' : ''}`} role="button" tabIndex={0} aria-label={`设备 ${d.name}`} style={{ opacity: faded ? .22 : 1 }} transform={`translate(${p.x} ${p.y})`} onClick={() => setSelectedId(d.id)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSelectedId(d.id); } }}>
                {sel && <rect x="-87" y="-39" width="174" height="112" rx="17" className="selection-outline" />}
                <rect x="-76" y="-29" width="152" height="55" rx="11" className="node-body" filter="url(#node-shadow)" />
                <rect x="-59" y="-15" width="36" height="25" rx="5" fill={`${vendorColors[d.vendor]}18`} />
                <g transform="translate(-52 -8)" stroke={vendorColors[d.vendor]} fill="none" strokeWidth="1.6"><rect width="22" height="11" rx="2" /><path d="M4 4h2m3 0h2m3 0h2M4 7h2m3 0h2m3 0h2" /></g>
                <text x="-13" y="-5" className="node-vendor">{vendorNames[d.vendor] || '未知厂商'}</text><text x="-13" y="12" className="node-model">{d.model?.slice(0, 19) || (d.kind === 'serial' ? 'Console 直连' : '邻居设备')}</text>
                <circle cx="65" cy="-20" r="4" fill={demo ? '#d99f3e' : d.connected ? '#169e86' : '#a4afba'} />
                <text y="48" className="node-name">{d.name?.slice(0, 26) || '未命名设备'}</text><text y="65" className="node-ip">{d.managementIp || (d.kind === 'serial' ? 'CONSOLE · 本机直连' : '管理地址未公布')}</text>
                {d.kind === 'serial' && <g transform="translate(-35 -52)"><rect width="70" height="17" rx="5" fill="#e0f2eb" /><text x="35" y="12" className="console-label">CONSOLE</text></g>}
              </g>; })}
            </g>
          </svg> : <div className="map-empty"><div className="empty-orbit"><Network size={38} /></div><h3>让你的网络，清晰可见</h3><p>接入 Console 线，选择串口并连接。<br />读取设备邻居表后，拓扑会出现在这里。</p><button className="btn btn-primary" onClick={onConnect}><Plus size={17} />连接第一台设备</button></div>}
          <div className="map-legend"><span><i style={{ background: vendorColors.huawei }} />华为</span><span><i style={{ background: vendorColors.h3c }} />华三</span><span><i style={{ background: vendorColors.ruijie }} />锐捷</span><span><i style={{ background: vendorColors.cisco }} />Cisco</span></div>
          <div className="map-controls"><button aria-label="缩小拓扑" onClick={() => setZoom(z => Math.max(.4, z - .15))}><Minus size={16} /></button><span>{Math.round(zoom * 100)}%</span><button aria-label="放大拓扑" onClick={() => setZoom(z => Math.min(2, z + .15))}><Plus size={16} /></button><button aria-label="重置拓扑视图" onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}><Crosshair size={16} /></button></div>
        </div>
        <div className="panel-foot"><span><ShieldCheck size={14} />发现阶段仅查询设备，不修改配置</span><span>拖动平移 · 滚轮缩放 · 点击设备</span></div>
      </section>
      <aside className="panel inspector"><div className="panel-heading"><h2>设备详情</h2><span className="tiny-label">INSPECTOR</span></div>{selected ? <><div className="device-hero"><span className="device-hero-icon" style={{ color: vendorColors[selected.vendor], background: `${vendorColors[selected.vendor]}12` }}><Router size={30} /></span><span className={`pill ${demo ? 'warning' : ''}`}>{demo ? '演示设备' : selected.connected ? '会话已连接' : '仅被邻居发现'}</span><h3>{selected.name}</h3><p>{selected.model || '型号尚未识别'}</p></div><dl className="details-list"><div><dt>设备厂商</dt><dd>{vendorNames[selected.vendor]}</dd></div><div><dt>管理地址</dt><dd className="mono">{selected.managementIp || '未获得'}</dd></div><div><dt>连接方式</dt><dd>{selected.kind === 'serial' ? 'Console 串口' : selected.kind === 'ssh' ? 'SSH' : '邻居公告'}</dd></div><div><dt>邻接链路</dt><dd>{related.length} 条</dd></div><div><dt>最近采集</dt><dd>{demo ? '示例快照' : time(selected.lastSeen)}</dd></div></dl>{!demo && selected.autoRefreshError && <div className="notice danger" style={{ marginBottom: 10 }}><span>自动刷新失败：{selected.autoRefreshError}</span></div>}<div className="neighbor-list"><h4>邻接端口 <span>{related.length}</span></h4>{related.length ? related.map(l => <div key={l.id}><Cable size={14} /><span>{l.source === selected.id ? l.localPort : l.remotePort}<small>{devices.find(d => d.id === (l.source === selected.id ? l.target : l.source))?.name}</small></span><b>{l.protocol}</b></div>) : <p className="muted">尚无邻居数据</p>}</div><div className="inspector-actions"><button className="btn" onClick={() => onTerminal(selected)}><Terminal size={16} />只读终端</button><button className="btn btn-primary" onClick={() => onAutomate(selected)}>配置此设备</button></div><p className="inspector-note">{demo ? '演示设备不连接真实网络，也不会执行配置。' : '邻居可见不等于管理可达；配置前需要建立设备会话。'}</p></> : <div className="empty-small"><Unplug size={30} /><p>连接后选择设备<br />查看型号、端口和邻居</p></div>}</aside>
    </div>
  </>;
}
